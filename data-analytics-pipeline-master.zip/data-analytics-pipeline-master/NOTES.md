# Issues

 - EventHub has issuses with 2 or more DAGs in a spark application try to read/write to the same topic 
 while in the same consumer group. For reads it seems to cause receivers to frequently disconnect 
 claiming another reciever has connected. For writes, it causes timeout issues. Work around is to use foreachBatch to created
 a kind of seralized commit to eventHub
 
 - Trottling issues. EventHub seems to fail if the publish rate goes over a certian number. The exact reason is still 
 to be determined, but we get regular failures with the following exception
 
    ```
   Lost task 2.0 in stage 43.0 (TID 175, 10.139.64.16, executor 4): com.microsoft.azure.eventhubs.ServerBusyException: The request was terminated because the entity is being throttled. Error code : 50002. Please wait 4 seconds and try again. To know more visit https://aka.ms/sbResourceMgrExceptionsS:N:SENSATADEV-EH:EVENTHUB:DO-CURATED-RECORDS~32766,CL:684,CC:717,ACC:2138905,LUR:All-0,LUT:2020-09-02T17:26:25.2094940Z,RC:1 TrackingId:4bd7801a0000b01400342c255f4fd58f_G31_B25, SystemTracker:sensatadev-eh:eventhub:do-curated-records~32766, Timestamp:2020-09-02T17:26:31, errorContext[NS: sensatadev-eh.servicebus.windows.net, PATH: do-curated-records, REFERENCE_ID: 33c7b57a95604ef195bd1b37f45f2440_G31, LINK_CREDIT: 0]
   ```
 - durations of alerts is calculated in the streaming job as the hub is unable to send an accurate duration at the moment
 - Any message with a date older than 2day is no processed as the hub currently has a problem with it's RTC handling.