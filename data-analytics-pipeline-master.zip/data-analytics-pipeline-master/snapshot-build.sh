#!/bin/bash

#docker run -d -it -v /opt/sensata:/media/windows10/Users/Charles\ Bajomo/Projects/sensata/data-analytics-pipeline sensdata/sc-builder
#

export RELEASE_VERSION=`cat /opt/sensata/VERSION`.`date +%d`
export DATABRICKS_CONFIG_FILE=/databricks.dev.cfg
cd /opt/sensata
sbt clean test
sbt package
dbfs mkdirs dbfs:/build/snapshots
dbfs cp --overwrite target/scala-2.12/*.jar dbfs:/build/snapshots/
