
CREATE TABLE public.dashboard_wheel_data_current (
	service varchar(100) not null,
	reported_time timestamp not null,
	schema_version varchar(10) not null,
	location varchar(50) not null,
	location_name varchar(100) not null,
	device_id varchar(120) NULL,
	asset_id varchar(120) NULL,
	asset_code varchar(120) NULL,
	device_name varchar(150) NOT NULL,
	company varchar(100) NULL,
    fleet varchar(100) NULL,
    asset_name varchar(150) NULL,
    wheel_config varchar(50) not null,
    image_url varchar(200) null,
    no_axles varchar(50) not null,
	pipeline_timestamp timestamp NULL,
	consumed_timestamp bigint not null,
	measured_temperature float8 NOT NULL,
	measured_temperature_c float8 NOT NULL,
	measured_temperature_f float8 NOT NULL,
	battery_status int4 NOT NULL,
	measured_pressure float8 NOT NULL,
	measured_pressure_psi float8 NOT NULL,
	temp_comp float8 NOT NULL,
	low_pressure_value float8 NOT NULL DEFAULT 0,
    extra_low_pressure_value float8 NOT NULL DEFAULT 0,
    normal_pressure_value float8 NOT NULL DEFAULT 0,
    low_temperature_value float8 NOT NULL DEFAULT 0,
    extra_low_temperature_value float8 NOT NULL DEFAULT 0,
    normal_temperature_value float8 NOT NULL DEFAULT 0,
	wheel_key varchar(100) not null,
	vehicle_key varchar(100) not null,
    asset_wheel_config_key varchar(100) not null,
	last_updated timestamp not null,
	PRIMARY KEY (service, device_id, location)
);


CREATE TABLE public.dashboard_wheel_alert_current (
	service varchar(100) not null,
	schema_version varchar(10) not null,
	resource varchar(100) not null,
	location varchar(50) not null,
	location_name varchar(150) not null,
	device_id varchar(150) NULL,
	asset_id varchar(120) NULL,
	asset_code varchar(120) NULL,
	device_name varchar(200) NOT NULL,
	company varchar(200) NULL,
    fleet varchar(200) NULL,
    asset_name varchar(150) NULL,
    wheel_config varchar(50) not null,
    image_url varchar(200) null,
    no_axles varchar(50) not null,
	reported_time timestamp not null,
	pipeline_timestamp timestamp NULL,
	consumed_timestamp bigint not null,
	active int4 not null,
    alert_name varchar(50) not null,
    duration int4 not null,
    previous_active_duration int4 not null,
    category int4 not null,
    wheel_key varchar(100) not null,
    vehicle_key varchar(100) not null,
    distance_travel_with_alert float8 NOT NULL DEFAULT 0,
    asset_wheel_config_key varchar(100) not null,
	last_updated timestamp not null,
	PRIMARY KEY (service,resource,device_id,location)
);

CREATE TABLE public.dashboard_vehicle_data_current (
	service varchar(100) NOT NULL default 'N/A',
	device_id varchar(100) NULL default 'N/A',
	asset_id varchar(120) NULL,
	asset_code varchar(120) NULL,
	device_name varchar(150) NOT NULL default 'N/A',
	company varchar(100) NULL default 'N/A',
    fleet varchar(100) NULL default 'N/A',
    asset_name varchar(100) NULL default 'N/A',
    wheel_config varchar(50) not null default 'N/A',
    image_url varchar(200) null default 'N/A',
    no_axles varchar(50) not null default 'N/A',
	reported_time timestamp NULL,
	schema_version varchar(10) NULL default 'N/A',
	pipeline_timestamp timestamp NULL,
	consumed_timestamp bigint NULL default 0,
	latitude float8 NOT NULL default 0,
	longitude float8 NOT NULL default 0,
	altitude int4 NOT NULL default 0,
	gps_timestamp timestamp NULL,
	measured_speed int4 NOT NULL default 0,
	measured_heading int4 NOT NULL default 0,
	odometer int4 NOT NULL default 0,
	odometer_total int4 NOT NULL default 0,
	odometer_in_miles float8 NOT NULL default 0,
	odometer_total_in_miles float8 NOT NULL default 0,
	vehicle_key varchar(100) not null,
	device_has_alerts int4 NOT NULL default 0,
	alerts_duration_hrs float8 NOT NULL default 0,
	last_updated timestamp not null,
	PRIMARY KEY (service,device_id,device_name)
);

CREATE TABLE public.dashboard_wheel_alert_data_history (
    service varchar(100) not null,
    resource varchar(200) not null,
	location varchar(100) not null,
	location_name varchar(150) not null,
	alert_name varchar(100) not null,
	device_id varchar(100) NULL,
	asset_id varchar(120) NULL,
	asset_code varchar(120) NULL,
	device_name varchar(150) NOT NULL,
	company varchar(200) NULL,
    fleet varchar(200) NULL,
    asset_name varchar(150) NULL,
    wheel_config varchar(50) not null,
    image_url varchar(200) null,
    no_axles varchar(50) not null,
	reported_time timestamp not null,
    total_alerts int4 NOT NULL,
    alert_duration_hrs float8 NOT NULL,
    alert_distance float8 NOT NULL,
    max_alert_type_duration_hrs float8 NULL default 0,
    max_alert_type_distance_miles float8 NULL default 0,
    no_of_active_alerts_msg int4 NOT NULL,
    no_of_inactive_alerts_msg int4 NOT NULL,
    on_alert_duration int8 NOT NULL,
    on_alert_previous_active_duration int8 NOT NULL,
    off_alert_duration int8 NOT NULL,
    off_alert_previous_active_duration int8 NOT NULL,
    on_alerts_first_reported_time timestamp null,
    on_alerts_last_reported_time timestamp null,
    off_alerts_first_reported_time timestamp null,
    off_alerts_last_reported_time timestamp null,
    is_last_device_record int4 not null default '0',
    reported_time_dashboard_format varchar(20) NULL,
	reported_time_dashboard_group varchar(30) NULL,
	no_of_datapoints int4 NOT NULL,
	wheel_key varchar(100) not null,
	vehicle_key varchar(100) not null,
    asset_wheel_config_key varchar(100) not null,
	last_updated timestamp not null,
	run_period varchar(20) not null default '24_Hour',
	frequency varchar(20) not null default '24 Hour',
	PRIMARY KEY (location, alert_name, device_id, frequency, reported_time_dashboard_format)
);

CREATE TABLE public.dashboard_wheel_data_history (
    service varchar(100) not null,
	location varchar(100) not null,
	location_name varchar(150) not null,
	device_id varchar(100) NULL,
	asset_id varchar(120) NULL,
	asset_code varchar(120) NULL,
	device_name varchar(150) NOT NULL,
	company varchar(200) NULL,
    fleet varchar(200) NULL,
    asset_name varchar(150) NULL,
    wheel_config varchar(50) not null,
    image_url varchar(200) null,
    no_axles varchar(50) not null,
	reported_time timestamp not null,
	max_measured_temperature float8 NOT NULL,
	min_measured_temperature float8 NOT NULL,
	avg_measured_temperature float8 NOT NULL,
	max_battery_status int4 NOT NULL,
	min_battery_status int4 NOT NULL,
	avg_battery_status float8 NOT NULL,
	max_measured_pressure float8 NOT NULL,
	min_measured_pressure float8 NOT NULL,
	avg_measured_pressure float8 NOT NULL,
	max_temp_comp float8 NOT NULL,
	min_temp_comp float8 NOT NULL,
	avg_temp_comp float8 NOT NULL,
	low_pressure_value float8 NOT NULL DEFAULT 0,
    extra_low_pressure_value float8 NOT NULL DEFAULT 0,
    normal_pressure_value float8 NOT NULL DEFAULT 0,
    high_pressure_value float8 NOT NULL DEFAULT 0,
    low_temperature_value float8 NOT NULL DEFAULT 0,
    extra_low_temperature_value float8 NOT NULL DEFAULT 0,
    normal_temperature_value float8 NOT NULL DEFAULT 0,
    high_temperature_value float8 NOT NULL DEFAULT 0,
    is_last_device_record int4 not null default '0',
    reported_time_dashboard_format varchar(20) NULL,
	reported_time_dashboard_group varchar(30) NULL,
	no_of_datapoints int4 NOT NULL,
	wheel_key varchar(100) not null,
	vehicle_key varchar(100) not null,
    asset_wheel_config_key varchar(100) not null,
	last_updated timestamp not null,
	run_period varchar(20) not null default '24_Hour',
	frequency varchar(20) not null default '24 Hour',
	PRIMARY KEY (location, device_id, frequency, reported_time_dashboard_format)
);

CREATE TABLE public.dashboard_vehicle_data_history (
    service varchar(100) not null,
	device_id varchar(100) NULL,
	asset_id varchar(120) NULL,
	asset_code varchar(120) NULL,
	device_name varchar(150) NOT NULL,
	company varchar(100) NULL,
    fleet varchar(100) NULL,
    asset_name varchar(150) NULL,
    wheel_config varchar(50) not null,
    image_url varchar(200) null,
    no_axles varchar(50) not null,
	reported_time timestamp not null,
	last_active_reported_time timestamp not null,
    last_known_latitude float8 NOT NULL,
    last_known_longitude float8 NOT NULL,
    last_known_altitude int4 NOT NULL,
    last_known_speed int4 NOT NULL,
    last_known_heading int4 NOT NULL,
    first_active_reported_time timestamp not null,
    first_known_latitude float8 NOT NULL,
    first_known_longitude float8 NOT NULL,
    first_known_altitude int4 NOT NULL,
    first_known_speed int4 NOT NULL,
    first_known_heading int4 NOT NULL,
    distance_travelled float8 NOT NULL default '0.00',
    hrs_active float8 NOT NULL default '0.00',
    no_of_trips int8 not null default '0',
    device_has_alerts int8 not null default '0',
    is_last_device_record int4 not null default '0',
    reported_time_dashboard_format varchar(20) NULL,
	reported_time_dashboard_group varchar(30) NULL,
    vehicle_key varchar(100) not null,
    asset_wheel_config_key varchar(100) not null,
    last_updated timestamp not null,
    no_of_datapoints int4 NOT NULL,
    run_period varchar(20) not null default '24 Hour',
    frequency varchar(20) not null default '24 Hour',
	PRIMARY KEY (device_id,reported_time_dashboard_format,frequency)
);



---- Dashboard Views


CREATE OR REPLACE VIEW public.v_customer_device AS SELECT t.deviceid,
    'telematic'::text AS "table",
    'all'::text AS topic_prefix,
    'TELEMATIC'::text AS device_type,
        CASE at.type
            WHEN 'Truck'::text THEN 'Tractor'::text
            ELSE 'Trailer'::text
        END::character varying(255) AS asset_type,
    array_to_string(ARRAY( SELECT json_array_elements(wc.config::json) AS json_array_elements), ','::text) AS wheel_axle_config,
    ag.name AS fleet,
    h.deviceid AS reported_device_id,
    a.assetid,
    a.fsnnum,
    a.regnum
   FROM telematic t
     JOIN asset a ON a.assetid = t.assetid
     JOIN assettype at ON at.assettypeid = a.assettypeid
     JOIN wheelconfig wc ON wc.wheelconfigid = a.wheelconfigid
     LEFT JOIN cachedassetsbyhierarchy_location cl ON cl.assetid = a.assetid
     LEFT JOIN assetgroup ag ON ag.assetgroupid = cl.assetgrouplevel1
     LEFT JOIN hub h ON h.assetid = a.assetid
UNION ALL
 SELECT h.deviceid,
    'hub'::text AS "table",
    'all'::text AS topic_prefix,
    'HUB'::text AS device_type,
        CASE at.type
            WHEN 'Truck'::text THEN 'Tractor'::text
            ELSE 'Trailer'::text
        END::character varying(255) AS asset_type,
    array_to_string(ARRAY( SELECT json_array_elements(wc.config::json) AS json_array_elements), ','::text) AS wheel_axle_config,
    ag.name AS fleet,
    h.deviceid AS reported_device_id,
    a.assetid,
    a.fsnnum,
    a.regnum
   FROM hub h
     JOIN asset a ON a.assetid = h.assetid
     JOIN assettype at ON at.assettypeid = a.assettypeid
     JOIN wheelconfig wc ON wc.wheelconfigid = a.wheelconfigid
     LEFT JOIN cachedassetsbyhierarchy_location cl ON cl.assetid = a.assetid
     LEFT JOIN assetgroup ag ON ag.assetgroupid = cl.assetgrouplevel1;

CREATE OR REPLACE VIEW public.v_dashboard_vehicle_data_history
AS SELECT d.device_id,
    v.fsnnum,
    v.assetid,
    v.fleet AS company,
    v.fleet,
    v.asset_type,
    v.wheel_axle_config,
    concat('https://powerbistatic.azurewebsites.net/img/',
        CASE v.wheel_axle_config
            WHEN '2,2,2'::text THEN 'TractorSuper'::text
            WHEN '2,2'::text THEN 'TractorSuper'::text
            ELSE concat(v.asset_type, 's')
        END, '_', replace(v.wheel_axle_config, ','::text, '_'::text), '.JPG') AS image_url,
    '0'::text AS no_axles,
    d.reported_time,
    d.last_active_reported_time,
    d.last_known_latitude,
    d.last_known_longitude,
    d.last_known_altitude,
    d.last_known_speed,
    d.last_known_heading,
    d.first_active_reported_time,
    d.first_known_latitude,
    d.first_known_longitude,
    d.first_known_altitude,
    d.first_known_speed,
    d.first_known_heading,
    d.distance_travelled,
    d.hrs_active,
    d.reported_time_dashboard_format,
    d.reported_time_dashboard_group,
    d.last_updated,
    d.frequency,
    concat(d.device_id, v.asset_type, d.frequency) AS vehicle_key,
    concat(v.asset_type, v.wheel_axle_config) AS asset_wheel_config_key,
    d.is_last_device_record,
    d.device_has_alerts,
    d.no_of_trips
   FROM dashboard_vehicle_data_history d
     JOIN v_customer_device v ON v.deviceid::text = d.device_id::text
WHERE d.last_updated >= (timezone('UTC'::text, now()) - '01:00:00'::interval) AND d.last_updated <= (timezone('UTC'::text, now()) + '01:00:00'::interval);

CREATE OR REPLACE VIEW public.v_dashboard_vehicle_data_current
AS SELECT d.device_id,
    v.fsnnum,
    v.assetid,
    v.fleet AS company,
    v.fleet,
    v.asset_type,
    v.wheel_axle_config,
    concat('https://powerbistatic.azurewebsites.net/img/',
        CASE v.wheel_axle_config
            WHEN '2,2,2'::text THEN 'TractorSuper'::text
            WHEN '2,2'::text THEN 'TractorSuper'::text
            ELSE concat(v.asset_type, 's')
        END, '_', replace(v.wheel_axle_config, ','::text, '_'::text), '.JPG') AS image_url,
    '0'::text AS no_axles,
    d.reported_time,
    d.latitude,
    d.longitude,
    d.altitude,
    d.gps_timestamp,
    d.measured_speed,
    d.measured_heading,
    d.last_updated,
    d.odometer,
    d.odometer_total,
    d.device_has_alerts,
    d.alerts_duration_hrs,
    d.odometer_in_miles,
    d.odometer_total_in_miles,
    concat(d.device_id, v.asset_type, 'Last  24 Hours') AS vehicle_key
   FROM dashboard_vehicle_data_current d
     JOIN v_customer_device v ON v.deviceid::text = d.device_id::text;

CREATE OR REPLACE VIEW public.v_dashboard_wheel_data_history
AS SELECT d.device_id,
    v.fsnnum,
    v.assetid,
    v.fleet AS company,
    v.fleet,
    v.asset_type,
    v.wheel_axle_config,
    concat('https://powerbistatic.azurewebsites.net/img/',
        CASE v.wheel_axle_config
            WHEN '2,2,2'::text THEN 'TractorSuper'::text
            WHEN '2,2'::text THEN 'TractorSuper'::text
            ELSE concat(v.asset_type, 's')
        END, '_', replace(v.wheel_axle_config, ','::text, '_'::text), '.JPG') AS image_url,
    '0'::text AS no_axles,
    d.location,
    COALESCE(wd.description, d.location) AS location_name,
    d.reported_time,
    d.max_measured_temperature,
    d.min_measured_temperature,
    d.avg_measured_temperature,
    d.max_battery_status,
    d.min_battery_status,
    d.avg_battery_status,
    d.max_measured_pressure,
    d.min_measured_pressure,
    d.avg_measured_pressure,
    d.max_temp_comp,
    d.min_temp_comp,
    d.avg_temp_comp,
    concat(d.device_id, v.asset_type, d.location) AS wheel_key,
    concat(d.device_id, v.asset_type, d.frequency) AS vehicle_key,
    concat(v.asset_type, v.wheel_axle_config) AS asset_wheel_config_key,
    d.reported_time_dashboard_format,
    d.reported_time_dashboard_group,
    d.last_updated,
    d.frequency,
    d.extra_low_pressure_value,
    d.low_pressure_value,
    d.normal_pressure_value,
    d.high_pressure_value,
    d.extra_low_temperature_value,
    d.low_temperature_value,
    d.normal_temperature_value,
    d.high_temperature_value,
    d.is_last_device_record
   FROM dashboard_wheel_data_history d
     JOIN v_customer_device v ON v.deviceid::text = d.device_id::text
     LEFT JOIN wheeldescription wd ON wd.isolocation::text = d.location::text AND array_to_string(ARRAY( SELECT json_array_elements(wd.wheelconfig::json) AS json_array_elements), ','::text) = v.wheel_axle_config AND (wd.assettype::text = 'truck'::text AND v.asset_type::text = 'Tractor'::text OR wd.assettype::text = 'trailer'::text AND v.asset_type::text = 'Trailer'::text)
  WHERE d.last_updated >= (timezone('UTC'::text, now()) - '01:00:00'::interval) AND d.last_updated <= (timezone('UTC'::text, now()) + '01:00:00'::interval);

CREATE OR REPLACE VIEW public.v_dashboard_wheel_data_current
AS SELECT d.device_id,
    v.fsnnum,
    v.assetid,
    v.fleet AS company,
    v.fleet,
    v.asset_type,
    v.wheel_axle_config,
    concat('https://powerbistatic.azurewebsites.net/img/',
        CASE v.wheel_axle_config
            WHEN '2,2,2'::text THEN 'TractorSuper'::text
            WHEN '2,2'::text THEN 'TractorSuper'::text
            ELSE concat(v.asset_type, 's')
        END, '_', replace(v.wheel_axle_config, ','::text, '_'::text), '.JPG') AS image_url,
    '0'::text AS no_axles,
    d.reported_time,
    d.location,
    COALESCE(wd.description, d.location) AS location_name,
    d.measured_temperature,
    d.measured_temperature_c,
    d.measured_temperature_f,
    d.battery_status,
    d.measured_pressure,
    d.measured_pressure_psi,
    d.temp_comp,
    d.low_pressure_value,
    d.extra_low_pressure_value,
    d.normal_pressure_value,
    d.low_temperature_value,
    d.extra_low_temperature_value,
    d.normal_temperature_value,
    concat(d.device_id, v.asset_type, d.location) AS wheel_key,
    concat(d.device_id, v.asset_type, 'Last  24 Hours') AS vehicle_key,
    concat(v.asset_type, v.wheel_axle_config) AS asset_wheel_config_key,
    d.last_updated
   FROM dashboard_wheel_data_current d
     JOIN v_customer_device v ON v.deviceid::text = d.device_id::text
     LEFT JOIN wheeldescription wd ON wd.isolocation::text = d.location::text AND array_to_string(ARRAY( SELECT json_array_elements(wd.wheelconfig::json) AS json_array_elements), ','::text) = v.wheel_axle_config AND (wd.assettype::text = 'truck'::text AND v.asset_type::text = 'Tractor'::text OR wd.assettype::text = 'trailer'::text AND v.asset_type::text = 'Trailer'::text);


CREATE OR REPLACE VIEW public.v_dashboard_wheel_alert_data_history
AS SELECT d.device_id,
    v.fsnnum,
    v.assetid,
    v.fleet AS company,
    v.fleet,
    v.asset_type,
    v.wheel_axle_config,
    concat('https://powerbistatic.azurewebsites.net/img/',
        CASE v.wheel_axle_config
            WHEN '2,2,2'::text THEN 'TractorSuper'::text
            WHEN '2,2'::text THEN 'TractorSuper'::text
            ELSE concat(v.asset_type, 's')
        END, '_', replace(v.wheel_axle_config, ','::text, '_'::text), '.JPG') AS image_url,
    '0'::text AS no_axles,
    d.location,
    COALESCE(wd.description, d.location) AS location_name,
    d.resource,
    d.alert_name,
    d.reported_time,
    d.total_alerts,
    d.alert_duration_hrs,
    d.alert_distance,
    d.max_alert_type_duration_hrs,
    d.max_alert_type_distance_miles,
    d.no_of_active_alerts_msg,
    d.no_of_inactive_alerts_msg,
    d.on_alert_duration,
    d.on_alert_previous_active_duration,
    d.on_alerts_first_reported_time,
    d.on_alerts_last_reported_time,
    d.off_alerts_first_reported_time,
    d.off_alerts_last_reported_time,
    concat(d.device_id, v.asset_type, d.location) AS wheel_key,
    concat(d.device_id, v.asset_type, d.frequency) AS vehicle_key,
    concat(v.asset_type, v.wheel_axle_config) AS asset_wheel_config_key,
    d.reported_time_dashboard_format,
    d.reported_time_dashboard_group,
    d.last_updated,
    d.frequency,
    d.is_last_device_record
   FROM dashboard_wheel_alert_data_history d
     JOIN v_customer_device v ON v.deviceid::text = d.device_id::text
     LEFT JOIN wheeldescription wd ON wd.isolocation::text = d.location::text AND array_to_string(ARRAY( SELECT json_array_elements(wd.wheelconfig::json) AS json_array_elements), ','::text) = v.wheel_axle_config AND (wd.assettype::text = 'truck'::text AND v.asset_type::text = 'Tractor'::text OR wd.assettype::text = 'trailer'::text AND v.asset_type::text = 'Trailer'::text)
  WHERE d.last_updated >= (timezone('UTC'::text, now()) - '01:00:00'::interval) AND d.last_updated <= (timezone('UTC'::text, now()) + '01:00:00'::interval);


CREATE OR REPLACE VIEW public.v_dashboard_wheel_alert_data_current
AS SELECT d.device_id,
    v.fsnnum,
    v.assetid,
    v.fleet AS company,
    v.fleet,
    v.asset_type,
    v.wheel_axle_config,
    concat('https://powerbistatic.azurewebsites.net/img/',
        CASE v.wheel_axle_config
            WHEN '2,2,2'::text THEN 'TractorSuper'::text
            WHEN '2,2'::text THEN 'TractorSuper'::text
            ELSE concat(v.asset_type, 's')
        END, '_', replace(v.wheel_axle_config, ','::text, '_'::text), '.JPG') AS image_url,
    '0'::text AS no_axles,
    d.resource,
    d.alert_name,
    d.location,
    COALESCE(wd.description, d.location) AS location_name,
    d.reported_time,
    d.active,
    d.duration,
    d.previous_active_duration,
    d.category,
    concat(d.device_id, v.asset_type, d.location) AS wheel_key,
    concat(d.device_id, v.asset_type, 'Last  24 Hours') AS vehicle_key,
    concat(v.asset_type, v.wheel_axle_config) AS asset_wheel_config_key,
    d.last_updated,
    d.distance_travel_with_alert
   FROM dashboard_wheel_alert_current d
     JOIN v_customer_device v ON v.deviceid::text = d.device_id::text
     LEFT JOIN wheeldescription wd ON wd.isolocation::text = d.location::text AND array_to_string(ARRAY( SELECT json_array_elements(wd.wheelconfig::json) AS json_array_elements), ','::text) = v.wheel_axle_config AND (wd.assettype::text = 'truck'::text AND v.asset_type::text = 'Tractor'::text OR wd.assettype::text = 'trailer'::text AND v.asset_type::text = 'Trailer'::text);


CREATE OR REPLACE VIEW public.v_vehicle_data_bridge
AS SELECT v_dashboard_vehicle_data_history.vehicle_key,
    v_dashboard_vehicle_data_history.device_id,
    v_dashboard_vehicle_data_history.fsnnum,
    v_dashboard_vehicle_data_history.asset_type,
    v_dashboard_vehicle_data_history.fleet
   FROM v_dashboard_vehicle_data_history
UNION
 SELECT v_dashboard_wheel_data_current.vehicle_key,
    v_dashboard_wheel_data_current.device_id,
    v_dashboard_wheel_data_current.fsnnum,
    v_dashboard_wheel_data_current.asset_type,
    v_dashboard_wheel_data_current.fleet
   FROM v_dashboard_wheel_data_current
UNION
 SELECT v_dashboard_wheel_alert_data_current.vehicle_key,
    v_dashboard_wheel_alert_data_current.device_id,
    v_dashboard_wheel_alert_data_current.fsnnum,
    v_dashboard_wheel_alert_data_current.asset_type,
    v_dashboard_wheel_alert_data_current.fleet
   FROM v_dashboard_wheel_alert_data_current;

CREATE OR REPLACE VIEW public.v_wheel_data_bridge
AS SELECT v_dashboard_wheel_data_history.wheel_key,
    v_dashboard_wheel_data_history.device_id,
    v_dashboard_wheel_data_history.fsnnum,
    v_dashboard_wheel_data_history.asset_type,
    v_dashboard_wheel_data_history.fleet
   FROM v_dashboard_wheel_data_history
UNION
 SELECT v_dashboard_wheel_data_current.wheel_key,
    v_dashboard_wheel_data_current.device_id,
    v_dashboard_wheel_data_current.fsnnum,
    v_dashboard_wheel_data_current.asset_type,
    v_dashboard_wheel_data_current.fleet
   FROM v_dashboard_wheel_data_current
UNION
 SELECT v_dashboard_wheel_alert_data_current.wheel_key,
    v_dashboard_wheel_alert_data_current.device_id,
    v_dashboard_wheel_alert_data_current.fsnnum,
    v_dashboard_wheel_alert_data_current.asset_type,
    v_dashboard_wheel_alert_data_current.fleet
   FROM v_dashboard_wheel_alert_data_current;