package utils

import com.sensata.data_office.data.{ActiveAlertNotification, AssetActivityNotification}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.catalyst.ScalaReflection
import org.apache.spark.sql.functions.{col, current_timestamp, floor, from_json, lit, struct, to_json}
import org.apache.spark.sql.types.StructType

import java.io.File

class utilityMethods extends SparkSessionTestWrapper {

  /**
   * Mocked global devices dataframe
   */
  def updateCustomerDimCacheMocked(): DataFrame = {
    loadCSVAsDataframe("global_devices_dev.csv")
      .union(
        loadCSVAsDataframe("global_devices_staging.csv")
      )
      .union(
        loadCSVAsDataframe("global_devices_live.csv")
      )
  }

  def FetchCustomerDeviceFromDatabaseMocked(): DataFrame = {
    loadCSVAsDataframe("global_devices_dev.csv")
      .union(
        loadCSVAsDataframe("global_devices_staging.csv")
      )
      .union(
        loadCSVAsDataframe("global_devices_live.csv")
      )

  }

  def getEnvVariableMocked(key: String):String = {
    subEnv.getOrElse(key,"dev")
  }

  def loadTextAsDataframe(filename: String): DataFrame = {
    spark
      .read
      .text(
        s"file:///${getTestDataPathRelativeToCurrentPath(filename)}"
      )
  }

  def loadActiveAlertMessage(filename: String):DataFrame = {
    val tmpdf = loadJsonAsDataframe(filename)
      .select(col("value.*"))

    tmpdf
      .withColumn(
        "value"
        , to_json(struct(
          tmpdf.columns.map(col(_)):_*
        ))
      )
      .select(col("value"))
  }

  /**
   *
   * @param filename
   * @return
   */
  def loadJsonAsDataframe(filename: String): DataFrame = {
    spark
      .read
      .format("json")
      .load(
        s"file:///${getTestDataPathRelativeToCurrentPath(filename)}"
      )
  }

  /**
   *
   * @param filename
   * @return
   */
  def loadCSVAsDataframe(filename: String): DataFrame = {
    spark
      .read
      .format("csv")
      .option("header", "true")
      .option("quote", "\"")
      .option("escape", "\"")
      .load(
        s"file:///${getTestDataPathRelativeToCurrentPath(filename)}"
      )
  }

  def loadAssetLastActivityDatabaseStub(filename: String) = {
    loadCSVAsDataframe(filename)
      .select(
      from_json(col("activity_state") cast "string"
        , ScalaReflection.schemaFor[AssetActivityNotification].dataType.asInstanceOf[StructType]
      ) as "events"
    ).select(col("events.*"))
  }

  def loadAssetLastAlertDatabaseStub(filename: String) = {
    loadCSVAsDataframe(filename)
      .select(
        from_json(col("alert_state") cast "string"
          , ScalaReflection.schemaFor[ActiveAlertNotification].dataType.asInstanceOf[StructType]
        ) as "events"
      ).select(col("events.*"))
  }

  def loadKafkaTopicData(filename: String): DataFrame = {
    loadCSVAsDataframe(filename)
  }
  /**
   * get test data relative path
   * @param filename
   * @return
   */
  def getTestDataPathRelativeToCurrentPath(filename: String): String = {
    s"${new File(".").getCanonicalPath}/src/test/resources/data/$filename"
  }

  val subEnv: Map[String,String] = Map(
    "ENVIRONMENT" -> "dev",
    "ALERT_EVENT_DELTA_HRS" -> "16"
  )

  def createEmptyActiveAlertRecord() = {
    spark.emptyDataFrame.select(
      lit(null) as "asset_id"
      , lit(null) as "asset_code"
      , lit(null) as "location"
      , lit("events/warnings/pressure") as "resource"
      , lit(-1) as "active"
      , lit(-1) as "category"
      , current_timestamp() as "reported_time"
      , lit(0) as "device_duration"
      , lit(0) as "calc_duration"
      , lit(0) as "est_duration"
      , lit(0) as "odometer_miles"
      , lit(0) as "odometer_total_miles"
      , lit(0) as "distance_travel"
      , lit(0) as "distance_travel_with_alert"
      , lit(0) as "old_active"
      , lit(0) as "old_category"
      , current_timestamp() as "old_reported_time"
      , lit(0) as "old_odometer_miles"
      , lit(0) as "old_odometer_total_miles"
      , lit(0) as "old_distance_travel"
      , lit(0) as "old_distance_travel_with_alert"
      , lit(0) as "old_calc_duration"
      , lit("false") as "state_changed"
      , lit(null) cast "timestamp" as "event_start_time"
      , lit(null) cast "double" as "pressure"
      , lit(null) cast "double" as "pressure_psi"
      , lit(null) cast "double" as "temperature"
      , lit(null) cast "double" as "temperature_f"
      , lit(null) cast "double" as "temp_comp_pressure"
      , current_timestamp() as "last_updated"
    )
      .withColumn("checkpoint_timestamp",floor( lit( System.currentTimeMillis() / (3600 * 1000) ) ) * 3600)
  }

  def createEmptyActivityRecord() = {
    spark.emptyDataFrame.select(
      lit(null) as "asset_code"
      , current_timestamp() as "reported_time"
      , lit(0) as "measured_speed"
      , lit(0) as "measured_heading"
      , lit(-1) as "odometer"
      , lit(-1) as "odometer_total"
      , lit(-1) as "odometer_miles"
      , lit(-1) as "odometer_total_miles"
      , lit(null) as "atis_state"
      , lit(null) as "atis_reported_time"
      , lit(current_timestamp()) as "prev_reported_time"
      , lit(-1) as "prev_odometer"
      , lit(-1) as "prev_odometer_total"
      , lit(-1) as "prev_odometer_miles"
      , lit(-1) as "prev_odometer_total_miles"
      , lit(null) as "prev_atis_state"
      , lit(null) as "prev_atis_reported_time"
      , lit(-1) as "active_trip"
      , lit(-1) as "distance_travelled"
      , lit(-1) as "active_duration"
      , lit(-1) as "total_duration"
      , lit(-1) as "total_distance_travelled"
      , lit("false") as "moving"
      , lit(null) as "ttl_active"
      , lit(null) as "kl15_pin_state"
      , current_timestamp() as "last_updated"
    )
      .withColumn("checkpoint_timestamp",floor( lit( System.currentTimeMillis() / (3600 * 1000) ) ) * 3600)
  }
}
