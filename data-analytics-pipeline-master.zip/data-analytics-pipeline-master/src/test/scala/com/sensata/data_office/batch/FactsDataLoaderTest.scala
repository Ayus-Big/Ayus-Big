package com.sensata.data_office.batch

import com.sensata.data_office.batch.jobs.FactsDataLoader.runFactDataLoader
import com.sensata.data_office.data.{ProcessedAlertSnapshot, ProcessedGPSRecord, ProcessedWheelRecord, ProcessedWheelWarningRecord}
import com.sensata.data_office.utilities.PipelineUtil
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.catalyst.ScalaReflection
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StructType
import org.mockito.ArgumentMatchersSugar.{any, eqTo}
import org.mockito.{IdiomaticMockito, MockitoSugar}
import org.scalatest.{FunSpec, Ignore}
import utils.{SparkSessionTestWrapper, utilityMethods}

import java.sql.Timestamp
import java.time.{LocalDateTime, LocalTime}

@Ignore
class FactsDataLoaderTest extends FunSpec with SparkSessionTestWrapper with IdiomaticMockito{

  /**
   * Mocked Kafka Writer for displaying final dataframe
   *
   * @param df
   * @param write_mode
   * @param kafkaOptions
   * @param kafka_topic
   */

  var resultsDf = spark.emptyDataFrame
  val utils = new utilityMethods()

  def writeDataFrameToBlobStorageMocked(df: DataFrame, write_mode: String, target_path: String): Unit = {
    resultsDf = df
  }


  describe("Fact Data Loader Test") {
    it("Test 1 - Verifying Fact Data Loader Test") {
      withObjectMocked[PipelineUtil.type] {
        PipelineUtil.spark returns spark
        PipelineUtil.environment = "dev"
        PipelineUtil.active_alerts_prev_state_topic returns "alert-past-notification"
        PipelineUtil.asset_prev_activity_topic returns "asset-past-activity-notification"

        PipelineUtil.updateCustomerDimCacheFromDatabase() returns utils.updateCustomerDimCacheMocked()

        MockitoSugar.when(
          PipelineUtil.updateCustomerDimCache(any[String])
        ) thenAnswer(utils.updateCustomerDimCacheMocked(), "earliest")

        MockitoSugar.when(
          PipelineUtil.loadDataFrameAndOffsetsFromKafka(eqTo[String]("alert-past-notification"), any[StructType], any[String])
        ) thenAnswer(utils.createEmptyActiveAlertRecord(), "earliest")

        MockitoSugar.when(
          PipelineUtil.loadDataFrameAndOffsetsFromKafka(eqTo[String]("asset-past-activity-notification"), any[StructType], any[String])
        ) thenAnswer(utils.createEmptyActivityRecord(), "earliest")


        MockitoSugar.when(PipelineUtil.getEnvVariable("ENVIRONMENT")) thenAnswer utils.getEnvVariableMocked("ENVIRONMENT")
        MockitoSugar.when(PipelineUtil.dedupToLatest(any[DataFrame])) thenCallRealMethod()
        MockitoSugar.when(PipelineUtil.dedupActivityToLatest(any[DataFrame])) thenCallRealMethod()

        MockitoSugar.when(
          PipelineUtil.writeDataFrameToBlobStorage(
            any[DataFrame], any[String], any[String]
          )
        ) thenAnswer writeDataFrameToBlobStorageMocked _

       // val analytics_schema = ScalaReflection.schemaFor[AnalyticWarningEventData].dataType.asInstanceOf[StructType]
        val analytics_schema = ScalaReflection.schemaFor[ProcessedAlertSnapshot].dataType.asInstanceOf[StructType]
        val wheel_data_schema = ScalaReflection.schemaFor[ProcessedWheelRecord].dataType.asInstanceOf[StructType]
        val alert_data_schema = ScalaReflection.schemaFor[ProcessedWheelWarningRecord].dataType.asInstanceOf[StructType]
        val gps_data_schema = ScalaReflection.schemaFor[ProcessedGPSRecord].dataType.asInstanceOf[StructType]


        val cur_timestamp: Timestamp =  Timestamp.valueOf(
          LocalDateTime.of(LocalDateTime.now().toLocalDate(), LocalTime.of(23,59,59) )
        )
        println("*************************cur_timestamp*********************")
        print(cur_timestamp)

        val start_timestamp: Timestamp =  Timestamp.valueOf(
          LocalDateTime.of(LocalDateTime.now().toLocalDate(), LocalTime.now() )
        )
        println(" ")
        println("*************************start_timestamp*********************")
        print(start_timestamp)

        val cur_timestamp_millis = ( System.currentTimeMillis() / (3600 * 1000) ).floor.toInt * 3600
        println(" ")
        println("*************************cur_timestamp_millis*********************")
        print(cur_timestamp_millis)

        val nextday_timestamp = cur_timestamp_millis + 86400
        println(" ")
        println("*************************nextday_timestamp*********************")
        print(nextday_timestamp)

        val consumed_timestamp_delta = cur_timestamp_millis - (60 * (24*3600))
        println(" ")
        println("*************************consumed_timestamp_delta*********************")
        print(consumed_timestamp_delta)
        println(" ")

       /* val end_timestamp = cur_timestamp_millis - (3600)
        println("/")
        println("*************************end_timestamp*********************")
        print(end_timestamp)*/


        val unit_of_run = "7 Days"

        val start_time_r = lit(cur_timestamp) - expr(s"INTERVAL ${unit_of_run}")
        val end_time_r = lit(cur_timestamp) + expr(s"INTERVAL 1 ${unit_of_run.split(" ")(1)}")



      //  print(start_time_r)
      //  print(end_time_r)

        val WheelDf = utils.loadCSVAsDataframe("wheel_data_for_fact.csv")

      /*  val WheelDf_final = WheelDf.select(
          from_json(col("value") cast "string"
            , wheel_data_schema
          ) as "events"
        )
          .select(col("events.*"))*/

        println("**************************WheelDf_final***********************************")
        WheelDf.show(5,false)

        val GPSDf = utils.loadCSVAsDataframe("gps_data_for_fact.csv")

       /* val GPSDf_final = GPSDf.select(
          from_json(col("value") cast "string"
            , gps_data_schema
          ) as "events"
        )
          .select(col("events.*"))*/

        println("**************************GPSDf***********************************")
        GPSDf.show(5,false)

       // val AlertDf = utils.loadCSVAsDataframe("alert_data_for_fact_battery.csv")
       val AlertDf = utils.loadCSVAsDataframe("alert_data_for_fact.csv")

      /*  val AlertDf_final = AlertDf.select(
          from_json(col("value") cast "string"
            , alert_data_schema
          ) as "events"
        )
          .select(col("events.*"))*/
        println("**************************AlertDf***********************************")
        AlertDf.show(5,false)



        val AlertSnapShotDf = utils.loadCSVAsDataframe("alert_snap_msg.csv")

        //   val alert_final = df.select(struct(col("data"), analytics_schema ) )
        val alert_snap_final = AlertSnapShotDf.select(
          from_json(col("value") cast "string"
            , analytics_schema
          ) as "events"
        )
          .select(col("events.*"))

        println("**************************Alert_snap_final***********************************")
        alert_snap_final.show(5,false)

        val LeakDf = utils.loadCSVAsDataframe("leak_fact.csv")
        println("**************************leak_fact***********************************")
        LeakDf.show(5,false)

        runFactDataLoader(start_time_r,end_time_r,WheelDf,GPSDf,AlertDf,alert_snap_final,LeakDf,unit_of_run)

        //  assert(validateDf.where($"asset_code" === "STAGING-2").count() == 5, "asset_code correctly set")

      }
    }

  }
}
