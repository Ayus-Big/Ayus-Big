package com.sensata.data_office.pipeline.queries

import com.sensata.data_office.data._
import com.sensata.data_office.utilities.PipelineUtil
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.catalyst.ScalaReflection
import org.apache.spark.sql.functions.{col, from_json}
import org.apache.spark.sql.types.StructType
import org.mockito.ArgumentMatchersSugar.{any, eqTo}
import org.mockito.{IdiomaticMockito, MockitoSugar}
import org.scalatest.{FunSpec, Ignore}
import utils.{SparkSessionTestWrapper, utilityMethods}


@Ignore
class CustomerDataPublisherTest extends FunSpec with SparkSessionTestWrapper with IdiomaticMockito {
  /**
   * Mocked Kafka Writer for displaying final dataframe
   *
   * @param df
   * @param write_mode
   * @param kafkaOptions
   * @param kafka_topic
   */

  var resultsDf = spark.emptyDataFrame

  def writeDataFrameToKafkaMocked(df: DataFrame, write_mode: String, kafkaOptions: Map[String, String]): Unit = {

    //  if( df.where($"key" contains("curated")).count() > 0) {
    resultsDf = df
    //  }
  }

  val utils = new utilityMethods()

  describe("CustomerDataPublisher Data Test") {
    it("Test 1 - Processed Wheel data and load into Postgres DB") {
      withObjectMocked[PipelineUtil.type] {
        PipelineUtil.spark returns spark
        PipelineUtil.environment = "dev"

        MockitoSugar.when(PipelineUtil.getEnvVariable("ENVIRONMENT")) thenAnswer utils.getEnvVariableMocked("ENVIRONMENT")
        MockitoSugar.when(
          PipelineUtil.writeDataFrameToKafka(
            any[DataFrame], any[String], any[Map[String, String]]
          )
        ) thenAnswer writeDataFrameToKafkaMocked _

        val wheel_data_scheam = ScalaReflection.schemaFor[ProcessedWheelRecord].dataType.asInstanceOf[StructType]
        val testDf = utils.loadCSVAsDataframe("wheel_customer_pub.csv")
        testDf.show(false)

        val finalDf = testDf
          .where(col("value") cast "string" rlike (".*\"service\":\"tpms-curated\".*"))
          .where(col("value") cast "string" rlike (".*\"location\":.*"))
          .where(col("value") cast "string" rlike (".*\"device_id\":.*"))
          .where(
            (col("value") cast "string" rlike (".*\"battery_status\":.*"))
              || (col("value") cast "string" rlike (".*\"measured_pressure\":.*"))
              || (col("value") cast "string" rlike (".*\"measured_temperature\":.*"))
          )
          .where(col("value") cast "string" rlike (".*\"consumed_timestamp\":.*"))
          .select(
            from_json(col("value") cast "string"
              , wheel_data_scheam
            ) as "events"
          )
          .select(col("events.*"))
          .filter( // only send records with temperature and pressure to the database
            (col("measured_pressure").isNotNull)
              && (col("measured_temperature").isNotNull)
              && (col("battery_status").isNotNull)
          )


        println("*************************************************finalDf wheel****************************************")
        finalDf.show(false)

        /* finaldf.write.format("csv").option("header","true")
          .save("C://Users//x3079432//Desktop//CustometPub//wheel_25thOct")*/

        CustomerDataPublisher.doPublishCuratedWheelRecords(finalDf, 1)

        println("*************************************************resultsDf wheel data****************************************")
        resultsDf.show(false)
        assert(resultsDf.columns.contains("key"))
        assert(resultsDf.columns.contains("value"))
        assert(resultsDf.columns.contains("topic"))


      }
    }
    ignore("Test 2 - Processed Vehicle data and load into Postgres DB") {
      withObjectMocked[PipelineUtil.type] {
        PipelineUtil.spark returns spark
        PipelineUtil.environment = "dev"

        MockitoSugar.when(PipelineUtil.getEnvVariable("ENVIRONMENT")) thenAnswer utils.getEnvVariableMocked("ENVIRONMENT")
        MockitoSugar.when(
          PipelineUtil.writeDataFrameToKafka(
            any[DataFrame], any[String], any[Map[String, String]]
          )
        ) thenAnswer writeDataFrameToKafkaMocked _

        val position_data_scheam = ScalaReflection.schemaFor[ProcessedGPSRecord].dataType.asInstanceOf[StructType]
        val testDf = utils.loadCSVAsDataframe("vehicle_customer_pub.csv")
        //  testDf.show(false)

        val finalDf = testDf
          .where(col("value") cast "string" rlike (".*\"service\":\"gnss-curated\".*"))
          .where(col("value") cast "string" rlike (".*\"consumed_timestamp\":.*"))
          .select(
            from_json(col("value") cast "string"
              , position_data_scheam
            ) as "events"
          ).select(col("events.*"))
          .na.fill(
          Map(
            "service" -> "N/A",
            "reported_time" -> "N/A",
            "schema_version" -> "N/A",
            "device_id" -> "N/A",
            "device_name" -> "N/A",
            "wheel_config" -> "N/A",
            "no_axles" -> "N/A",
          )
        )

        /*println("*************************************************finalDf vehicle****************************************")
        finalDf.show(false)*/

        val finalDf1 = utils.loadCSVAsDataframe("vehicle_customer_pub1.csv")
        println("*************************************************finalDf1 vehicle****************************************")
        finalDf1.show(false)

        val finalDf2 = finalDf1.filter(col("latitude") === "null")
        println("*************************************************finalDf2 vehicle****************************************")
        finalDf2.show(false)

        /* finaldf.write.format("csv").option("header","true")
           .save("C://Users//x3079432//Desktop//CustometPub//wheel_25thOct")*/

        CustomerDataPublisher.doPublishCuratedVehicleRecords(finalDf2, 1)

        println("*************************************************resultsDf vehicle data****************************************")
        resultsDf.show(false)
        assert(resultsDf.columns.contains("key"))
        assert(resultsDf.columns.contains("value"))
        assert(resultsDf.columns.contains("topic"))


      }
    }

  }
}