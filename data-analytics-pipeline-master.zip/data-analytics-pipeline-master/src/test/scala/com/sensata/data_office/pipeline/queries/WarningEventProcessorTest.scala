package com.sensata.data_office.pipeline.queries

import com.sensata.data_office.data._
import com.sensata.data_office.utilities.PipelineUtil
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.catalyst.ScalaReflection
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StructType
import org.mockito.ArgumentMatchersSugar.{any, eqTo}
import org.mockito.{IdiomaticMockito, MockitoSugar}
import org.scalatest.FunSpec
import utils.{SparkSessionTestWrapper, utilityMethods}



 class WarningEventProcessorTest extends FunSpec with SparkSessionTestWrapper with IdiomaticMockito {

   import spark.implicits._

   /**
    * Mocked Kafka Writer for displaying final dataframe
    *
    * @param df
    * @param write_mode
    * @param kafkaOptions
    * @param kafka_topic
    */

   var resultsDf = spark.emptyDataFrame
   val utils = new utilityMethods()

   def writeDataFrameToKafkaTopicMocked(df: DataFrame, write_mode: String, kafkaOptions: Map[String, String], kafka_topic: String): Unit = {
     resultsDf = df
   }

   def loadWheelTPMSDataMocked(filename: String): DataFrame = {
     try {
       utils.loadCSVAsDataframe(filename) /*spark.read
         .format("kafka")
         .options(kafkaConfig)
         .option("startingOffsets",alerts_kafka_offset)
         .option("subscribe", compact_curated_tpms_records_topic)
         .load()*/
         .select(
           get_json_object($"value" cast "string", "$.asset_code") as "asset_code"
           , get_json_object($"value" cast "string", "$.device_id") as "device_id"
           , get_json_object($"value" cast "string", "$.location") as "location"
           , get_json_object($"value" cast "string", "$.measured_temperature_c") cast ("double") as "measured_temperature_c"
           , get_json_object($"value" cast "string", "$.measured_temperature_f") cast ("double") as "measured_temperature_f"
           , get_json_object($"value" cast "string", "$.measured_pressure_psi") cast ("double") as "measured_pressure_psi"
           , get_json_object($"value" cast "string", "$.battery_status") cast ("double") as "battery_status"
           , get_json_object($"value" cast "string", "$.reported_time") cast ("timestamp") as "reported_time"
           , get_json_object($"value" cast "string", "$.last_updated") cast ("timestamp") as "last_updated"
         )
         .withColumn("resource", lit("wheel-tpms-data"))
     } catch {
       case _ => spark.emptyDataFrame.select(
         lit(null) as "asset_code"
         , lit(null) as "device_id"
         , lit(null) as "location"
         , lit(null) as "measured_temperature_c"
         , lit(null) as "measured_temperature_f"
         , lit(null) as "measured_pressure_psi"
         , lit(null) as "battery_status"
         , lit(null) as "reported_time"
         , current_timestamp() as "last_updated"
         , lit("wheel-tpms-data") as "resource"
       )
     }
   }

   def dedupToLatestMocked(df: DataFrame) = {
     df.withColumn(
       "rec_rank"
       , rank over Window.partitionBy("asset_code", "location", "resource").orderBy(asc("reported_time"), asc("last_updated"))
     )
       .withColumn(
         "max_rank"
         , max("rec_rank") over Window.partitionBy("asset_code", "location", "resource")
       )
       .where($"max_rank" === $"rec_rank") // select the last record
       .drop("max_rank", "rec_rank")
       .dropDuplicates()
   }


   describe("Warning Event Processed Data Test") {
     it("Test 1 - Verifying Warning event process for curated alerts Topic") {
       withObjectMocked[PipelineUtil.type] {
         PipelineUtil.spark returns spark
         PipelineUtil.environment = "dev"
         PipelineUtil.active_alerts_prev_state_topic returns "alert-past-notification"
         PipelineUtil.asset_prev_activity_topic returns "asset-past-activity-notification"

         PipelineUtil.updateCustomerDimCacheFromDatabase() returns utils.updateCustomerDimCacheMocked()
         PipelineUtil.FetchCustomerDeviceFromDatabase() returns utils.FetchCustomerDeviceFromDatabaseMocked()

         MockitoSugar.when(
           PipelineUtil.updateCustomerDimCache(any[String])
         ) thenAnswer(utils.updateCustomerDimCacheMocked(), "earliest")

         PipelineUtil.getAssetAlertStateFromDatabaseCache returns utils.loadAssetLastAlertDatabaseStub("cache/asset_alert_activity.csv")
         PipelineUtil.getAssetActivityStateFromDatabaseCache() returns utils.loadAssetLastActivityDatabaseStub("cache/asset_last_activity.csv")


         MockitoSugar.when(
           PipelineUtil.loadWheelTPMSData(any[String])
         ) thenAnswer (
           (loadWheelTPMSDataMocked("compact_cur_tpms.csv"), "earliest")
           )

         MockitoSugar.when(PipelineUtil.getEnvVariable("ENVIRONMENT")) thenAnswer utils.getEnvVariableMocked("ENVIRONMENT")
         MockitoSugar.when(PipelineUtil.dedupToLatest(any[DataFrame])) thenCallRealMethod()
         MockitoSugar.when(PipelineUtil.dedupActivityToLatest(any[DataFrame])) thenCallRealMethod()
         MockitoSugar.when(
           PipelineUtil.writeDataFrameToKafkaTopic(
             any[DataFrame], any[String], any[Map[String, String]], eqTo[String]("curated-alerts-data-records")
           )
         ) thenAnswer writeDataFrameToKafkaTopicMocked _

         //  val testDf = utils.loadCSVAsDataframe("warning_data_tyrelock.csv")
         val testDf = utils.loadCSVAsDataframe("warning_data_version2.0.csv")
         println("************************************testDf*****************************************")
         testDf.show(false)

         WarningEventProcessor.processMessagesByBatch(testDf, 1)

         println("************************************resultsDf for Test 1*****************************************")
         resultsDf.show(5,false)
         assert(resultsDf.columns.contains("key"))
         assert(resultsDf.columns.contains("value"))
         assert(resultsDf !== null)

         val finalDf = resultsDf
           .select(
             from_json($"value" cast "string"
               , ScalaReflection.schemaFor[ProcessedWheelWarningRecord].dataType.asInstanceOf[StructType]
             ) as "events"
           )
           .select($"events.*")

         println("************************************finalDf*****************************************")
         finalDf.show(5,false)
         assert(finalDf.where($"asset_code" isNotNull).count() > 0, "No Null Access Codes")

        /* val validateDf = finalDf.where(($"device_id" === "1KqjP1nVJQYR"))

         println("************************************validateDf*****************************************")
         validateDf.show(false)
         assert(validateDf.where($"asset_code" === "STAGING-2").count() == 4, "asset_code correctly set")
         assert(validateDf.where($"asset_id" === 2).count() == 4, "asset_id correctly set")
         assert(validateDf.where($"service" === "alerts-curated").count() == 4, "service is having alerts-curated")
         assert(validateDf.where($"resource" === "events/warnings/tyre-lock").count() == 2, "resource is having tyre-lock")
         assert(validateDf.where($"resource" === "events/warnings/fast-pressure-loss").count() > 0, "resource is having fast-pressure-loss")
         // assert(validateDf.where($"resource" === "events/warnings/temperature").count() > 0,"resource is having temperature")
         assert(validateDf.where($"category" =!= null).count() >= 0, "category shouldn't have null")
         assert(validateDf.where($"active" === 1).count() >= 0, "active has true value")
         assert(validateDf.where($"duration" =!= null).count() >= 0, "duration shouldn't have null")*/
       }
     }

     it("Test 2 - Verifying Warning event process analytics Topic") {
       withObjectMocked[PipelineUtil.type] {
         PipelineUtil.updateCustomerDimCacheFromDatabase() returns utils.updateCustomerDimCacheMocked()
         PipelineUtil.FetchCustomerDeviceFromDatabase() returns utils.FetchCustomerDeviceFromDatabaseMocked()
         PipelineUtil.spark returns spark
         PipelineUtil.environment = "dev"
         PipelineUtil.active_alerts_prev_state_topic returns "alert-past-notification"
         PipelineUtil.asset_prev_activity_topic returns "asset-past-activity-notification"

         MockitoSugar.when(
           PipelineUtil.updateCustomerDimCache(any[String])
         ) thenAnswer(utils.updateCustomerDimCacheMocked(), "earliest")

         PipelineUtil.getAssetAlertStateFromDatabaseCache returns utils.loadAssetLastAlertDatabaseStub("cache/asset_alert_activity.csv")
         PipelineUtil.getAssetActivityStateFromDatabaseCache() returns utils.loadAssetLastActivityDatabaseStub("cache/asset_last_activity.csv")


         MockitoSugar.when(
           PipelineUtil.loadWheelTPMSData(any[String])
         ) thenAnswer (
           (loadWheelTPMSDataMocked("compact_cur_tpms.csv"), "earliest")
           )


         MockitoSugar.when(PipelineUtil.getEnvVariable("ENVIRONMENT")) thenAnswer utils.getEnvVariableMocked("ENVIRONMENT")
         MockitoSugar.when(PipelineUtil.dedupToLatest(any[DataFrame])) thenCallRealMethod()
         MockitoSugar.when(PipelineUtil.dedupActivityToLatest(any[DataFrame])) thenCallRealMethod()
         MockitoSugar.when(
           PipelineUtil.writeDataFrameToKafkaTopic(
             any[DataFrame], any[String], any[Map[String, String]], eqTo[String]("curated-alerts-snapshot-records")
           )
         ) thenAnswer writeDataFrameToKafkaTopicMocked _

         //   val testDf = utils.loadCSVAsDataframe("warning_data_tyrelock.csv")
         val testDf = utils.loadCSVAsDataframe("warning_data_version2.0.csv")

         WarningEventProcessor.processMessagesByBatch(testDf, 1)

         println("************************************resultsDf*****************************************")
         resultsDf.show(5,false)
         assert(resultsDf.columns.contains("key"))
         assert(resultsDf.columns.contains("value"))
         assert(resultsDf !== null)

         val finalDf = resultsDf
           .select(
             from_json($"value" cast "string"
               , ScalaReflection.schemaFor[ProcessedAlertSnapshot].dataType.asInstanceOf[StructType]
             ) as "events"
           )
           .select($"events.*")

         /*println("************************************finalDf*****************************************")
         finalDf.show(false)*/

         assert(finalDf.where($"device_id" isNotNull).count() > 0, "No Null device id")
         assert(finalDf.where($"service" === "analytics").count() > 0, "Service should have analytics")

         //finalDf.printSchema()

         val press_data_schema = ScalaReflection.schemaFor[WheelPressureData].dataType.asInstanceOf[StructType]
         val temp_data_schema = ScalaReflection.schemaFor[WheelTemperatureData].dataType.asInstanceOf[StructType]
         val warn_data_schema = ScalaReflection.schemaFor[WarningEvent].dataType.asInstanceOf[StructType]

         val warnDf = finalDf.select($"device_id", $"reported_time",
           (from_json($"data.trigger.data", warn_data_schema) as "warn_data"))
           .withColumn("location", $"warn_data.location")
           .withColumn("category", $"warn_data.category")
           .withColumn("duration", $"warn_data.event.duration")
           .withColumn("previous_active_duration", $"warn_data.event.previous_active_duration")
           .withColumn("active", $"warn_data.event.active")

         /*println("************************************warnDf*****************************************")
         warnDf.show(false)*/

         assert(warnDf.where($"location" === 17).count() >= 1, "location should have 37, 17, 19 etc")
         assert(warnDf.where($"category" isNotNull).count() > 0, "category shouldn't have null")
         assert(warnDf.where($"active" === "false").count() >= 1, "active has false value")
         assert(warnDf.where($"duration" isNotNull).count() > 0, "duration shouldn't have null")


         val pressDf = finalDf.select(explode($"data.additional_data") as "add_data")
           .withColumn("data_press"
             , when($"add_data.resource" === "wheel/pressure"
               , from_json($"add_data.data", press_data_schema)
             ).otherwise(lit(null))
           )
           .select($"data_press.pressure.measured" as "pressure",
             $"data_press.pressure.temp_comp" as "temp_comp")

         assert(pressDf.where($"pressure" === 9130).count() >= 1, "pressure checking")
         assert(pressDf.where($"pressure" === "temp_comp").count() >= 0, "pressure should be matched temp_comp")

         /*println("************************************pressDf*****************************************")
         pressDf.show(false)*/

       }
     }

     it("Test 3 - Verifying Warning event process for alerts notifications Topic") {
       withObjectMocked[PipelineUtil.type] {
         PipelineUtil.updateCustomerDimCacheFromDatabase() returns utils.updateCustomerDimCacheMocked()
         PipelineUtil.FetchCustomerDeviceFromDatabase() returns utils.FetchCustomerDeviceFromDatabaseMocked()
         PipelineUtil.spark returns spark
         PipelineUtil.environment = "dev"
         PipelineUtil.active_alerts_prev_state_topic returns "alert-past-notification"
         PipelineUtil.asset_prev_activity_topic returns "asset-past-activity-notification"

         MockitoSugar.when(
           PipelineUtil.updateCustomerDimCache(any[String])
         ) thenAnswer(utils.updateCustomerDimCacheMocked(), "earliest")

         PipelineUtil.getAssetAlertStateFromDatabaseCache returns utils.loadAssetLastAlertDatabaseStub("cache/asset_alert_activity.csv")
         PipelineUtil.getAssetActivityStateFromDatabaseCache() returns utils.loadAssetLastActivityDatabaseStub("cache/asset_last_activity.csv")

         MockitoSugar.when(
           PipelineUtil.loadWheelTPMSData(any[String])
         ) thenAnswer (
           (loadWheelTPMSDataMocked("compact_cur_tpms.csv"), "earliest")
           )

         MockitoSugar.when(PipelineUtil.getEnvVariable("ENVIRONMENT")) thenAnswer utils.getEnvVariableMocked("ENVIRONMENT")
         MockitoSugar.when(PipelineUtil.dedupToLatest(any[DataFrame])) thenCallRealMethod()
         MockitoSugar.when(PipelineUtil.dedupActivityToLatest(any[DataFrame])) thenCallRealMethod()
         MockitoSugar.when(
           PipelineUtil.writeDataFrameToKafkaTopic(
             any[DataFrame], any[String], any[Map[String, String]], eqTo[String]("alert-active-notification")
           )
         ) thenAnswer writeDataFrameToKafkaTopicMocked _

         //   val testDf = utils.loadCSVAsDataframe("warning_data_tyrelock.csv")
         val testDf = utils.loadCSVAsDataframe("warning_data_version2.0.csv")

         WarningEventProcessor.processMessagesByBatch(testDf, 1)

         resultsDf.show(5,false)
         assert(resultsDf.columns.contains("key"))
         assert(resultsDf.columns.contains("value"))
         assert(resultsDf !== null)

         val finalDf = resultsDf
           .select(
             from_json($"value" cast "string"
               , ScalaReflection.schemaFor[ActiveAlertNotification].dataType.asInstanceOf[StructType]
             ) as "events"
           )
           .select($"events.*")

         finalDf.show(5,false)
         assert(finalDf.where($"asset_code" isNotNull).count() > 0, "No Null Access Codes")

         val validateDf = finalDf.where($"asset_code" === "STAGING-2")

         validateDf.show(false)
         assert(validateDf.where($"location" === 17).count() >= 1, "location correctly set")
         assert(validateDf.where($"pressure_psi" === 63.02).count() >= 1, "pressure_psi correctly set")
         assert(validateDf.where($"temperature_f" === 219.2).count() >= 1, "temperature_f correctly set")
         assert(validateDf.where($"category" =!= null).count() >= 0, "category shouldn't have null")
         assert(validateDf.where($"active" === 0).count() > 1, "active has false value")


       }
     }

     ignore("Test 4 - Verifying Warning event process for FEDX alerts Topic") {
       withObjectMocked[PipelineUtil.type] {
         PipelineUtil.updateCustomerDimCacheFromDatabase() returns utils.updateCustomerDimCacheMocked()
         PipelineUtil.spark returns spark
         PipelineUtil.environment = "dev"
         PipelineUtil.active_alerts_prev_state_topic returns "alert-past-notification"
         PipelineUtil.asset_prev_activity_topic returns "asset-past-activity-notification"

         MockitoSugar.when(
           PipelineUtil.updateCustomerDimCache(any[String])
         ) thenAnswer(utils.updateCustomerDimCacheMocked(), "earliest")

         PipelineUtil.getAssetAlertStateFromDatabaseCache returns utils.loadAssetLastAlertDatabaseStub("cache/asset_alert_activity.csv")
         PipelineUtil.getAssetActivityStateFromDatabaseCache() returns utils.loadAssetLastActivityDatabaseStub("cache/asset_last_activity.csv")

         MockitoSugar.when(
           PipelineUtil.loadWheelTPMSData(any[String])
         ) thenAnswer (
           (loadWheelTPMSDataMocked("compact_cur_tpms.csv"), "earliest")
           )

         MockitoSugar.when(PipelineUtil.getEnvVariable("ENVIRONMENT")) thenAnswer utils.getEnvVariableMocked("ENVIRONMENT")
         MockitoSugar.when(PipelineUtil.dedupToLatest(any[DataFrame])) thenCallRealMethod()
         MockitoSugar.when(PipelineUtil.dedupActivityToLatest(any[DataFrame])) thenCallRealMethod()
         MockitoSugar.when(
           PipelineUtil.writeDataFrameToKafkaTopic(
             any[DataFrame], any[String], any[Map[String, String]], eqTo[String]("rawingestion-m2m")
           )
         ) thenAnswer writeDataFrameToKafkaTopicMocked _

         val testDf = utils.loadCSVAsDataframe("warning_data_version2.0.csv")

         WarningEventProcessor.processMessagesByBatch(testDf, 1)

         println("************************************result df for Test 4********************************")
         resultsDf.show(false)
         // assert(resultsDf.columns.contains("key"))
         assert(resultsDf.columns.contains("value"))
         assert(resultsDf !== null)


       }
     }
     ignore("Test 5 - Verifying Warning event process for WRNR alerts Topic") {
       withObjectMocked[PipelineUtil.type] {
         PipelineUtil.updateCustomerDimCacheFromDatabase() returns utils.updateCustomerDimCacheMocked()
         PipelineUtil.spark returns spark
         PipelineUtil.environment = "dev"
         PipelineUtil.active_alerts_prev_state_topic returns "alert-past-notification"
         PipelineUtil.asset_prev_activity_topic returns "asset-past-activity-notification"

         MockitoSugar.when(
           PipelineUtil.updateCustomerDimCache(any[String])
         ) thenAnswer(utils.updateCustomerDimCacheMocked(), "earliest")

         PipelineUtil.getAssetAlertStateFromDatabaseCache returns utils.loadAssetLastAlertDatabaseStub("cache/asset_alert_activity.csv")
         PipelineUtil.getAssetActivityStateFromDatabaseCache() returns utils.loadAssetLastActivityDatabaseStub("cache/asset_last_activity.csv")

         MockitoSugar.when(
           PipelineUtil.loadWheelTPMSData(any[String])
         ) thenAnswer (
           (loadWheelTPMSDataMocked("compact_cur_tpms.csv"), "earliest")
           )

         MockitoSugar.when(PipelineUtil.getEnvVariable("ENVIRONMENT")) thenAnswer utils.getEnvVariableMocked("ENVIRONMENT")
         MockitoSugar.when(PipelineUtil.dedupToLatest(any[DataFrame])) thenCallRealMethod()
         MockitoSugar.when(PipelineUtil.dedupActivityToLatest(any[DataFrame])) thenCallRealMethod()
         MockitoSugar.when(
           PipelineUtil.writeDataFrameToKafkaTopic(
             any[DataFrame], any[String], any[Map[String, String]], eqTo[String]("wrnr_alerts_new_topic")
           )
         ) thenAnswer writeDataFrameToKafkaTopicMocked _

         val testDf = utils.loadCSVAsDataframe("warning_data_version2.0.csv")
         println("************************************testDf******************************************")
         testDf.show(false)

         WarningEventProcessor.processMessagesByBatch(testDf, 1)

         println("************************************result df for Test 4********************************")
         resultsDf.show(false)
         // assert(resultsDf.columns.contains("key"))
        // assert(resultsDf.columns.contains("value"))
       //  assert(resultsDf !== null)
       }
     }
   }
 }