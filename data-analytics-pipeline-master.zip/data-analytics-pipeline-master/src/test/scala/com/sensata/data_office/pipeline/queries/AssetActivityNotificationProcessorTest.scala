package com.sensata.data_office.pipeline.queries

import com.sensata.data_office.data.AssetActivityNotification
import com.sensata.data_office.utilities.PipelineUtil
import com.sensata.data_office.utilities.PipelineUtil.createEmptyActivityRecord
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.catalyst.ScalaReflection
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StructType
import org.mockito.ArgumentMatchersSugar.{any, eqTo}
import org.mockito.{IdiomaticMockito, MockitoSugar}
import org.scalatest.FunSpec
import org.slf4j.LoggerFactory
import utils.{SparkSessionTestWrapper, utilityMethods}



class AssetActivityNotificationProcessorTest extends FunSpec with SparkSessionTestWrapper with IdiomaticMockito {
  import spark.implicits._

  def writeDataFrameToDatabaseCacheTableMocked(df: DataFrame, table_name: String): Unit = {
    resultsDf = df
  }

  /**
   * Mocked Kafka Writer for displaying final dataframe
   *
   * @param df
   * @param write_mode
   * @param kafkaOptions
   * @param kafka_topic
   */
  def writeDataFrameToKafkaTopicMocked(df: DataFrame, write_mode: String, kafkaOptions: Map[String, String], kafka_topic: String): Unit = {
    resultsDf = df
       }

  def reloadAssetActivityMocked (filename: String): DataFrame = {

    var cached_alerts = spark.emptyDataFrame
    try {
      val notify_schema = ScalaReflection.schemaFor[AssetActivityNotification].dataType.asInstanceOf[StructType]
      cached_alerts = utils.loadCSVAsDataframe(filename)
        .select(
          from_json($"activity_state" cast "string"
            , notify_schema
          ) as "events"
        )
        .select($"events.*")

      if (!cached_alerts.columns.contains("measured_speed")) {
        cached_alerts = cached_alerts
          .withColumn("measured_speed", lit(0))
          .withColumn("measured_heading", lit(0))
      }
    } catch {
      case _ => cached_alerts = createEmptyActivityRecord()
    }
    dedupActivityToLatestMocked(cached_alerts)
  }

  def dedupActivityToLatestMocked(df: DataFrame) = {
    df.withColumn(
      "rec_rank"
      , rank over Window.partitionBy("asset_code").orderBy(asc("reported_time"),asc("last_updated"))
    )
      .withColumn(
        "max_rank"
        , max("rec_rank") over Window.partitionBy("asset_code")
      )
      .where($"max_rank" === $"rec_rank") // select the last record
      .drop("max_rank","rec_rank")
      .dropDuplicates("asset_code")
  }

  var resultsDf = spark.emptyDataFrame
  val utils = new utilityMethods()

  describe("Asset Activity Notification Test") {
    it("Test 1 - Asset activity Notification process for Topic") {
      withObjectMocked[PipelineUtil.type] {
        PipelineUtil.spark returns spark
        PipelineUtil.environment = "dev"
        PipelineUtil.appLogger returns LoggerFactory.getLogger("AssetAlertTest")
        PipelineUtil.asset_prev_activity_topic returns "asset-past-activity-notification"
        MockitoSugar.when(PipelineUtil.getEnvVariable("ENVIRONMENT")) thenAnswer utils.getEnvVariableMocked("ENVIRONMENT")
        MockitoSugar.when(PipelineUtil.dedupActivityToLatest(any[DataFrame])) thenAnswer dedupActivityToLatestMocked _

        //PipelineUtil.getAssetActivityStateFromDatabaseCache returns reloadAssetActivityMocked("asset_prev_activity_data.csv")
        PipelineUtil.getAssetActivityStateFromDatabaseCache() returns utils.loadAssetLastActivityDatabaseStub("cache/asset_last_activity.csv")



       /* MockitoSugar.when(
          PipelineUtil.writeDataFrameToDatabaseCacheTable(any[DataFrame], any[String])
        ) thenAnswer writeDataFrameToDatabaseCacheTableMocked _*/


        MockitoSugar.when(
          PipelineUtil.writeDataFrameToKafkaTopic(
            any[DataFrame], any[String], any[Map[String, String]], any[String]
          )
        ) thenAnswer writeDataFrameToKafkaTopicMocked _

        val testDf = utils.loadCSVAsDataframe("asset_activity_data.csv")
        testDf.show(false)

        AssetActivityNotificationProcessor.processMessagesByBatch(testDf, 1)

      /*  println("****************************resultsDf**************************")
        resultsDf.show(false)*/
        assert(resultsDf.columns.contains("key"))
        assert(resultsDf.columns.contains("value"))
       // assert(resultsDf.columns.contains("spark_key"))
       // assert(resultsDf.columns.contains("activity_state"))

        val finalDf = resultsDf
          .select(
            from_json($"value" cast "string"
              , ScalaReflection.schemaFor[AssetActivityNotification].dataType.asInstanceOf[StructType]
            ) as "events"
          )
          .select($"events.*")

        finalDf.show(false)
        assert(finalDf.where($"asset_code" isNotNull).count() == 0, "Null Access Codes")
        assert(finalDf.where($"asset_code" like  "SENSDEV or STAGING").count() == 0,"Asset has sensdev or staging")

      }
    }
  }
}
