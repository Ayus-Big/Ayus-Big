package com.sensata.data_office.pipeline.queries

import com.sensata.data_office.data.ActiveAlertNotification
import com.sensata.data_office.utilities.PipelineUtil
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.catalyst.ScalaReflection
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StructType
import org.mockito.ArgumentMatchersSugar.{any, eqTo}
import org.mockito.{IdiomaticMockito, MockitoSugar}
import org.scalatest.FunSpec
import org.slf4j.LoggerFactory
import utils.{SparkSessionTestWrapper, utilityMethods}


class WarningNotificationProcessorTest  extends FunSpec with SparkSessionTestWrapper with IdiomaticMockito {
  import spark.implicits._

  /**
   * Mocked Kafka Writer for displaying final dataframe
   * @param df
   * @param write_mode
   * @param kafkaOptions
   * @param kafka_topic
   */
  def writeDataFrameToKafkaTopicMocked(df: DataFrame, write_mode: String, kafkaOptions: Map[String,String], kafka_topic: String): Unit = {
    resultsDf = df
  }

  /*def writeDataFrameToKafkaMocked(df: DataFrame, write_mode: String, kafkaOptions: Map[String,String]): Unit = {
    resultsDf = df
  }*/

  def writeDataFrameToEmailNotificationKafkaTopicMocked(df: DataFrame, write_mode: String, kafkaOptions: Map[String,String], kafka_topic: String): Unit = {
    notificationDf = df
  }

 /* def writeDataFrameToDatabaseCacheTableMocked(df: DataFrame, table_name: String): Unit = {
    resultsDf = df
  }*/

  /**
   *
   * @return
   */
  def reloadLiveAlertsMocked(filename: String): DataFrame = {

    var cached_alerts = spark.emptyDataFrame
    val notify_schema = ScalaReflection.schemaFor[ActiveAlertNotification].dataType.asInstanceOf[StructType]
    cached_alerts = utils.loadActiveAlertMessage(filename)
      .select(
        from_json($"value" cast "string"
          , notify_schema
        ) as "events"
      )
      .select($"events.*")

    if(! cached_alerts.columns.contains("asset_code") ) {
      cached_alerts = cached_alerts.withColumn("asset_code", $"asset_id")
    } else {
      cached_alerts = cached_alerts.withColumn("asset_code"
        , when($"asset_code" isNull, $"asset_id").otherwise($"asset_code")
      )
    }
    cached_alerts
      .where( ($"active" === 1) || ($"active" === 0))
      .withColumn(
        "rec_rank"
        , rank over Window.partitionBy("asset_code","location","resource").orderBy(asc("reported_time"),asc("last_updated"))
      )
      .withColumn(
        "max_rank"
        , max("rec_rank") over Window.partitionBy("asset_code","location","resource")
      )
      .where($"max_rank" === $"rec_rank") // select the last record
      .drop("max_rank","rec_rank")
      .dropDuplicates()
      .where($"asset_code" === "STAGING-81")
  }

  var resultsDf = spark.emptyDataFrame
  var notificationDf = spark.emptyDataFrame

  val utils = new utilityMethods()

  describe("Alert Notification Test") {
    it("Test 1: Changes the alert state when active moves from 1 to 0 and 0 to 1") {
      withObjectMocked[PipelineUtil.type] {
        PipelineUtil.spark returns spark
        PipelineUtil.environment returns "dev"
        PipelineUtil.appLogger returns LoggerFactory.getLogger("ActiveAlertTest")
        PipelineUtil.active_alerts_prev_state_topic returns "alert-past-notification"
        MockitoSugar.when(PipelineUtil.dedupToLatest(any[DataFrame])) thenCallRealMethod()

        PipelineUtil.getAssetAlertStateFromDatabaseCache returns reloadLiveAlertsMocked("alert-notification/messages_alert-past-notification-active-state-change.json")


        MockitoSugar.when( PipelineUtil.getEnvVariable(any[String],any[String]) ) thenCallRealMethod()
        MockitoSugar.when(
          PipelineUtil.writeDataFrameToKafkaTopic(
            any[DataFrame],any[String],any[Map[String,String]],any[String]
          )
        ) thenAnswer writeDataFrameToKafkaTopicMocked _

       /* MockitoSugar.when(
          PipelineUtil.writeDataFrameToKafka(
            any[DataFrame],any[String],any[Map[String,String]]
          )
        ) thenAnswer writeDataFrameToKafkaMocked _*/


        MockitoSugar.when(
          PipelineUtil.writeDataFrameToEmailNotificationKafkaTopic(
            any[DataFrame],any[String],any[Map[String,String]],any[String]
          )
        ) thenAnswer writeDataFrameToEmailNotificationKafkaTopicMocked _


        //    MockitoSugar.when(
        //      PipelineUtil.writeDataFrameToDatabaseCacheTable(any[DataFrame], any[String])
        //    ) thenAnswer writeDataFrameToDatabaseCacheTableMocked _

        val testDf = utils.loadActiveAlertMessage("alert-notification/messages_alert-active-notification-active-state-change.json")
          //.where($"key" === "STAGING-81-27-events/warnings/pressure")

        /*println("*******************************************testDf*************************************")
        testDf.show(50,false)*/

        WarningNotificationProcessor.processMessagesByBatch(testDf,1)

        println("*******************************************resultsDf*************************************")
        resultsDf.show(false)
        println("*******************************************notificationDf*************************************")
        notificationDf.show(false)

        val finalDf = notificationDf
          .where($"key" === "STAGING-81-27-events/warnings/pressure")
          .select(
            from_json($"value" cast "string"
              , ScalaReflection.schemaFor[ActiveAlertNotification].dataType.asInstanceOf[StructType]
            ) as "events"
          )
          .select($"events.*")

       // assert(notificationDf.count() == 1, "email notification record count")
        assert(finalDf.count() == 1, "record count for key 'STAGING-81-27-events/warnings/pressure'")
        assert(finalDf.where($"state_changed" === "true").count() == 1, "state_change record count for key 'STAGING-81-27-events/warnings/pressure'")
        assert(finalDf.where($"active" === "1").count() == 1, "active record count for key 'STAGING-81-27-events/warnings/pressure'")
        assert(finalDf.where($"old_active" === "0").count() == 1,"old_active record count for key 'STAGING-81-27-events/warnings/pressure'")
       // assert(resultsDf.count() == 1)
      }
    }

    it("Test 2: Changes the alert state when an active alert changes category") {
      withObjectMocked[PipelineUtil.type] {
        PipelineUtil.spark returns spark
        PipelineUtil.environment returns "dev"
        PipelineUtil.appLogger returns LoggerFactory.getLogger("ActiveAlertTest")
        PipelineUtil.active_alerts_prev_state_topic returns "alert-past-notification"
        MockitoSugar.when(PipelineUtil.dedupToLatest(any[DataFrame])) thenCallRealMethod()

        PipelineUtil.getAssetAlertStateFromDatabaseCache returns reloadLiveAlertsMocked("alert-notification/messages_alert-past-notification-category-state-change.json")

        MockitoSugar.when( PipelineUtil.getEnvVariable(any[String],any[String]) ) thenCallRealMethod()
        MockitoSugar.when(
          PipelineUtil.writeDataFrameToKafkaTopic(
            any[DataFrame],any[String],any[Map[String,String]],any[String]
          )
        ) thenAnswer writeDataFrameToKafkaTopicMocked _

        MockitoSugar.when(
          PipelineUtil.writeDataFrameToEmailNotificationKafkaTopic(
            any[DataFrame],any[String],any[Map[String,String]],any[String]
          )
        ) thenAnswer writeDataFrameToEmailNotificationKafkaTopicMocked _

        val testDf = utils.loadActiveAlertMessage("alert-notification/messages_alert-active-notification-category-state-change.json")
          .where($"key" === "STAGING-81-27-events/warnings/pressure")

        testDf.show(false)

        WarningNotificationProcessor.processMessagesByBatch(testDf,1)

        notificationDf.show(5,false)

        val finalDf = notificationDf
          .where($"key" === "STAGING-81-27-events/warnings/pressure")
          .select(
            from_json($"value" cast "string"
              , ScalaReflection.schemaFor[ActiveAlertNotification].dataType.asInstanceOf[StructType]
            ) as "events"
          )
          .select($"events.*")
        finalDf.show(1,false)
        assert(notificationDf.count() == 1)
        assert(finalDf.count() == 1)
        assert(finalDf.where($"state_changed" === "true").count() == 1)
        assert(finalDf.where($"category" === "2").count() == 1)
        assert(finalDf.where($"old_category" === "1").count() == 1)
        assert(resultsDf.count() == 1)

      }
    }

    it("Test 3: Doesn't change the alert state when the active field hasn't changed ") {
      withObjectMocked[PipelineUtil.type] {
        PipelineUtil.spark returns spark
        PipelineUtil.environment returns "dev"
        PipelineUtil.appLogger returns LoggerFactory.getLogger("ActiveAlertTest")
        PipelineUtil.active_alerts_prev_state_topic returns "alert-past-notification"
        MockitoSugar.when(PipelineUtil.dedupToLatest(any[DataFrame])) thenCallRealMethod()

        PipelineUtil.getAssetAlertStateFromDatabaseCache returns reloadLiveAlertsMocked("alert-notification/messages_alert-past-notification-no-state-change.json")

        MockitoSugar.when( PipelineUtil.getEnvVariable(any[String],any[String]) ) thenCallRealMethod()
        MockitoSugar.when(
          PipelineUtil.writeDataFrameToKafkaTopic(
            any[DataFrame],any[String],any[Map[String,String]],any[String]
          )
        ) thenAnswer writeDataFrameToKafkaTopicMocked _

        MockitoSugar.when(
          PipelineUtil.writeDataFrameToEmailNotificationKafkaTopic(
            any[DataFrame],any[String],any[Map[String,String]],any[String]
          )
        ) thenAnswer writeDataFrameToEmailNotificationKafkaTopicMocked _

        val testDf = utils.loadActiveAlertMessage("alert-notification/messages_alert-active-notification-no-state-change.json")
        //  .where($"key" === "STAGING-81-27-events/warnings/pressure")
        testDf.show(false)

        WarningNotificationProcessor.processMessagesByBatch(testDf,1)

        println("**********************************resultsDf***********************************")
        resultsDf.show(false)


        val finalDf = resultsDf
          .where($"spark_key" === "STAGING-81-27-events/warnings/pressure")
         /* .select(
            from_json($"value" cast "string"
              , ScalaReflection.schemaFor[ActiveAlertNotification].dataType.asInstanceOf[StructType]
            ) as "events"
          )
          .select($"events.*")*/

        println("**********************************finalDf***********************************")
        finalDf.show(false)

        assert(finalDf.count() == 1)
        assert(finalDf.where($"state_changed" === "false").count() == 1)
        assert(finalDf.where($"category" === "1").count() == 1)
        assert(finalDf.where($"active" === "1").count() == 1)
        assert(finalDf.where($"old_active" === "1").count() == 1)

      }
    }
  }

}
