package com.sensata.data_office.pipeline.queries

import com.sensata.data_office.utilities.PipelineUtil
import org.apache.spark.sql.DataFrame
import org.mockito.ArgumentMatchersSugar.any
import org.mockito.{IdiomaticMockito, MockitoSugar}
import org.scalatest.FunSpec
import utils.{SparkSessionTestWrapper, utilityMethods}

class LakeDataLoaderTest extends FunSpec with SparkSessionTestWrapper with IdiomaticMockito {

  /**
   * Mocked Kafka Writer for displaying final dataframe
   *
   * @param df
   * @param write_mode
   * @param kafkaOptions
   * @param kafka_topic
   */

  var resultsDf = spark.emptyDataFrame

  def writeDataFrameToBlobStorageMocked(df: DataFrame, write_mode: String, target_path: String): Unit = {
    resultsDf = df
  }

  val utils = new utilityMethods()

  describe("Curated Topic Data Test") {
    it("Test 1 - Processed GPS data and load into Blob storage") {
      withObjectMocked[PipelineUtil.type] {
        PipelineUtil.spark returns spark
        PipelineUtil.environment = "dev"

        MockitoSugar.when(PipelineUtil.getEnvVariable("ENVIRONMENT")) thenAnswer utils.getEnvVariableMocked("ENVIRONMENT")
        MockitoSugar.when(
          PipelineUtil.writeDataFrameToBlobStorage(
            any[DataFrame], any[String], any[String]
          )
        ) thenAnswer writeDataFrameToBlobStorageMocked _

        val testDf = utils.loadCSVAsDataframe("gps_msg.csv")
      //  testDf.show(false)
        LakeDataLoader.processGPSMessagesByBatch(testDf, 1)

        //println("***************************this is for GPS message***********************************")
      //  resultsDf.show( false)
        assert(resultsDf.count() === testDf.count())
      //  assert(resultsDf.where($"asset_code" isNotNull).count() > 0, "No Null Access Codes")
       // assert(resultsDf.where($"asset_code" like  "SENSDEV or STAGING").count() == 0,"Asset has sensdev or staging")

      }
    }

    it("Test 2 - Processed Alerts message and load into Blob storage") {
      withObjectMocked[PipelineUtil.type] {
        PipelineUtil.updateCustomerDimCacheFromDatabase() returns utils.updateCustomerDimCacheMocked()
        PipelineUtil.spark returns spark
        PipelineUtil.environment = "dev"

        MockitoSugar.when(PipelineUtil.getEnvVariable("ENVIRONMENT")) thenAnswer utils.getEnvVariableMocked("ENVIRONMENT")
        MockitoSugar.when(
          PipelineUtil.writeDataFrameToBlobStorage(
            any[DataFrame], any[String], any[String]
          )
        ) thenAnswer writeDataFrameToBlobStorageMocked _

        val testDf = utils.loadCSVAsDataframe("alert_msg.csv")

        LakeDataLoader.processAlertsMessagesByBatch(testDf, 1)

        println("***************************this is for Alerts message***********************************")
        resultsDf.show(false)
       // assert(resultsDf.count() === testDf.count())

      }
    }

    it("Test 3 - Processed Alerts SnapShot message and load into Blob storage") {
      withObjectMocked[PipelineUtil.type] {
        PipelineUtil.spark returns spark
        PipelineUtil.environment = "dev"

        MockitoSugar.when(PipelineUtil.getEnvVariable("ENVIRONMENT")) thenAnswer utils.getEnvVariableMocked("ENVIRONMENT")
        MockitoSugar.when(
          PipelineUtil.writeDataFrameToBlobStorage(
            any[DataFrame], any[String], any[String]
          )
        ) thenAnswer writeDataFrameToBlobStorageMocked _

        val testDf = utils.loadCSVAsDataframe("alert_snap_msg.csv")

      /*  println("***************************this is for testDf Alerts SnapShot message***********************************")
        testDf.show( false)*/

        LakeDataLoader.processAlertSnapShotMessagesByBatch(testDf, 1)

        /*println("***************************this is for Alerts SnapShot message***********************************")
        resultsDf.show( false)*/
        assert(resultsDf.count() === testDf.count())

      }
    }

    it("Test 4 - Processed Wheel message and load into Blob storage") {
      withObjectMocked[PipelineUtil.type] {
        PipelineUtil.spark returns spark
        PipelineUtil.environment = "dev"

        MockitoSugar.when(PipelineUtil.getEnvVariable("ENVIRONMENT")) thenAnswer utils.getEnvVariableMocked("ENVIRONMENT")
        MockitoSugar.when(
          PipelineUtil.writeDataFrameToBlobStorage(
            any[DataFrame], any[String], any[String]
          )
        ) thenAnswer writeDataFrameToBlobStorageMocked _

        val testDf = utils.loadCSVAsDataframe("wheel_curated_msg.csv")

        LakeDataLoader.processWheelsMessagesByBatch(testDf, 1)

       // println("***************************this is for Wheel message***********************************")
       // resultsDf.show( false)
        assert(resultsDf.count() === testDf.count())

      }
    }
  }
}
