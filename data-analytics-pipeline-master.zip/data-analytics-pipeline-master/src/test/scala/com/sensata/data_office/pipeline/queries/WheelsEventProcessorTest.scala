package com.sensata.data_office.pipeline.queries

import com.sensata.data_office.data._
import com.sensata.data_office.utilities.PipelineUtil
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.catalyst.ScalaReflection
import org.apache.spark.sql.functions.from_json
import org.apache.spark.sql.types.StructType
import org.mockito.ArgumentMatchersSugar.{any, eqTo}
import org.mockito.{IdiomaticMockito, MockitoSugar}
import org.scalatest.FunSpec
import utils.{SparkSessionTestWrapper, utilityMethods}


class WheelsEventProcessorTest extends FunSpec with SparkSessionTestWrapper with IdiomaticMockito {

  import spark.implicits._

  /**
   * Mocked Kafka Writer for displaying final dataframe
   *
   * @param df
   * @param write_mode
   * @param kafkaOptions
   * @param kafka_topic
   */
  def writeDataFrameToKafkaTopicMocked(df: DataFrame, write_mode: String, kafkaOptions: Map[String, String], kafka_topic: String): Unit = {
    resultsDf = df
  }

  def writeDataFrameToKafkaTPMSTopicMocked(df: DataFrame, write_mode: String, kafkaOptions: Map[String, String], kafka_topic: String): Unit = {
    resultsDf = df
  }

  def writeDataFrameToKafkaTPMSCompactTopicMocked(df: DataFrame, write_mode: String, kafkaOptions: Map[String, String], kafka_topic: String): Unit = {
    resultsDf_cmpt = df
  }

  def writeDataFrameToKafkaActivityTopicMocked(df: DataFrame, write_mode: String, kafkaOptions: Map[String, String], kafka_topic: String): Unit = {
    resultsDf_actvty = df
  }

  var resultsDf = spark.emptyDataFrame
  var resultsDf_cmpt = spark.emptyDataFrame
  var resultsDf_actvty = spark.emptyDataFrame
  val utils = new utilityMethods()

  describe("Wheel Event Processor Data Test") {
    it("Test 1 - Verifying Wheel event data for curated wheel topic ") {
      withObjectMocked[PipelineUtil.type] {
        PipelineUtil.updateCustomerDimCacheFromDatabase() returns utils.updateCustomerDimCacheMocked()
        PipelineUtil.FetchCustomerDeviceFromDatabase() returns utils.FetchCustomerDeviceFromDatabaseMocked()
        PipelineUtil.spark returns spark
        PipelineUtil.environment = "dev"

        MockitoSugar.when(PipelineUtil.getEnvVariable("ENVIRONMENT")) thenAnswer utils.getEnvVariableMocked("ENVIRONMENT")

        MockitoSugar.when(
          PipelineUtil.updateCustomerDimCache(any[String])
        ) thenAnswer(utils.updateCustomerDimCacheMocked(), "earliest")

        MockitoSugar.when(
          PipelineUtil.writeDataFrameToKafkaTopic(
            any[DataFrame], any[String], any[Map[String, String]], eqTo[String]("curated-tpms-data-records")
          )
        ) thenAnswer writeDataFrameToKafkaTPMSTopicMocked _

        val testDf = utils.loadCSVAsDataframe("wheel_data.csv")
        println("******************************testDf********************************")
        testDf.show(false)

        WheelsEventProcessor.processMessagesByBatch(testDf, 1)

        println("******************************resultsDf********************************")
        resultsDf.show(false)

        // val write_df = resultsDf.write.format("csv").option("header","true")
        //   .save("C:///Users//x3079432//Desktop//WheelEventProcessor//resultsdf_25thOct_1")

        val curated_data = resultsDf.select(
          from_json($"value" cast "string"
            , ScalaReflection.schemaFor[ProcessedWheelRecord].dataType.asInstanceOf[StructType]
          ) as "events"
        )
          .select($"events.*")
          .where(($"device_id" === "1JXkCLH1CdF2") && ($"location") === "3A")

        /*   curated_data.write.format("csv").option("header","true").mode("append")
           .save("C:///Users//x3079432//Desktop//WheelEventProcessor//curated_wheel_data//28thOct")*/


        println("******************************curated_data********************************")
        curated_data.show(false)
          //sys.exit(-1) // 2021-05-22 00:51:07
           assert(curated_data.where($"asset_code" === "SENSDEV-14").count() == 1, "asset_code not correctly set")
           assert(curated_data.where($"asset_id" === 14).count() == 1,"asset_id correctly set")
           assert(curated_data.where($"measured_pressure" === 6215).count() == 1,"measured_pressure not correctly set")
           assert(curated_data.where($"measured_temperature" === 4.0).count() == 1,"measured_temperature not correctly set")
           assert(curated_data.where($"battery_status" === 100).count() == 1,"battery_status correctly set")
           assert(curated_data.where($"topic_id" === "sensdev").count() == 1,"routing topic prefix is correctly set")

      }
    }

    it("Test 2 - Verifying Wheel event data for compact tpms topic ") {
      withObjectMocked[PipelineUtil.type] {
        PipelineUtil.updateCustomerDimCacheFromDatabase() returns utils.updateCustomerDimCacheMocked()
        PipelineUtil.FetchCustomerDeviceFromDatabase() returns utils.FetchCustomerDeviceFromDatabaseMocked()
        PipelineUtil.spark returns spark
        PipelineUtil.environment = "dev"

        MockitoSugar.when(PipelineUtil.getEnvVariable("ENVIRONMENT")) thenAnswer utils.getEnvVariableMocked("ENVIRONMENT")

        MockitoSugar.when(
          PipelineUtil.updateCustomerDimCache(any[String])
        ) thenAnswer(utils.updateCustomerDimCacheMocked(), "earliest")

        MockitoSugar.when(
          PipelineUtil.writeDataFrameToKafkaTopic(
            any[DataFrame], any[String], any[Map[String, String]], eqTo[String]("curated-tpms-records-compact")
          )
        ) thenAnswer writeDataFrameToKafkaTPMSCompactTopicMocked _

        val testDf = utils.loadCSVAsDataframe("wheel_data.csv")

        /*println("******************************testDf********************************")
        testDf.show(false)*/

        WheelsEventProcessor.processMessagesByBatch(testDf, 1)

        println("******************************resultsDf_cmpt********************************")
        resultsDf_cmpt.show(false)

        assert(resultsDf_cmpt.columns.contains("key"))
        assert(resultsDf_cmpt.columns.contains("value"))
        assert(resultsDf_cmpt.count() > 0)

        val compact_data1 = resultsDf_cmpt.select(
          from_json($"value" cast "string"
            , ScalaReflection.schemaFor[ProcessedWheelRecord].dataType.asInstanceOf[StructType]
          ) as "events"
        )
          .select($"events.*")
          .where(($"device_id" === "1JXkCLH1CdF2") && ($"location") === "3A")

        println("******************************compact_data1********************************")
        compact_data1.show(false)
        assert(compact_data1.where($"asset_code" === "SENSDEV-14").count() == 1, "asset_code not correctly set")
        assert(compact_data1.where($"service" === "wheel-tpms-data").count() == 1, "service not correctly set")
        assert(compact_data1.where($"measured_temperature_f" === 39.2).count() == 1, "measured_temperature_f not correctly set")
        assert(compact_data1.where($"measured_temperature_c" === 4.0).count() == 1, "measured_temperature_c not correctly set")
        assert(compact_data1.where($"measured_pressure_psi" === 90.14).count() == 1, "measured_pressure_psi not correctly set")

      }
    }

    it("Test 3 - Verifying Wheel event data for asset activity topic ") {
      withObjectMocked[PipelineUtil.type] {
        PipelineUtil.updateCustomerDimCacheFromDatabase() returns utils.updateCustomerDimCacheMocked()
        PipelineUtil.FetchCustomerDeviceFromDatabase() returns utils.FetchCustomerDeviceFromDatabaseMocked()
        PipelineUtil.spark returns spark
        PipelineUtil.environment = "dev"

        MockitoSugar.when(
          PipelineUtil.updateCustomerDimCache(any[String])
        ) thenAnswer(utils.updateCustomerDimCacheMocked(), "earliest")

        MockitoSugar.when(PipelineUtil.getEnvVariable("ENVIRONMENT")) thenAnswer utils.getEnvVariableMocked("ENVIRONMENT")

        MockitoSugar.when(
          PipelineUtil.writeDataFrameToKafkaTopic(
            any[DataFrame], any[String], any[Map[String, String]], eqTo[String]("asset-activity-notification")
          )
        ) thenAnswer writeDataFrameToKafkaActivityTopicMocked _

        val testDf = utils.loadCSVAsDataframe("wheel_data.csv")

        WheelsEventProcessor.processMessagesByBatch(testDf, 1)

        /*   println("******************************resultsDf_actvty********************************")
        resultsDf_actvty.show(false)*/

        assert(resultsDf_actvty.columns.contains("key"))
        assert(resultsDf_actvty.columns.contains("value"))
        assert(resultsDf_actvty.count() > 0)

        val asset_activity_data1 = resultsDf_actvty.select(
          from_json($"value" cast "string"
            , ScalaReflection.schemaFor[AssetActivityNotification].dataType.asInstanceOf[StructType]
          ) as "events"
        )
          .select($"events.*")

        asset_activity_data1.show(false)
        assert(asset_activity_data1.where($"asset_code" === "SENSDEV-14").count() == 1, "asset_code not correctly set")


      }
    }

    ignore("Test 4 - Verifying FEDX data for new topic ") {
      withObjectMocked[PipelineUtil.type] {
        PipelineUtil.updateCustomerDimCacheFromDatabase() returns utils.updateCustomerDimCacheMocked()
        PipelineUtil.spark returns spark
        PipelineUtil.environment = "dev"

        MockitoSugar.when(
          PipelineUtil.updateCustomerDimCache(any[String])
        ) thenAnswer(utils.updateCustomerDimCacheMocked(), "earliest")

        MockitoSugar.when(PipelineUtil.getEnvVariable("ENVIRONMENT")) thenAnswer utils.getEnvVariableMocked("ENVIRONMENT")

        MockitoSugar.when(
          PipelineUtil.writeDataFrameToKafkaTopic(
            any[DataFrame], any[String], any[Map[String, String]], eqTo[String]("fedx-alerts-new-topic")
          )
        ) thenAnswer writeDataFrameToKafkaActivityTopicMocked _

        val testDf = utils.loadCSVAsDataframe("wheel_data.csv")

        WheelsEventProcessor.processMessagesByBatch(testDf, 1)

        println("******************************resultsDf_actvty********************************")
        resultsDf_actvty.show(false)

        // assert(resultsDf_actvty.columns.contains("key"))
        assert(resultsDf_actvty.columns.contains("value"))
        assert(resultsDf_actvty.count() > 0)


      }
    }
    ignore("Test 5 - Verifying WRNR data for new topic ") {
      withObjectMocked[PipelineUtil.type] {
        PipelineUtil.updateCustomerDimCacheFromDatabase() returns utils.updateCustomerDimCacheMocked()
        PipelineUtil.spark returns spark
        PipelineUtil.environment = "dev"

        MockitoSugar.when(
          PipelineUtil.updateCustomerDimCache(any[String])
        ) thenAnswer(utils.updateCustomerDimCacheMocked(), "earliest")

        MockitoSugar.when(PipelineUtil.getEnvVariable("ENVIRONMENT")) thenAnswer utils.getEnvVariableMocked("ENVIRONMENT")

        MockitoSugar.when(
          PipelineUtil.writeDataFrameToKafkaTopic(
            any[DataFrame], any[String], any[Map[String, String]], eqTo[String]("wrnr_alerts_new_topic")
          )
        ) thenAnswer writeDataFrameToKafkaTopicMocked _

        val testDf = utils.loadCSVAsDataframe("wheel_data.csv")
        println("******************************testDf********************************")
        testDf.show(false)

        WheelsEventProcessor.processMessagesByBatch(testDf, 1)

        println("******************************resultsDf********************************")
        resultsDf.show(false)

        assert(resultsDf.columns.contains("value"))


      }
    }
  }
}