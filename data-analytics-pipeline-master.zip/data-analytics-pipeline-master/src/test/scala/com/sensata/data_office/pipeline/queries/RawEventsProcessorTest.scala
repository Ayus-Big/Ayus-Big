package com.sensata.data_office.pipeline.queries

import com.github.mrpowers.spark.fast.tests.DatasetComparer
import com.sensata.data_office.utilities.PipelineUtil
import com.sensata.data_office.utilities.PipelineUtil.received_timestamp_format
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.{from_unixtime, get_json_object, to_timestamp, unix_timestamp}
import org.mockito.ArgumentMatchersSugar._
import org.mockito.IdiomaticMockito.StubbingOps
import org.mockito.MockitoSugar
import org.mockito.MockitoSugar.withObjectMocked
import org.scalatest.FunSpec
import utils.{SparkSessionTestWrapper, utilityMethods}



class RawEventsProcessorTest extends FunSpec with SparkSessionTestWrapper with DatasetComparer {

  import spark.implicits._

  var resultsDf = spark.emptyDataFrame
  var resultsDf2 = spark.emptyDataFrame

  val utils = new utilityMethods()

  /**
   * Mocked Kafka Writer for displaying final dataframe
   *
   * @param df
   * @param write_mode
   * @param kafkaOptions
   * @param kafka_topic
   */




  def writeDataFrameToKafkaTopicMocked(df: DataFrame, write_mode: String, kafkaOptions: Map[String, String], kafka_topic: String): Unit = {

    println("*********************************df*************************************")
    df.show(false)


    val topic2resourceT = df.select(
      get_json_object($"value" cast "string", "$.resource") cast "string" as "resource"
      , get_json_object($"value" cast "string", "$.time") cast "timestamp" as "reported_time"
      , get_json_object($"value" cast "string", "$.deviceId") cast "string" as "device_id"
      //, $"topic"
    ).dropDuplicates()

    println("**************************topic2resourceT df**************************")
    topic2resourceT.show(false)

   /* if (topic2resourceT.count() > 0) {

      if (kafka_topic === "gnss-stream-data") {
        assert(
          topic2resourceT.where(
            (($"resource" isin (
              Seq(MessageTypes.GnssPos
                , MessageTypes.GnssVelocity
                , MessageTypes.GnssTime
                , MessageTypes.GnssMotion
                , MessageTypes.GnssDistance
                , MessageTypes.AtisAlerts
                , MessageTypes.TtlAlerts
                , MessageTypes.Kl15Alerts)
              )
              ))
          ).count() > 0
          , "vehicle messages go to gnss topic"
        )
      }

      if (kafka_topic === "tpms-alerts-event-data") {
        assert(
          topic2resourceT.where(
            ($"resource" isin(
              MessageTypes.WarningEventGeneric
              , MessageTypes.WarningEventPressure
              , MessageTypes.WarningEventFastPressureLoss
              , MessageTypes.WarningEventTyreBurst
              , MessageTypes.WarningEventTyreLock
              , MessageTypes.WheelWarningTemperature
              , MessageTypes.GnssDistance
            )
              )
          ).count() > 0
          , "alerts messages go to alert topic"
        )
      }

      if (kafka_topic === "tpms-stream-data") {
        assert(
          topic2resourceT.where(
            ($"resource" isin (
              Seq(MessageTypes.WheelInfoPressure
                , MessageTypes.WheelInfoTemperature
                , MessageTypes.WheelInfoBattery)
              )
              )
          ).count() > 0
          , "TPMS messages go to gnss topic"
        )
      }*/

      /* assert(
        topic2resourceT.where(
          //(( $"reported_time" between("2000-01-01 00:00:00", "2000-01-01 01:00:00") ))
          ($"device_id" === "test-1JXjSbZCXWF2")
      ).count() === 0
        , "Records with invalid timestamps are filtered out"
      )*/
    }
    // }

    /**
     *
     * @param df
     * @param write_mode
     * @param kafkaOptions
     */
    def writeDataFrameToKafkaMocked(df1: DataFrame, write_mode: String, kafkaOptions: Map[String, String]): Unit = {

     println("**************************df1**************************")
      df1.show(false)

      val topic2resource = df1.select(
        get_json_object($"value" cast "string", "$.resource") cast "string" as "resource"
        , get_json_object($"value" cast "string", "$.time") cast "timestamp" as "reported_time"
        , get_json_object($"value" cast "string", "$.deviceId") cast "string" as "device_id"
        , $"topic"
      ).dropDuplicates()

     println("**************************topic2resource df**************************")
      topic2resource.show(false)


      if (topic2resource.count() > 0) {
        assert(
          topic2resource.where(
            (($"resource" isNotNull) && ($"topic" isNotNull))
          ).count() > 0
          , "All messages are routed to a topic"
        )

        /*assert(
        topic2resource.where(
          //(( $"reported_time" between("2000-01-01 00:00:00", "2000-01-01 01:00:00") ))
          ($"device_id" === "test-1JXjSbZCXWF2")
        ).count() === 0
        , "Records with invalid timestamps are filtered out"
      )*/
      }
    }

    /**
     *
     * @param kafka_topic
     * @param kafkaOptions
     * @return
     */
    /*def readDataFrameFromKafkaWithConsumedTimestampMocked(kafka_topic: String, kafkaOptions: Map[String,String]): DataFrame = {
    utils.loadCSVAsDataframe("raw/atis_msg.json")
      .union(
        utils.loadCSVAsDataframe("raw/position_msg.json")
      ).union(
      utils.loadCSVAsDataframe("raw/velocity_msg.json")
    ).union(
      utils.loadCSVAsDataframe("raw/odometer_msg.json")
    )
  }*/

    describe("Raw Data from IoTHub") {

      it("Extracts json resources and route to correct topic") {
        withObjectMocked[PipelineUtil.type] {

          PipelineUtil.spark returns spark
          PipelineUtil.environment = utils.getEnvVariableMocked("ENVIRONMENT")
          MockitoSugar.when(PipelineUtil.extractAnalyticMessageAlerts(any[DataFrame])) thenCallRealMethod()
          MockitoSugar.when(PipelineUtil.constructGenericIOTEventMessage(any[DataFrame])) thenCallRealMethod()
          MockitoSugar.when(PipelineUtil.extractAnalyticMessageTPMS(any[DataFrame])) thenCallRealMethod()
          MockitoSugar.when(PipelineUtil.buildJsonMessage(*, *)) thenCallRealMethod()
          MockitoSugar.when(PipelineUtil.buildJsonMessageV2(*, *, *)) thenCallRealMethod()
          MockitoSugar.when(PipelineUtil.getEnvVariable(eqTo[String]("ENVIRONMENT"), any[String])) thenReturn ("dev")
          MockitoSugar.when(PipelineUtil.getEnvVariable(eqTo[String]("INVALID_TIME_FILTER_THRESHOLD"), any[String])) thenReturn ("20")
          MockitoSugar.when(
            PipelineUtil.writeDataFrameToKafkaTopic(
              any[DataFrame], any[String], any[Map[String, String]], any[String]
            )
          ) thenAnswer writeDataFrameToKafkaTopicMocked _

          MockitoSugar.when(
            PipelineUtil.writeDataFrameToKafka(
              any[DataFrame], any[String], any[Map[String, String]]
            )
          ) thenAnswer writeDataFrameToKafkaMocked _

          PipelineUtil.updateCustomerDimCacheFromDatabase() returns utils.updateCustomerDimCacheMocked()
          PipelineUtil.FetchCustomerDeviceFromDatabase() returns utils.FetchCustomerDeviceFromDatabaseMocked()

          val testDf = utils.loadCSVAsDataframe("raw/raw_msg.csv")

            //   val testDf = utils.loadCSVAsDataframe("raw/atis_msg.csv")
            //      .union(
            //         utils.loadCSVAsDataframe("raw/position_msg.csv")
            //      ).union(
            //      utils.loadCSVAsDataframe("raw/velocity_msg.csv")
            //     ).union(
            //      utils.loadCSVAsDataframe("raw/odometer_msg.csv")
            //    ).union(
            //      utils.loadCSVAsDataframe("raw/alert_msg.csv")
            //     )
            .withColumn("consumed_timestamp"
              , to_timestamp(
                from_unixtime(unix_timestamp(), received_timestamp_format)
              ).cast("long")

            )
          println("**************************test df**************************")
          testDf.show(false)

          RawEventsProcessor.processBatch(testDf, 1)

        //  println("************************************result df for Werner new topic********************************")
        //  resultsDf.show(false)

          // check buildJsonMessageV2 and buildJsonMessage are called based on message version
          //  verify(PipelineUtil, atLeast(1)).buildJsonMessage(any[Dataset[GenericEventData]], any[StructType])
         // verify(PipelineUtil, atLeast(1)).buildJsonMessageV2(any[Dataset[GenericEventData]], any[StructType],any[Boolean])
        }
      }

    }
// }
}

