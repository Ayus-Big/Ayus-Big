package com.sensata.data_office.pipeline.queries

import com.sensata.data_office.data._
import com.sensata.data_office.pipeline.queries.CustomerDataPublisher.asKafkaConnectJsonMessage
import com.sensata.data_office.utilities.Analytics.selectNCastDataFrameAsSchema
import com.sensata.data_office.pipeline.queries.CustomerDataPublisher.setNullableStateForAllColumns
import com.sensata.data_office.utilities.PipelineUtil
import com.sensata.data_office.utilities.PipelineUtil.{asset_prev_activity_topic, dedupActivityToLatest, purgeOffsetList}
import com.typesafe.config.ConfigFactory
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.catalyst.ScalaReflection
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{abs, get_json_object, _}
import org.apache.spark.sql.streaming.Trigger
import org.apache.spark.sql.types.StructType
import org.apache.spark.storage.StorageLevel

object AssetActivityNotificationProcessor {


  val pipelineConfig = ConfigFactory
    .load(s"application.${PipelineUtil.getEnvVariable("ENVIRONMENT")}.conf")
    .getConfig("EventProcessors").getConfig("pipeline")

  val dimentionalCfg = ConfigFactory
    .load(s"application.${PipelineUtil.getEnvVariable("ENVIRONMENT")}.conf")
    .getConfig("dimensional_data")

  val VERSION = pipelineConfig.getString("version")

  val watermark_column = ConfigFactory
    .load(s"application.${PipelineUtil.getEnvVariable("ENVIRONMENT")}.conf").getConfig("high_watermark").getString("watermark_column")
  val watermark_delay_threashold = ConfigFactory
    .load(s"application.${PipelineUtil.getEnvVariable("ENVIRONMENT")}.conf").getConfig("high_watermark").getString("watermark_delay_threashold")
  val late_record_threshold_sec = ConfigFactory
    .load(s"application.${PipelineUtil.getEnvVariable("ENVIRONMENT")}.conf").getConfig("high_watermark").getString("late_record_threshold_sec")

  import PipelineUtil.spark.implicits._

  def processMessagesByBatch(batchMessage: DataFrame, batchId: Long): Unit = {

    val prevActivity = PipelineUtil.getAssetActivityStateFromDatabaseCache()

    val wheel_activity = batchMessage
      .where(get_json_object($"value" cast "string", "$.msg_type") === "wheel")
      .select(
        get_json_object($"value" cast "string", "$.asset_code") as "asset_code"
        , get_json_object($"value" cast "string", "$.reported_time") cast "timestamp" as "reported_time"
        , get_json_object($"value" cast "string", "$.last_updated") cast "timestamp" as "last_updated"
    )

    val gnss_activity = batchMessage
      .where(get_json_object($"value" cast "string", "$.msg_type") === "gnss")
      .select(
        get_json_object($"value" cast "string", "$.asset_code") as "asset_code"
        , get_json_object($"value" cast "string", "$.reported_time") cast "timestamp" as "reported_time"
        , get_json_object($"value" cast "string", "$.measured_speed") cast "int" as "measured_speed"
        , get_json_object($"value" cast "string", "$.measured_heading") cast "int" as "measured_heading"
        , get_json_object($"value" cast "string", "$.odometer") cast "double" as "odometer"
        , get_json_object($"value" cast "string", "$.odometer_total") cast "double" as "odometer_total"
        , get_json_object($"value" cast "string", "$.odometer_in_miles") cast "double" as "odometer_in_miles"
        , get_json_object($"value" cast "string", "$.odometer_total_in_miles") cast "double" as "odometer_total_in_miles"
        , get_json_object($"value" cast "string", "$.atis_state") as "atis_state"
        , get_json_object($"value" cast "string", "$.ttl_active") as "ttl_active"
        , get_json_object($"value" cast "string", "$.atis_reported_time") cast "timestamp" as "atis_reported_time"
        , get_json_object($"value" cast "string", "$.kl15_pin_state") cast "int" as "kl15_pin_state"
        , get_json_object($"value" cast "string", "$.last_updated") cast "timestamp" as "last_updated"
      )

    val notify_schema = ScalaReflection.schemaFor[AssetActivityNotification].dataType.asInstanceOf[StructType]
    val active_msg_tmp = wheel_activity
      .withColumn("w_reported_time",$"reported_time")
      .withColumn("w_last_updated",$"last_updated")
      .join(
        gnss_activity
          .withColumn("g_reported_time",$"reported_time")
          .withColumn("g_last_updated",$"last_updated")
      , Seq("asset_code")
      , "left"
    )
      .withColumn("final_reported_time",$"w_reported_time" )
      .withColumn("final_last_updated",$"w_last_updated" )
      .union(
        wheel_activity
          .withColumn("w_reported_time",$"reported_time")
          .withColumn("w_last_updated",$"last_updated")
          .join(
            gnss_activity
              .withColumn("g_reported_time",$"reported_time")
              .withColumn("g_last_updated",$"last_updated")
            , Seq("asset_code")
            , "right"
          )
          .withColumn("final_reported_time",$"g_reported_time" )
          .withColumn("final_last_updated",$"g_last_updated" )
    )

    var active_final = active_msg_tmp
      if (!active_msg_tmp.columns.contains("atis_state")) {

        active_final = active_msg_tmp.withColumn("atis_state", lit(null))
          .withColumn("ttl_active", lit(null))
          .withColumn("kl15_pin_state", lit(null))
          .withColumn("atis_reported_time", lit(null))
      }
     val active_msg = PipelineUtil.dedupActivityToLatest(active_final
         .select(
        $"asset_code"
        , $"final_reported_time" as "reported_time"
        , $"measured_speed"
        , $"measured_heading"
        , $"odometer"
        , $"odometer_total"
        , $"odometer_in_miles" as "odometer_miles"
        , $"odometer_total_in_miles" as "odometer_total_miles"
        , $"atis_state"
        , $"ttl_active"
        , $"kl15_pin_state"
        , $"atis_reported_time"
        , lit(current_timestamp()) as "prev_reported_time"
        , lit(-1) as "prev_odometer"
        , lit(-1) as "prev_odometer_total"
        , lit(-1) as "prev_odometer_miles"
        , lit(-1) as "prev_odometer_total_miles"
        , lit(-1) as "active_trip"
        , lit(-1) as "distance_travelled"
        , lit(-1) as "active_duration"
        , lit(-1) as "total_duration"
        , lit(-1) as "total_distance_travelled"
        , lit(null) as "prev_atis_state"
        , lit(null) as "prev_atis_reported_time"
        , lit("false") as "moving"
        , $"final_last_updated" as "last_updated"
        , lit(0) as "checkpoint_timestamp"
      )
    )
      .where( $"asset_code" isNotNull )
      .select(notify_schema.fields.toList.map(r => col(r.name)): _*)
      .as[AssetActivityNotification]
       .persist(StorageLevel.MEMORY_AND_DISK)

    PipelineUtil.appLogger.info(s"Activity Messages in Batch $batchId are: ${active_msg.count()}")

    val assets_with_actvty = prevActivity.join(
        active_msg.select(
          $"asset_code"
          , $"reported_time" as "new_reported_time"
          , $"odometer" as "new_odometer"
          , $"odometer_total" as "new_odometer_total"
          , $"odometer_miles" as "new_odometer_miles"
          , $"odometer_total_miles" as "new_odometer_total_miles"
          , $"atis_state" as "new_atis_state"
          , $"ttl_active" as "new_ttl_active"
          , $"kl15_pin_state" as "new_kl15_pin_state"
          , $"atis_reported_time" as "new_atis_reported_time"
        )
        , Seq("asset_code")
        , "right"
      )
        .where( $"asset_code" isNotNull  )
        .withColumn("total_duration"
          ,when($"total_duration" isNull, 0).otherwise($"total_duration")
        )
        .withColumn("total_distance_travelled"
          ,when($"total_distance_travelled" isNull, 0).otherwise($"total_distance_travelled")
        )
        .withColumn("distance_travelled"
          ,when($"distance_travelled" isNull, 0).otherwise($"distance_travelled")
        )
        .withColumn("total_duration"
          ,when($"total_duration" isNull, 0).otherwise($"total_duration")
        )
        .withColumn("prev_reported_time",$"reported_time")
        .withColumn("prev_odometer",$"odometer")
        .withColumn("prev_odometer_total",$"odometer_total")
        .withColumn("prev_odometer_miles",$"odometer_miles")
        .withColumn("prev_odometer_total_miles",$"odometer_total_miles")
        .withColumn("prev_atis_state"
          , when(($"atis_state" isNull) || (($"atis_state" =!= $"new_atis_state") && ($"new_atis_state" isNotNull) )
            , $"atis_state"
          ).otherwise($"prev_atis_state")
        )
        .withColumn("atis_state"
          , when(($"atis_state" isNull) || (($"atis_state" =!= $"new_atis_state") && ($"new_atis_state" isNotNull) )
            , $"new_atis_state"
          ).otherwise($"atis_state")
        )
        .withColumn("prev_atis_reported_time"
          , when(($"atis_state" isNull) || (($"atis_state" =!= $"new_atis_state") && ($"new_atis_state" isNotNull) )
            , $"atis_reported_time"
          ).otherwise($"prev_atis_reported_time")
        )
        .withColumn("atis_reported_time"
          , when(($"atis_state" isNull) || (($"atis_state" =!= $"new_atis_state") && ($"new_atis_state" isNotNull) )
            , $"new_atis_reported_time"
          ).otherwise($"atis_reported_time")
        )
        .withColumn("active_trip"
          , when(
            abs( ($"new_reported_time" cast "long") - ($"reported_time" cast "long")) < (60 * 30)
            , 1
          ).otherwise(0)
        )
        .withColumn("measured_speed"
          , when($"measured_speed" isNull, 0).otherwise($"measured_speed")
        )
        .withColumn("moving"
          , when(
            //abs( ($"new_reported_time" cast "long") - ($"prev_reported_time" cast "long")) > (60 * 30)
            $"measured_speed" > 0
            , "true"
          ).otherwise(
            when( $"new_odometer_miles" > $"prev_odometer_miles", "true"

            ).otherwise("false")
          )
        )
        .withColumn("distance_travelled"
          , when($"active_trip" === 1
            , when(
              coalesce($"new_odometer_miles",lit(0)) - coalesce($"odometer_miles",lit(0)) <= 0
              , $"distance_travelled"
            ).otherwise($"distance_travelled" + coalesce($"new_odometer_miles",lit(0)) - coalesce($"odometer_miles",lit(0)))
          ).otherwise(0)
        )
        .withColumn("total_distance_travelled"
          , $"total_distance_travelled" + $"distance_travelled"
        )
        .withColumn("active_duration"
          , when($"active_trip" === 1
          , $"active_duration" + abs( ($"new_reported_time" cast "long") - ($"reported_time" cast "long"))
          ).otherwise(0)
        )
        .withColumn("total_duration"
          , $"active_duration" + $"total_duration"
        )
        .withColumn("prev_reported_time", $"reported_time")
        .withColumn("reported_time", $"new_reported_time")
        .withColumn("odometer",$"new_odometer")
        .withColumn("odometer_total",$"new_odometer_total")
        .withColumn("odometer_miles",$"new_odometer_miles")
        .withColumn("odometer_total_miles",$"new_odometer_total_miles")
        .withColumn("last_updated", current_timestamp() )
        .where(($"asset_code" isNotNull) && ($"reported_time" isNotNull ) )
        .select(notify_schema.fields.toList.map(r => col(r.name)): _*)
        .persist(StorageLevel.MEMORY_AND_DISK)

    val current_assets_with_actvty = assets_with_actvty
      .withColumn("checkpoint_timestamp",floor( lit( System.currentTimeMillis() / (3600 * 1000) ) ) * 3600)
      .as[AssetActivityNotification]
      .withColumn(
        "rec_rank"
        , rank over Window.partitionBy("asset_code").orderBy(asc("reported_time"))
      )
      .withColumn(
        "max_rank"
        , max("rec_rank") over Window.partitionBy("asset_code")
      )
      .where($"max_rank" === $"rec_rank") // select the last record
      .drop("max_rank","rec_rank")
      .dropDuplicates("asset_code")
      .as[AssetActivityNotification]

    val assets_count = current_assets_with_actvty.count()
    PipelineUtil.appLogger.info(s"New alert count: $assets_count")

    // persist new state
    val assetActDf = current_assets_with_actvty
      .select(
        concat_ws("-", $"asset_code") as "spark_key"
        , to_json(
          struct(current_assets_with_actvty.columns.map(col(_)): _*)
        ) as "activity_state"
        , $"asset_code"
        , $"last_updated"
        , lit(pipelineConfig.getString("asset_prev_activity_topic"))  as "topic"
      ).dropDuplicates("spark_key")

    val cached_df_schema = ScalaReflection.schemaFor[AssetActivityNotificationCache].dataType.asInstanceOf[StructType]
    val finalDf = asKafkaConnectJsonMessage(selectNCastDataFrameAsSchema(assetActDf, cached_df_schema)
      , setNullableStateForAllColumns( cached_df_schema, true)
      , Seq("schema","payload","topic","spark_key").toList
    )
      .select($"spark_key" as "key"
        , to_json(struct($"schema",$"payload")) as "value"
        , $"topic"
      )
  //  PipelineUtil.writeDataFrameToKafka(finalDf, "append", PipelineUtil.kafkaConfig)

    PipelineUtil.writeDataFrameToKafkaTopic(finalDf, "append", PipelineUtil.kafkaConfig
      , pipelineConfig.getString("asset_prev_activity_topic")
    )


    assets_with_actvty.unpersist()
    active_msg.unpersist()
  }

  def doNotificationEventsProcessing() {

    val AllMessage = PipelineUtil.readDataFrameFromKafka(
      pipelineConfig.getString("asset_activity_topic")
      , PipelineUtil.kafkaConfig
    )

    // persist wheel information
    AllMessage.writeStream
      .trigger(Trigger.ProcessingTime("1 minutes"))
      .outputMode("append")
      //.option("checkpointLocation", pipelineConfig.getString("checkpoint_path") + "/asset_activity")
      .foreachBatch(processMessagesByBatch _)
      .queryName("Process Asset Activity Notifications")
      .start()
  }
}
