package com.sensata.data_office.utilities

import com.sensata.data_office.batch.DashBoardDataPipeline.spark.implicits._
import com.sensata.data_office.data.{MessageTypes, WarningEvent, WheelPressureData, WheelTemperatureData}
import org.apache.spark.sql.catalyst.ScalaReflection
import org.apache.spark.sql.expressions.{Window, WindowSpec}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{Column, DataFrame, Row, SparkSession}
import org.apache.spark.storage.StorageLevel

import java.sql.{Connection, DriverManager}
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Properties

object Analytics {

  def doUpdateDashboardWheelHistoryMappingtable(dbOpt: Properties, src_tablename: String
                                                , mapping_table_name: String = "public.dashboard_wheel_data_bridge"
                                                , mapping_key: String="wheel_key") = {

    // make the connection
    Class.forName(dbOpt.getProperty("Driver"))
    val connection:Connection = DriverManager.getConnection(dbOpt.getProperty("jdbcuri"), dbOpt)
    connection.setAutoCommit(true)

    val statement = connection.createStatement()

    // purge table
    statement.execute(
      s"""
         |INSERT into $mapping_table_name($mapping_key)
         |select $mapping_key
         |from $src_tablename
         |ON conflict ($mapping_key) do nothing ;
         |""".stripMargin)

    connection.close()
  }

  def doUpdateDashboardVehicleKeyMappingtable(dbOpt: Properties, src_tablename: String
  , mapping_table_name: String = "public.dashboard_vehicle_data_bridge", mapping_key: String="vehicle_key") = {
    doUpdateDashboardWheelHistoryMappingtable(dbOpt,src_tablename,mapping_table_name,mapping_key)
  }

  def doDatabaseOverwrite(dbOpt: Properties, load_query: String, purge_query: String) = {

    // make the connection
    Class.forName(dbOpt.getProperty("Driver"))
    val connection:Connection = DriverManager.getConnection(dbOpt.getProperty("jdbcuri"), dbOpt)
    connection.setAutoCommit(true)

    val statement = connection.createStatement()

    // purge table
    statement.execute(purge_query)
    // load table
    statement.execute(load_query)

    connection.close()
  }

  def truncateSnapshoTable(dbOpt: Properties, tablename: String) = {

    // make the connection
    Class.forName(dbOpt.getProperty("Driver"))
    val connection:Connection = DriverManager.getConnection(dbOpt.getProperty("jdbcuri"), dbOpt)
    connection.setAutoCommit(true)

    // create the statement, and run the select query
    val statement = connection.createStatement()
    statement.execute(s"DELETE FROM $tablename")

    connection.close()
  }

  def doDatabaseMerge(dbOpt: Properties, query: String, staging_tablename: String, truncate_staging: Boolean = false) = {

    // make the connection
    Class.forName(dbOpt.getProperty("Driver"))
    val connection:Connection = DriverManager.getConnection(dbOpt.getProperty("jdbcuri"), dbOpt)
    connection.setAutoCommit(true)

    // create the statement, and run the select query
    val statement = connection.createStatement()
    val resultSet = statement.execute(query)
    if (resultSet && truncate_staging) {
      statement.execute(s"DELETE FROM $staging_tablename")
    }

    connection.close()
  }

  def udf_getPressureGroupBin = udf((pressure_val:Int, metric:String) => {
    pressure_val match {
      case x if 0 until 44 contains x => s"Extra Low $metric"
      case x if 44 until 80 contains x => s"Low $metric"
      case _ => s"Normal $metric"
    }
  })

  def udf_get24HrsTimeBin = udf((a_hour:Int ) => {
    a_hour match {
      case x if 0 until 5 contains x => "Hours 00-04"
      case x if 5 until 9 contains x => "Hours 05-09"
      case x if 9 until 13 contains x => "Hours 09-12"
      case x if 13 until 17 contains x => "Hours 13-16"
      case x if 17 until 21 contains x => "Hours 17-20"
      case _ => "Hours 21-23"

    }
  })


  def udf_get30DaysBin = udf((a_day:Int ) => {
    // group into
    a_day match {
      case x if 1 until 6 contains x => "Day 01-05"
      case x if 6 until 12 contains x => "Day 06-11"
      case x if 12 until 17 contains x => "Day 12-16"
      case x if 17 until 23 contains x => "Day 17-22"
      case x if 23 until 29 contains x => "Day 23-28"
      case _ => "Day 29-30"
    }
  })

  def udf_calulateDistance2Points =  udf((lon1: Double, lat1: Double,lon2: Double, lat2: Double ) => {
    val rad_earth_miles = 3958.8

    if (lat2 != 0 && lon2 != 0) {
      val Q1 = lat1 * Math.PI / 180; // φ, λ in radians
      val Q2 = lat2 * Math.PI / 180;
      val Dq = (lat2 - lat1) * Math.PI / 180;
      val Dd = (lon2 - lon1) * Math.PI / 180;

      val a = (Math.sin(Dq / 2) * Math.sin(Dq / 2)) + (Math.cos(Q1) * Math.cos(Q2) * Math.sin(Dd / 2) * Math.sin(Dd / 2))

      val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
      rad_earth_miles * c
    } else {
      val c = 0
      rad_earth_miles * c
    }

  })

  def allocateAllRequiredRecords1(df: DataFrame, df_unique_keys: Seq[String], field_type_map: Map[String,String], isdays: Boolean, record_count: Int, run_freq: String, rec_rank_wnd:WindowSpec, spark: SparkSession) = {

   /* df
      .select(df_unique_keys.filter(!Seq("reported_time", "reported_time_dashboard_format").contains(_)).map(col(_)): _*)
      .dropDuplicates(df_unique_keys.filter(!Seq("reported_time", "reported_time_dashboard_format").contains(_)))
      .show(false)*/
    //sys.exit()

    var list30day: Seq[Row] = Seq()
    var reporting_time: Seq[Row] = Seq()
    val formatterDay = DateTimeFormatter.ofPattern("yyyy-MM-dd 00:00:00")
    val formatterHour = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:00:00")

    val reporting_time_list = isdays match {
      case true =>
        (1 to record_count).toList.map(v => "Day " + "%02d".format(v)).toList zip
          (record_count to 1 by -1).toList.map(v => LocalDateTime.now().minusDays(v).format(formatterDay)).toList

      case _ =>
        (1 to record_count).toList.map(v => "Hour " + "%02d".format(v)).toList zip
          (record_count to 1 by -1).toList.map(v => LocalDateTime.now().minusHours(v).format(formatterHour)).toList
    }

    val keys_2_days_df = spark.createDataFrame(
      spark.sparkContext.parallelize(reporting_time_list.map(v => Row(v._1, v._2)))
      , new StructType()
        .add(StructField("reported_time_dashboard_format", StringType, false))
        .add(StructField("reported_time", StringType, false))
    )
      .withColumn("reported_time", col("reported_time") cast "timestamp")
      .join(
        df
          .select(df_unique_keys.filter(!Seq("reported_time", "reported_time_dashboard_format").contains(_)).map(col(_)): _*)
          .dropDuplicates(df_unique_keys.filter(!Seq("reported_time", "reported_time_dashboard_format").contains(_)))
        )

    //keys_2_days_df.show(false)
    //keys_2_days_df.write.format("csv").option("header","true")
    //.save("C:///Users//x3079432//Desktop//test_alert/keys_2_days_df_24")
    //sys.exit()

    val keys_2_days_df_new = keys_2_days_df
      .toDF("reported_time_dashboard_format","reported_time","asset_code","location","alert_name","frequency","topic","topic_id")

     keys_2_days_df_new.join(
      df.drop("reported_time_dashboard_format")
      , df_unique_keys.filter(_ != "reported_time_dashboard_format")
     , "left"
    )
      .where(
        (col("asset_code") isNotNull) && (col("reported_time") isNotNull)
     )
   // alert_df.show(22,false)
    //sys.exit()
   // alert_df
      .withColumn("run_period"
        , when(
          col("run_period") isNull
          , lit(run_freq.replace("  ", " ").replace(" ", "_"))).otherwise(col("run_period"))
      )
      .withColumn("rec_rank"
        , rank over rec_rank_wnd.orderBy(asc("reported_time"))
      )
      .withColumn("reported_time_dashboard_group"
        , when(col("run_period") === lit("24_Hours")
          , udf_get24HrsTimeBin(col("rec_rank"))
        ).otherwise(
          when(
            col("run_period") === lit("7_Days")
            , concat_ws(" ", lit("Day"), lpad(col("rec_rank"), 2, "0"))
          ).otherwise(
            udf_get30DaysBin(col("rec_rank"))
          )
        ) // $"reported_time_dashboard_format"
      )
      .drop("agg_date", "rec_rank")
      .na.fill(
      field_type_map.map(v => {
        v._2 match {
          case "integer" => (v._1 -> -255)
          case "float" => (v._1 -> -255)
          case "long" => (v._1 -> -255)
          case "double" => (v._1 -> -255)
          case "boolean" => (v._1 -> 0)
          case "timestamp" => (v._1 -> System.currentTimeMillis() / 1000)
          case _ => (v._1 -> "N/A")
        }
      })

    )

   // alert_df.show(25,false)
    //sys.exit()
   // alert_df
  }

  def allocateAllRequiredRecords2(df: DataFrame, df_unique_keys: Seq[String], field_type_map: Map[String,String], isdays: Boolean, record_count: Int, run_freq: String, rec_rank_wnd:WindowSpec, spark: SparkSession) = {


    var list30day: Seq[Row] = Seq()
    var reporting_time: Seq[Row] = Seq()
    val formatterDay = DateTimeFormatter.ofPattern("yyyy-MM-dd 00:00:00")
    val formatterHour = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:00:00")

    val reporting_time_list = isdays match {
      case true =>
        (1 to record_count).toList.map(v => "Day " + "%02d".format(v)).toList zip
          (record_count to 1 by -1).toList.map(v => LocalDateTime.now().minusDays(v).format(formatterDay)).toList

      case _ =>
        (1 to record_count).toList.map(v => "Hour " + "%02d".format(v)).toList zip
          (record_count to 1 by -1).toList.map(v => LocalDateTime.now().minusHours(v).format(formatterHour)).toList
    }

    val keys_2_days_df = spark.createDataFrame(
      spark.sparkContext.parallelize(reporting_time_list.map(v => Row(v._1, v._2)))
      , new StructType()
        .add(StructField("reported_time_dashboard_format", StringType, false))
        .add(StructField("reported_time", StringType, false))
    )
      .withColumn("reported_time", col("reported_time") cast "timestamp")
      .join(
        df
          .select(df_unique_keys.filter(!Seq("reported_time", "reported_time_dashboard_format").contains(_)).map(col(_)): _*)
          .dropDuplicates(df_unique_keys.filter(!Seq("reported_time", "reported_time_dashboard_format").contains(_)))
      )

   /* val keys_2_days_df_new1 = keys_2_days_df
      .toDF("reported_time_dashboard_format","reported_time","asset_code","frequency","topic","topic_id")*/

    keys_2_days_df.join(
      df.drop("reported_time_dashboard_format")
      , df_unique_keys.filter(_ != "reported_time_dashboard_format")
      , "left"
    )
      .where(
        (col("asset_code") isNotNull) && (col("reported_time") isNotNull)
      )
     .withColumn("run_period"
        , when(
          col("run_period") isNull
          , lit(run_freq.replace("  ", " ").replace(" ", "_"))).otherwise(col("run_period"))
      )
      .withColumn("rec_rank"
        , rank over rec_rank_wnd.orderBy(asc("reported_time"))
      )
      .withColumn("reported_time_dashboard_group"
        , when(col("run_period") === lit("24_Hours")
          , udf_get24HrsTimeBin(col("rec_rank"))
        ).otherwise(
          when(
            col("run_period") === lit("7_Days")
            , concat_ws(" ", lit("Day"), lpad(col("rec_rank"), 2, "0"))
          ).otherwise(
            udf_get30DaysBin(col("rec_rank"))
          )
        ) // $"reported_time_dashboard_format"
      )
      .drop("agg_date", "rec_rank")
      .na.fill(
      field_type_map.map(v => {
        v._2 match {
          case "integer" => (v._1 -> -255)
          case "float" => (v._1 -> -255)
          case "long" => (v._1 -> -255)
          case "double" => (v._1 -> -255)
          case "boolean" => (v._1 -> 0)
          case "timestamp" => (v._1 -> System.currentTimeMillis() / 1000)
          case _ => (v._1 -> "N/A")
        }
      })
    )
  }

  def addTpmsGroupingColumns(df: DataFrame) = {
    df.
      withColumn("low_pressure_value"
      ,when(col("measured_pressure_psi") between (44,80), col("measured_pressure_psi")).otherwise(0)
    )
      .withColumn("extra_low_pressure_value"
        ,when(col("measured_pressure_psi") between (0,44), col("measured_pressure_psi")).otherwise(0)
      )
      .withColumn("normal_pressure_value"
        ,when(col("measured_pressure_psi") >= 80, col("measured_pressure_psi")).otherwise(0)
      )
      .withColumn("low_temperature_value"
        ,when(col("measured_temperature_f") between (44,80), col("measured_temperature_f")).otherwise(0)
      )
      .withColumn("extra_low_temperature_value"
        ,when(col("measured_temperature_f") < 44, col("measured_temperature_f")).otherwise(0)
      )
      .withColumn("normal_temperature_value"
        ,when(col("measured_temperature_f") between (0,185), col("measured_temperature_f")).otherwise(0)
      )
  }

  def getRelevantMessagesByTPMSStream(alert_df: DataFrame, timestamp_match_threshold:Int) = {

    alert_df
      .withColumn("next_alert_duration"
        , lead("duration", 1) over Window.partitionBy("asset_code", "location","alert_name").orderBy(asc("reported_time"))
      )
      .withColumn("next_report_timestamp"
        , lead("reported_time", 1) over Window.partitionBy("asset_code", "location","alert_name").orderBy(asc("reported_time"))
      )
      .withColumn("trip_duration"
        , when(
          col("next_report_timestamp") isNull
          , lit(0)
        ).otherwise(
          when(
            col("active") === -1
            , lit(0)
          ).otherwise(abs(col("next_report_timestamp").cast("long")  - col("reported_time").cast("long")))
        )
      )
      .withColumn("active_alert_duration"
        , when(col("next_alert_duration") isNull
          , lit(0)
        ).otherwise(
          when(
            col("active") === -1
            , lit(0)
          ).otherwise(abs(col("next_alert_duration")  - col("duration")))
        )
      )
      .withColumn("alert_duration"
        , when(col("next_alert_duration") isNull
          , lit(0)
        ).otherwise(
          abs(col("next_alert_duration")  - col("duration"))
        )
      )
      .where(col("trip_duration") < timestamp_match_threshold * 4 ) // if over 20min, we assume van was off
      .persist(StorageLevel.MEMORY_AND_DISK)
  }

  def flattenAnalyticalMessage(df: DataFrame): DataFrame = {

    val press_data_schema = ScalaReflection.schemaFor[WheelPressureData].dataType.asInstanceOf[StructType]
    val temp_data_schema = ScalaReflection.schemaFor[WheelTemperatureData].dataType.asInstanceOf[StructType]
    val warn_data_schema = ScalaReflection.schemaFor[WarningEvent].dataType.asInstanceOf[StructType]

    val alerts_snapshots = df
      .select(
        $"data.trigger.time" cast "timestamp" as "trigger_reported_time"
        ,$"data.trigger.data" as "trigger_data"
        , $"data.trigger.resource" as "alert_resource"
        ,  explode($"data.additional_data") as "tpms"
        , $"asset_id"
        , $"asset_code"
      )
      .select(
        $"trigger_reported_time"
        , $"alert_resource"
        , from_json($"trigger_data" cast "string" , warn_data_schema ) as "warn_data"
        , $"asset_id"
        , $"asset_code"
        , $"tpms.*"
      )
      .select(
        $"trigger_reported_time"
        , $"service"
        , $"alert_resource"
        , $"resource"
        , $"asset_id"
        , $"asset_code"
        , $"time" cast "timestamp" as "data_reported_time"
        , $"data"
        , $"warn_data.*"
      )
      .withColumn("data_temp"
        , when($"resource" === "wheel/temperature"
          , from_json($"data" cast "string" , temp_data_schema )
        ).otherwise(lit(null))
      )
      .withColumn("data_press"
        ,when($"resource" === "wheel/pressure"
          , from_json($"data" cast "string" , press_data_schema )
        ).otherwise(lit(null))
      )
      .withColumn("temperature"
        ,when($"resource" === "wheel/temperature"
          , $"data_temp.temperature"
        ).otherwise(lit(null) )
      )
      .withColumn("pressure"
        , when($"resource" === "wheel/pressure"
          , $"data_press.pressure.measured"
        ).otherwise(lit(null) )
      )
      .withColumn("temp_comp_pressure"
        ,when($"resource" === "wheel/pressure"
          , $"data_press.pressure.temp_comp"
        ).otherwise(lit(null) )
      )

      .withColumn("temperature_f", round(((($"temperature" cast "float") * (9 / 5)) + 32), 1))
      .withColumn("pressure_psi", round((($"pressure" cast "float") / 68.9476), 2))
      .where(
        ($"location" === upper($"data_temp.location")) || ($"location" === upper($"data_press.location"))
      )

    alerts_snapshots
      .select(
        (($"trigger_reported_time" cast "long") / 1000) cast "timestamp" as "reported_time"
        , $"service"
        , $"alert_resource"
        , $"location"
        , $"category"
        , $"asset_id"
        , $"asset_code"
        , $"temperature"
        , $"temperature_f"
      )
      .where(
        $"resource" === MessageTypes.WheelInfoTemperature
      ).join(
      alerts_snapshots.select(
        (($"trigger_reported_time" cast "long") / 1000) cast "timestamp" as "reported_time"
        , $"service"
        , $"alert_resource"
        , $"location"
        , $"category"
        , $"asset_id"
        , $"asset_code"
        , $"pressure"
        , $"pressure_psi"
        , $"temp_comp_pressure"
      )
        .where(
          $"resource" === MessageTypes.WheelInfoPressure
        )
      , Seq("reported_time", "service", "alert_resource", "location", "category", "asset_id", "asset_code")
      , "outer"
    )
      .withColumnRenamed("alert_resource","resource")
      .dropDuplicates("asset_code","reported_time", "service", "resource", "location", "category")
  }

  def addAlertFeatures_new(df: DataFrame): DataFrame = {

    df.unpersist()

    val byDeviceId = Window.partitionBy("asset_code", "location","agg_date","alert_name").orderBy(asc("reported_time"))
    val active_alerts = df
      .select("asset_code", "location","agg_date","alert_name","active","duration","previous_active_duration","reported_time")
      .where(col("active") === lit(1)) // alert is active
      .withColumn("rowid"
        , rank over byDeviceId
      )
      .withColumn("next_alert_duration"
        , lag("duration", 1,0) over byDeviceId
      )
      .withColumn("alert_state_duration"
        , abs(col("duration") - col("next_alert_duration"))
      )
      .withColumn(
      "on_alerts_max_rank"
      , max("rowid") over Window.partitionBy("asset_code", "location","agg_date","alert_name")
    ).withColumn(
      "on_alerts_max_duration"
      , max("duration") over Window.partitionBy("asset_code", "location","agg_date","alert_name")
    ).withColumn(
      "on_alerts_max_previous_active_duration"
      , max("previous_active_duration") over Window.partitionBy("asset_code", "location","agg_date","alert_name")
    ).withColumn(
      "on_alerts_first_reported_time"
      , min("reported_time") over Window.partitionBy("asset_code", "location","agg_date","alert_name")
    ).withColumn(
      "on_alerts_last_reported_time"
      , max("reported_time") over Window.partitionBy("asset_code", "location","agg_date","alert_name")
    )
      .withColumn("on_alerts"
        , when(col("alert_state_duration") > 24*3600 // only take records over 24hrs as a new alert
          , lit(1)
        ).otherwise(lit(0))
      )
      .groupBy("asset_code", "location","agg_date","alert_name").agg(
      first("rowid",ignoreNulls = true) as "rowid"
      , sum("on_alerts") as "total_on_alerts"
      , sum("alert_state_duration") as "total_on_alert_duration"
      ,first("on_alerts_max_rank",ignoreNulls = true) as "on_alerts_max_rank"
      ,first("on_alerts_max_duration",ignoreNulls = true) as "on_alerts_max_duration"
      ,first("on_alerts_max_previous_active_duration",ignoreNulls = true) as "on_alerts_max_previous_active_duration"
      ,first("on_alerts_first_reported_time",ignoreNulls = true) as "on_alerts_first_reported_time"
      ,first("on_alerts_last_reported_time",ignoreNulls = true) as "on_alerts_last_reported_time"
    )
      .withColumn(
        "total_on_alerts"
      , when(
          (col("total_on_alerts") === lit(0)) && (col("total_on_alert_duration") > lit(0))
        , lit(1)
      ).otherwise(col("total_on_alerts"))
    )
      .select("asset_code", "location","agg_date","alert_name","on_alerts_max_rank"
        ,"on_alerts_max_duration","on_alerts_max_previous_active_duration"
      ,"on_alerts_first_reported_time","on_alerts_last_reported_time","total_on_alerts","total_on_alert_duration")

    val inactive_alerts = df
      .select("asset_code", "location","agg_date","alert_name","active","duration","previous_active_duration","reported_time")
      .where(col("active") === lit(-1)) // alert is off
      .withColumn("rowid"
        , rank over byDeviceId
      )
      .withColumn(
      "off_alerts_max_rank"
      , max("rowid") over Window.partitionBy("asset_code", "location","agg_date","alert_name")
    ).withColumn(
      "off_alerts_max_duration"
      , max("duration") over Window.partitionBy("asset_code", "location","agg_date","alert_name")
    ).withColumn(
      "off_alerts_max_previous_active_duration"
      , max("previous_active_duration") over Window.partitionBy("asset_code", "location","agg_date","alert_name")
    ).withColumn(
      "off_alerts_max_previous_active_duration"
      , max("previous_active_duration") over Window.partitionBy("asset_code", "location","agg_date","alert_name")
    ).withColumn(
      "off_alerts_first_reported_time"
      , min("reported_time") over Window.partitionBy("asset_code", "location","agg_date","alert_name")
    ).withColumn(
      "off_alerts_last_reported_time"
      , max("reported_time") over Window.partitionBy("asset_code", "location","agg_date","alert_name")
    )
      .groupBy("asset_code", "location","agg_date","alert_name").agg(
      first("rowid",ignoreNulls = true) as "rowid"
      ,first("off_alerts_max_rank",ignoreNulls = true) as "off_alerts_max_rank"
      ,first("off_alerts_max_duration",ignoreNulls = true) as "off_alerts_max_duration"
      ,first("off_alerts_max_previous_active_duration",ignoreNulls = true) as "off_alerts_max_previous_active_duration"
      ,first("off_alerts_first_reported_time",ignoreNulls = true) as "off_alerts_first_reported_time"
      ,first("off_alerts_last_reported_time",ignoreNulls = true) as "off_alerts_last_reported_time"
    )
      .select("asset_code", "location","agg_date","alert_name","off_alerts_max_rank"
        ,"off_alerts_max_duration","off_alerts_max_previous_active_duration"
      ,"off_alerts_first_reported_time","off_alerts_last_reported_time")

    df.join(
      active_alerts
      , Seq("asset_code", "location","agg_date","alert_name")
      , "left"
    ).join(
      inactive_alerts
      , Seq("asset_code", "location","agg_date","alert_name")
      , "left"
    )
      .na.fill(0)

  }

  def selectNCastDataFrameAsSchema(df: DataFrame, data_schema: StructType): DataFrame = {
    df.select(
      (data_schema
        .fields
        .map( r => col(r.name).cast(r.dataType.simpleString))
        .toList
        ++ df
        .columns
        .filter(!data_schema.fields.map(_.name).toList.contains(_))
        .map(col(_))
        .toList):_*
    )
  }

  def getAssetActivityDays(vehicleDf: DataFrame, wheelDf:DataFrame, alertDf: DataFrame): DataFrame = {
    vehicleDf.select(
      $"asset_code"
      ,$"reported_time"
      ,$"agg_date" as "active_day"
    ).union(
      wheelDf.select(
        $"asset_code"
        ,$"reported_time"
        ,$"agg_date" as "active_day"
      )
    ).union(
      alertDf.select(
        $"asset_code"
        ,$"reported_time"
        ,$"agg_date" as "active_day"
      )
    ).groupBy("asset_code","active_day").agg(
      min("reported_time") as "first_active_reported_time"
      , max("reported_time") as "last_active_reported_time"
    )
      .withColumn("active_duration"
        , sum(
          abs(($"last_active_reported_time" cast "long") - ($"first_active_reported_time" cast "long")) / 3600
        ) over Window.partitionBy("asset_code", "active_day")
      )
  }

  def allocateAlertDurationNMetric(alertDf: DataFrame, actvDf: DataFrame, metricDf: DataFrame): DataFrame = {
    alertDf.join( // get min/max active reported_times
      actvDf
      , Seq("asset_code","active_day")
      , "left"
    )
     .join(metricDf
        .select(
          $"reported_time" as "metric_reported_time"
          , lit("alerts-curated") as "service"
          , $"asset_code"
          , $"resource"
          , $"location"
          , $"temperature_f" cast "double" as "measured_temperature"
          , $"pressure_psi" cast "double" as "measured_pressure"
        )
      , Seq("asset_code","service","resource", "location")
      , "left"
    )
     .where(
        abs( ($"metric_reported_time" cast "long") - ($"reported_time" cast "long") ) <= 300 // 5 minutes
      )
      .withColumn("alert_duration_from_active_date"
        , abs( ($"active_day" cast "long") - ($"reported_time" cast "long") ) / 3600
      )
      .withColumn("alert_duration_from_alert_start_date"
        , abs( ($"alert_start_time" cast "long") - ($"reported_time" cast "long") )  / 3600
      )
      .withColumn("alert_duration_by_date"
        , when($"alert_duration_from_active_date" < $"alert_duration_from_alert_start_date"
          , $"alert_duration_from_active_date"
        ).otherwise($"alert_duration_from_alert_start_date")
      )
  }

  def allocateAlertTripInformation(alertDf: DataFrame, tripDf: DataFrame): DataFrame = {
    alertDf
      .join(   // add trip information.
        tripDf
          .select(
            $"asset_code" as "join_key"
            ,$"trip_start_time"
            ,$"trip_stop_time"
            ,$"trip_duration"
            ,$"trip_distance"
          )
        , (
          ($"asset_code" === $"join_key")
            && ($"reported_time" between($"trip_start_time",$"trip_stop_time")) // between trip_start and trip_start 10min
          )
        ,"left"
      )
      .withColumn("alert_at_trip_start"
        , when(($"alert_end_time" isNull) && ($"alert_status" === 1)
          , 1
        ).otherwise(
          when(
            ( ($"alert_start_time" cast "long") <= (($"trip_start_time" cast "long") + (10*60)) )
              && (($"alert_end_time" cast "long") > ($"trip_start_time" cast "long") ) && ($"alert_status" === 1)
            , 1
          ).otherwise(0)
        )
      )
      .withColumn("alert_during_trip"
        , when(
          $"trip_start_time" isNotNull
          , 1
        ).otherwise(0)
      )
  }

  def allocateAlertDistancetoAlerts(alertDf: DataFrame, dstAlrtDf: DataFrame): DataFrame = {
    alertDf
      .withColumn("alert_end_time_join"  // nulls don't do joins
        ,when($"alert_end_time" isNull, "1900-01-01 00:00:00").otherwise($"alert_end_time")
      )
      .join(
      dstAlrtDf.select(
        $"asset_code"
        , $"resource"
        , $"location"
        , $"alert_start_time"
        , $"event_start_time"
        , $"alert_distance" as "alert_distance_new"
        , when($"alert_end_time" isNull, "1900-01-01 00:00:00").otherwise($"alert_end_time") as "alert_end_time_join"
      )
      , Seq("asset_code", "resource","location", "alert_start_time", "alert_end_time_join", "event_start_time")
      ,"left"
    )
      .withColumn("alert_distance", coalesce($"alert_distance",$"alert_distance_new"))
      .drop("alert_distance_new","alert_end_time_join")
  }
  def getDistinctDistanceWithAlerts(alertDf: DataFrame, dstAlrtDf: DataFrame): DataFrame = {
    alertDf.select(
      $"asset_code"
      , $"resource"
      , $"location"
      , $"alert_start_time"
      , $"alert_end_time"
      , $"event_start_time"
    ).dropDuplicates().join(
      dstAlrtDf
        .select(
          $"asset_code" as "dist_join_key"
          , $"reported_time" as "v_reported_time"
          , $"distance_travelled_with_alert" as "v_distance_travelled_with_alert"
        )
      , (
        ($"asset_code" === $"dist_join_key") && ($"v_reported_time" between($"alert_start_time",coalesce($"alert_end_time",current_timestamp())))
        )
      ,"left"
    )
      .withColumn("alert_distance"
        , sum(coalesce($"v_distance_travelled_with_alert",lit(0))) over Window.partitionBy("asset_code", "location","resource","alert_start_time","alert_end_time")
      )
      .withColumn("max_alert_distance_reported_time" // get the last matching reported time from the vehicle data group
        , max($"v_reported_time") over Window.partitionBy("asset_code", "location","resource","alert_start_time","alert_end_time")
      )
      .where($"max_alert_distance_reported_time" === $"v_reported_time")
  }

  def getDistanceWithAlerts(df: DataFrame): DataFrame = {
    val byDeviceId = Window.partitionBy("asset_code").orderBy(asc("reported_time"))
    df
      .where($"device_has_alerts" > 0)
      .select($"asset_code"
        , $"reported_time"
        , $"odometer_in_miles"
        , $"moving"
        , $"active_trip"
      )
      .withColumn("prev_odometer_in_miles"
        , lag($"odometer_in_miles", 1) over byDeviceId
      )
      .withColumn("next_odometer_in_miles"
        , lead($"odometer_in_miles", 1) over byDeviceId
      )
      .withColumn("distance_travelled_with_alert"
        , when($"prev_odometer_in_miles" isNull, 0
        ).otherwise(
          when(($"odometer_in_miles" isNull)
            || ($"odometer_in_miles" === 0)
            || ($"next_odometer_in_miles" === 0)
            , 0 ).otherwise(
            when(
              ($"next_odometer_in_miles" < $"odometer_in_miles")
              , $"next_odometer_in_miles"
            ).otherwise(abs($"next_odometer_in_miles" - $"odometer_in_miles"))
          )
        )
      ).select(
      $"asset_code"
      , $"reported_time"
      , $"odometer_in_miles"
      , $"moving"
      , $"active_trip"
      , $"distance_travelled_with_alert"
    )
  }
  def getTripInformation(df: DataFrame): DataFrame = {
    val byDeviceId = Window.partitionBy("asset_code").orderBy(asc("reported_time"))
    val active_alerts = df
      .select($"asset_code"
        , $"reported_time"
        , $"distance_travelled"
        , $"active_duration"
        , $"moving"
        , $"active_trip"
      )
      .withColumn("prev_active_duration"
        , lag($"active_duration", 1, -1) over byDeviceId
      )
      .withColumn("prev_distance_travelled"
        , lag($"distance_travelled", 1, -1) over byDeviceId
      )
      .withColumn("trip_stop_time"
        , when(($"active_trip" === 0) && ($"prev_active_duration" > 0)
          , $"reported_time"
        )
      )
      .withColumn("trip_duration"
        , when($"active_trip" === 0
          , $"prev_active_duration"
        )
      )
      .withColumn("trip_distance"
        , when($"active_trip" === 0
          , $"prev_distance_travelled"
        )
      )
      .withColumn("trip_start_time"
        , (($"trip_stop_time" cast "long") - $"trip_duration") cast "timestamp"
      )
      .where(
        ($"active_trip" === 1) || ( ($"active_trip" === 0) && ($"prev_active_duration" > 0) )
      )

    val trip_end_times = active_alerts.where($"trip_stop_time" isNotNull)

    active_alerts.join(
      trip_end_times.select(
        $"asset_code" as "join_key"
        ,$"trip_start_time" as "new_trip_start_time"
        ,$"trip_stop_time" as "new_trip_stop_time"
        ,$"trip_duration" as "new_trip_duration"
        ,$"trip_distance" as "new_trip_distance"
      ).dropDuplicates()
      , (
        ($"asset_code" === $"join_key")
        && ($"reported_time" between($"new_trip_start_time",$"new_trip_stop_time"))
      )
      , "left"
    )
      .withColumn("trip_start_time"
        , when(($"trip_start_time" isNull)
          , $"new_trip_start_time"   // Closed and confirmed
        ).otherwise($"trip_start_time")
      )
      .withColumn("trip_stop_time"
        , when(($"trip_stop_time" isNull)
          , $"new_trip_stop_time"   // Closed and confirmed
        ).otherwise($"trip_stop_time")
      )
      .withColumn("trip_duration"
        , when(($"trip_duration" isNull)
          , $"new_trip_duration"   // Closed and confirmed
        ).otherwise($"trip_duration")
      )
      .withColumn("trip_distance"
        , when(($"trip_distance" isNull)
          , $"new_trip_distance"   // Closed and confirmed
        ).otherwise($"trip_distance")
      )
      .drop("join_key","new_start_time","new_trip_stop_time","new_trip_duration","prev_active_duration","prev_distance_travelled")

    val uncompleted_trip = active_alerts
      .groupBy(
        "asset_code"
        ,"trip_start_time"
        ,"trip_stop_time"
        ,"trip_duration"
        ,"trip_distance"
      ).agg(
      min("reported_time") as "alt_trip_start"
    ).select(
      $"asset_code"
      ,$"trip_start_time"
      ,$"trip_stop_time"
      ,$"trip_duration"
      ,$"trip_distance"
      ,$"alt_trip_start"
      , concat_ws("-",$"asset_code",$"trip_start_time",$"trip_stop_time",$"trip_duration",$"trip_distance") as "akey"
    )

    active_alerts
      .withColumn("akey", concat_ws("-",$"asset_code",$"trip_start_time",$"trip_stop_time",$"trip_duration",$"trip_distance") )
      .join(
        uncompleted_trip.select(
          $"akey"
          , $"asset_code"
          , $"alt_trip_start"
        )
        , Seq( "asset_code","akey")
        , "left"
      )
      .withColumn("trip_start_time"
        , when(($"trip_start_time" isNull)
          , $"alt_trip_start"
        ).otherwise($"trip_start_time")
      )
      .drop("akey","alt_trip_start")
      .dropDuplicates(
        "asset_code"
        ,"trip_start_time"
        ,"trip_stop_time"
        ,"trip_duration"
        ,"trip_distance"
      ).select(
      $"asset_code"
      ,$"trip_start_time"
      ,$"trip_stop_time"
      ,$"trip_duration"
      ,$"trip_distance"
    )
      .withColumn("trip_day"
        , to_timestamp(
          from_unixtime($"trip_start_time" cast "long", "yyyy-MM-dd")
        )
      )
  }

  def correctAlertDateTimes(df: DataFrame): DataFrame = {
    val byDeviceId = Window.partitionBy("asset_code", "location","resource").orderBy(asc("reported_time"))
    df
      .select( $"service"
        ,$"asset_code"
        , $"asset_id"
        , $"location"
        ,$"resource"
        ,when($"active" isin (0,-1), 0).otherwise($"active") as "alert_status"
        ,$"category"
        ,$"battery_status"
        ,$"reported_time" cast "timestamp"
        ,$"alert_start_time" cast "timestamp"
        ,$"alert_end_time" cast "timestamp"
        ,$"event_start_time" cast "timestamp"
        ,$"duration"  cast "long"
        ,when(
          $"distance_travel_with_alert" isNull, 0
        ).otherwise(
          $"distance_travel_with_alert"
        )  cast "double" as "distance_travel_with_alert"
        ,$"topic"
        ,$"topic_id"
        ,$"agg_date"
      )
      /*.withColumn("prev_alert_status"
        , lag($"alert_status", 1) over byDeviceId
      )
      .withColumn("next_alert_status"
        , lead($"alert_status", 1) over byDeviceId
      )
      .withColumn("prev_reported_time"
        , lead($"reported_time", 1) over byDeviceId
      )*/
      .withColumn("duration"
        , when(($"alert_end_time"isNull) || ($"alert_status" isNull)
          , 0
        ).otherwise(
          $"duration"
        )
      )
      .withColumn("next_event_start_time"
        , lead($"event_start_time", 1) over byDeviceId
      )
      /*.withColumn("alert_start_time"
        , when(($"alert_start_time" isNull)
          , when( ($"alert_end_time" isNotNull)  && ( coalesce($"duration") > 0 )
            , (($"alert_end_time" cast "long") - $"duration" ) cast "timestamp"
          ).otherwise(
            when( ($"alert_end_time" isNull) && ( coalesce($"duration") > 0 )
              , (($"reported_time" cast "long") - $"duration" ) cast "timestamp"
            ).otherwise($"alert_start_time")
          )
        ).otherwise($"alert_start_time")
      )
      .withColumn("alert_end_time"
        , when( ($"alert_end_time" isNull) && ($"alert_status" === 0)
          , $"reported_time"
        ).otherwise($"alert_end_time")
      )
      .withColumn("next_reported_time"
        , lead($"reported_time", 1) over byDeviceId
      )
      .withColumn("prev_alert_status"
        , lag($"alert_status", 1) over byDeviceId
      )
      .withColumn("next_alert_status"
        , lead($"alert_status", 1) over byDeviceId
      )
      .withColumn("prev_category"
        , lag($"category", 1,-1) over byDeviceId
      )
      .withColumn("max_event_start_time"  // get last available event start time for group
        , max($"event_start_time") over byDeviceId
      )
      .withColumn("max_alert_start_time"  // get last available alert start time for group
        , max($"alert_start_time") over byDeviceId
      )
      .withColumn("alert_start_time", // set alert start time to last available for the group if not set
        when(
          ($"alert_start_time" isNull) && ($"alert_end_time" isNull)
          , $"max_alert_start_time"
        ).otherwise($"alert_start_time")
      )
      .withColumn("event_start_time", // set event start time to last available for the group if not set
        when($"event_start_time" isNull, $"max_event_start_time").otherwise($"event_start_time")
      )
      .withColumn("duration_delta"
        , when( ($"alert_status" === 0) || ($"next_reported_time" isNull)
          , lit(0)
        ).otherwise( abs( ($"next_reported_time" cast "long") - ($"reported_time" cast "long") ) / 3600 )
      )
      .withColumn("alert_end_time"
        , when(
          ($"prev_alert_status" === 1) && ($"alert_status" === 0)
          , $"reported_time"
        ).otherwise($"alert_end_time")
      )
      .withColumn("category"
        , when( ($"alert_status" === 0) && (($"category" === 0) || ($"category" isNotNull))
          , $"prev_category"
        ).otherwise($"category")
      )*/
      .withColumn("event_status"
        , when(($"event_start_time" isNotNull) && ($"alert_status" === 1)
          , 1 ).otherwise(  // Open
          when( ($"event_start_time" isNotNull) && ($"alert_status" === 0)
            , 2  // Closed and unconfirmed
          ).otherwise(0) // unknown
        )
      )
      .withColumn(
        "event_end_time"
        , when(
          ($"alert_status" === 0)
          , $"alert_end_time"
        ).otherwise(null)
      )
      .withColumn("event_status"
        , when(($"event_end_time" isNotNull) && ($"alert_status" === 0)  && ($"next_event_start_time" =!= $"event_start_time")
          , 3   // Closed and confirmed
        ).otherwise($"event_status")
      )
      .drop("next_event_start_time"
        ,"next_reported_time"
        ,"prev_category"
        ,"prev_alert_status"
        ,"next_alert_status"
        ,"next_alert_start_time"
        ,"max_alert_start_time"
        ,"max_event_start_time"
      )
  }

  def getAlertEventTimes(df: DataFrame): DataFrame = {
    val byDeviceId = Window.partitionBy("asset_code", "location","resource").orderBy(asc("reported_time"))
    val byDeviceId_noOrder = Window.partitionBy("asset_code", "location","resource")
    val active_alerts = df
      .persist(StorageLevel.MEMORY_AND_DISK)

    // get the closed event time
      val event_end_times = active_alerts
        .select(
          $"asset_code"
          ,$"location"
          ,$"resource"
          ,$"event_start_time"
          , $"reported_time"
        )
        .where($"alert_status" === 1)
        .groupBy($"asset_code"
          ,$"location"
          ,$"resource"
          ,$"event_start_time").agg(max("reported_time") as "reported_time")
        .withColumn("next_event_start_time"
          , lead($"event_start_time", 1) over byDeviceId
        )
        .withColumn("closed_event_end_time"
          , when($"next_event_start_time" > $"event_start_time"
            , $"next_event_start_time"
          ).otherwise(lit(null) cast "string")
        )
        .drop("reported_time")

    // event with distance
    val event_end_times_distance =  event_end_times .join(
      active_alerts
        .select(
          $"asset_code"
          ,$"location"
          ,$"resource"
          ,$"event_start_time"
          ,$"distance_travel_with_alert"
        ).groupBy(
        "asset_code"
        ,"location"
        ,"resource"
        ,"event_start_time"
      ).agg(
        sum("distance_travel_with_alert") as "event_distance"
      )
      , Seq("asset_code" ,"location" ,"resource" ,"event_start_time")
    )

    // close any alerts that have closed by setting the alert end time
    val active_alerts_closed = active_alerts.join(
      active_alerts
        .select(
          $"asset_code"
          ,$"location"
          ,$"resource"
          ,$"alert_start_time"
          ,$"alert_end_time" as "new_alert_end_time"
        )
        .where(($"alert_end_time" isNotNull) && ($"alert_status" === 0))
        .dropDuplicates()
      , Seq("asset_code","location","resource","alert_start_time")
      , "left"
    )
      .withColumn("alert_end_time",
        when( ($"new_alert_end_time" isNotNull) && ($"new_alert_end_time" < $"reported_time")
          , $"new_alert_end_time").otherwise($"alert_end_time")
      )
      .drop("new_alert_end_time")

    // get distance travelled
    val active_alerts_with_distance = active_alerts_closed.join(
      active_alerts_closed.select(
        $"asset_code"
        , $"location"
        ,$"resource"
        ,$"alert_start_time"
        ,$"alert_end_time"
        ,$"category"
        ,$"distance_travel_with_alert"
      )
        .groupBy("asset_code","location","resource","alert_start_time","alert_end_time","category")
        .agg(
          sum("distance_travel_with_alert") as "alert_distance"
        )
      , Seq("asset_code", "location","resource","alert_start_time","alert_end_time","category")
      , "left"
    )

    // close events
    active_alerts_with_distance.join(
      event_end_times_distance.select(
        $"asset_code"
        , $"location"
        ,$"resource"
        ,$"event_start_time"
        ,$"closed_event_end_time"
        ,$"event_distance"
      )
      , Seq("asset_code", "location","resource","event_start_time")
      , "left"
    )
      .withColumn("event_end_time"
        , when($"closed_event_end_time" isNull
          , $"alert_end_time"
        ).otherwise($"closed_event_end_time")
      )
      .withColumn("event_status"
        , when(($"closed_event_end_time" isNotNull)
          , lit(3) // event closed confirmed
        ).otherwise(
          when(($"closed_event_end_time" isNull) && ($"alert_end_time" isNotNull)
            , lit(2) // event closed unconfirmed
          ).otherwise(lit(1)) // event open
        )
      )
      .withColumn("alert_duration"
        , when($"alert_end_time" isNull
          ,  abs( (($"alert_start_time" cast "timestamp") cast "long") - ($"reported_time" cast "long") ) / 3600
        ).otherwise(
          abs( (($"alert_start_time" cast "timestamp") cast "long") - (($"alert_end_time" cast "timestamp") cast "long") ) / 3600
        ) cast "double"
      )
      .withColumn("event_duration"
        , when($"event_end_time" isNull
          ,  abs( (($"event_start_time" cast "timestamp") cast "long") - ($"reported_time" cast "long") ) / 3600
        ).otherwise(
          abs( (($"event_start_time" cast "timestamp") cast "long") - (($"event_end_time" cast "timestamp") cast "long") ) / 3600
        ) cast "double"
      )
      .withColumn("active_day"
        , to_timestamp(
          from_unixtime($"reported_time" cast "long", "yyyy-MM-dd")
        )
      )
      .where(
        ($"asset_code" isNotNull) && ($"reported_time" isNotNull) && ($"alert_start_time" isNotNull) && ($"alert_status" isNotNull)
      )
      .drop("closed_event_end_time")
  }

  def addRecordRank(df: DataFrame, for_wheel: Boolean = false): DataFrame = {

    if (!for_wheel) {
      val byDeviceId = Window.partitionBy("asset_code", "agg_date").orderBy(asc("reported_time"))
      df
        .withColumn("rowid"
          , rank over byDeviceId
        ).withColumn(
        "max_rank"
        , max("rowid") over Window.partitionBy("asset_code", "agg_date")
      )
    } else {
      val byDeviceId = Window.partitionBy("asset_code","location", "agg_date").orderBy(asc("reported_time"))
      df
        .withColumn("rowid"
          , rank over byDeviceId
        ).withColumn(
        "max_rank"
        , max("rowid") over Window.partitionBy("asset_code","location", "agg_date")
      )
    }

  }

  def addLastandFirstTime(dfWithRank: DataFrame) : DataFrame = {

    val latestrec = dfWithRank
      .select(
        col("asset_code") as "asset_code"
        , col("agg_date") as "agg_date"
        , col("reported_time") as "last_active_reported_time"
      )
      .where(col("rowid") === col("max_rank"))

    val firstrec = dfWithRank
      .select(
        col("asset_code") as "asset_code"
        , col("agg_date") as "agg_date"
        , col("reported_time") as "first_active_reported_time"
      )
      .where(col("rowid") === lit(1))

    // added latest record
    dfWithRank.join(
      latestrec
      , Seq("asset_code","agg_date")
    ).join(
      firstrec
      , Seq("asset_code","agg_date")
    )
  }

  def addLastKnowLocationAndTime(dfWithRank: DataFrame) : DataFrame = {

    val latestrec = dfWithRank
      .select(
        col("asset_code") as "asset_code"
        , col("agg_date") as "agg_date"
        , col("latitude") as "last_known_latitude"
        , col("longitude") as "last_known_longitude"
        , col("altitude") as "last_known_altitude"
        , col("measured_speed") as "last_known_speed"
        , col("measured_heading") as "last_known_heading"
        , col("reported_time") as "last_active_reported_time"
      )
      .where(col("rowid") === col("max_rank"))

    val firstrec = dfWithRank
      .select(
        col("asset_code") as "asset_code"
        , col("agg_date") as "agg_date"
        , col("latitude") as "first_known_latitude"
        , col("longitude") as "first_known_longitude"
        , col("altitude") as "first_known_altitude"
        , col("measured_speed") as "first_known_speed"
        , col("measured_heading") as "first_known_heading"
        , col("reported_time") as "first_active_reported_time"
      )
      .where(col("rowid") === lit(1))

    // added latest record
    dfWithRank.join(
      latestrec
      , Seq("asset_code","agg_date")
    ).join(
      firstrec
      , Seq("asset_code","agg_date")
      )
  }

  def calculateMilesTravelled(df: DataFrame) : DataFrame = {
    val byDeviceId = Window.partitionBy("asset_code","agg_date").orderBy(asc("reported_time"))

    df
      .withColumn("next_lat"
      , lead("latitude", 1,0) over byDeviceId
      )
      .withColumn("next_long"
        , lead("longitude", 1,0) over byDeviceId
      )
      .withColumn("next_odometer_in_miles"
        , lead("odometer_in_miles", 1,0) over byDeviceId
      )
      .withColumn("next_reported_time"
        , lead("reported_time", 1,null) over byDeviceId
      )
      .withColumn("distance_travelled"
        , when( (col("odometer_in_miles") <= 0) || (col("next_odometer_in_miles") <= 0)
         , 0
        ).otherwise( abs(col("next_odometer_in_miles") - col("odometer_in_miles")) )
      )
      .withColumn("trip_started"
        , when(
          (col("next_reported_time") isNull) ||
          (abs( ( col("next_reported_time")  cast "long" ) - ( col("reported_time")  cast "long" ) ) <= 1800)
          , 0
        ).otherwise(1)
      )
  }

  def addHoursActive(dfWithRank: DataFrame) : DataFrame = {
    val byDeviceId = Window.partitionBy("asset_code","agg_date").orderBy(asc("reported_time"))

    val dfWith_time_delta = dfWithRank.withColumn("next_reported_time"
      , lead("reported_time", 1) over byDeviceId
    )
      .withColumn("next_reported_time"
      , when(col("next_reported_time") isNull, col("reported_time") ).otherwise(col("next_reported_time"))
      )
      .withColumn("reporting_time_delta"
        , abs( (col("next_reported_time") cast "long") - (col("reported_time") cast "long") )
      )
      .withColumn("reporting_time_delta"
        , when(col("reporting_time_delta") > 1800  // only consider deltas that are less than 30min
          , lit(0)
        ).otherwise(col("reporting_time_delta"))
      )
      .withColumn( "Hrs_Active"
        , col("reporting_time_delta") / 3600
      )

      val latestrec = dfWith_time_delta.select(
        col("asset_code") as "asset_code"
        , col("agg_date") as "agg_date"
        , col("reported_time") cast "long" as "last_active_reported_epoch"
      )
      .where(col("rowid") === col("max_rank"))

    val minrec = dfWith_time_delta
      .select(
        col("asset_code") as "asset_code"
        , col("agg_date") as "agg_date"
        ,col("reported_time") cast "long" as "first_active_reported_epoch"
      )
      .where(col("rowid") === lit(1))

    // added latest record
    dfWith_time_delta.join(
      latestrec
      , Seq("asset_code","agg_date")
    ).join(
      minrec
      , Seq("asset_code","agg_date")
    )
  }

  def setAlertId(): Column = {
    when( ($"resource" === "events/warnings/pressure") && ($"category" === 0) && ($"active" === 1)
      , 4
    ).otherwise(
      when( ($"resource" === "events/warnings/pressure") && ($"category" === 3) && ($"active" === 1)
      , 3
    ).otherwise(
      when( ($"resource" === "events/warnings/pressure") && ($"category" === 2) && ($"active" === 1)
      , 2
    ).otherwise(
      when( ($"resource" === "events/warnings/pressure") && ($"category" === 1) && ($"active" === 1)
      , 1
    ).otherwise(
      when( ($"resource" === "events/warnings/temperature") && ($"category" === 1) && ($"active" === 1)
      , 5
    ).otherwise(
      when( ($"resource" === "events/warnings/temperature") && ($"category" === 0) && ($"active" === 1)
      , 6
    ).otherwise(
      when( ($"resource" === "events/warnings/fast-pressure-loss") && ($"category" === 0) && ($"active" === 1)
      , 7
    ).otherwise(
      when( ($"resource" === "events/warnings/tyre-lock") && ($"category" === 1) && ($"active" === 1)
      , 8
    ).otherwise(
       when( ($"resource" === "wheel/battery-warning") && ($"category" === 1) && ($"active" === 1)
      , 9
    ).otherwise(
      when( ($"resource" === "leak-detection") && ($"category" === 0) && ($"active" === 1)
      , 10
    ).otherwise(
      when( ($"resource" === "wheel/missing-sensor") && ($"category" === 1) && ($"active" === 1)
      , 11
    ).otherwise(
      when( ($"resource" === "wheel/pressure-warning") && ($"category" === 3) && ($"active" === 1)
      , 12
    ).otherwise(
      when( ($"resource" === "wheel/pressure-warning") && ($"category" === 2) && ($"active" === 1)
      , 13
    ).otherwise(
      when( ($"resource" === "wheel/pressure-warning") && ($"category" === 1) && ($"active" === 1)
      , 14
    ).otherwise(
      when( ($"resource" === "wheel/pressure-warning") && ($"category" === 0) && ($"active" === 1)
      , 15
    ).otherwise(
      when( ($"resource" === "wheel/temperature-warning") && ($"category" === 3) && ($"active" === 1)
      , 16
    ).otherwise(
     when( ($"resource" === "wheel/temperature-warning") && ($"category" === 2) && ($"active" === 1)
     , 17
    ).otherwise(
     when( ($"resource" === "wheel/temperature-warning") && ($"category" === 1) && ($"active" === 1)
     , 18
    ).otherwise(
     when( ($"resource" === "wheel/temperature-warning") && ($"category" === 0) && ($"active" === 1)
     , 19
    ).otherwise(
     when( ($"resource" === "wheel/dynamic-pressure-warning") && ($"category" === 0) && ($"active" === 1)
     , 20
    ).otherwise(
     when( ($"resource" === "wheel/tyre-lock-warning") && ($"category" === 1) && ($"active" === 1)
     , 21
        ).otherwise(0)
        ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) )
  }

  def setAlertIdFact(): Column = {
    when( ($"resource" === "events/warnings/pressure") && ($"category" === 0)
      , 4
    ).otherwise(
      when( ($"resource" === "events/warnings/pressure") && ($"category" === 3)
        , 3
      ).otherwise(
        when( ($"resource" === "events/warnings/pressure") && ($"category" === 2)
          , 2
        ).otherwise(
          when( ($"resource" === "events/warnings/pressure") && ($"category" === 1)
            , 1
          ).otherwise(
            when( ($"resource" === "events/warnings/temperature") && ($"category" === 1)
              , 5
            ).otherwise(
              when( ($"resource" === "events/warnings/temperature") && ($"category" === 0)
                , 6
              ).otherwise(
                when( ($"resource" === "events/warnings/fast-pressure-loss") && ($"category" === 0)
                  , 7
                ).otherwise(
                  when( ($"resource" === "events/warnings/tyre-lock") && ($"category" === 1)
                    , 8
                  ).otherwise(
                    when( ($"resource" === "wheel/battery-warning") && ($"category" === 1)
                      , 9
                    ).otherwise(
                      when( ($"resource" === "leak-detection") && ($"category" === 0)
                        , 10
                      ).otherwise(
                        when( ($"resource" === "wheel/missing-sensor") && ($"category" === 1)
                          , 11
                        ).otherwise(
                          when( ($"resource" === "wheel/pressure-warning") && ($"category" === 3)
                            , 12
                          ).otherwise(
                            when( ($"resource" === "wheel/pressure-warning") && ($"category" === 2)
                              , 13
                            ).otherwise(
                              when( ($"resource" === "wheel/pressure-warning") && ($"category" === 1)
                                , 14
                              ).otherwise(
                                when( ($"resource" === "wheel/pressure-warning") && ($"category" === 0)
                                  , 15
                                ).otherwise(
                                  when( ($"resource" === "wheel/temperature-warning") && ($"category" === 3)
                                    , 16
                                  ).otherwise(
                                    when( ($"resource" === "wheel/temperature-warning") && ($"category" === 2)
                                      , 17
                                    ).otherwise(
                                      when( ($"resource" === "wheel/temperature-warning") && ($"category" === 1)
                                        , 18
                                      ).otherwise(
                                        when( ($"resource" === "wheel/temperature-warning") && ($"category" === 0)
                                          , 19
                                        ).otherwise(
                                          when( ($"resource" === "wheel/dynamic-pressure-warning") && ($"category" === 0)
                                            , 20
                                          ).otherwise(
                                            when( ($"resource" === "wheel/tyre-lock-warning") && ($"category" === 1)
                                              , 21
                                            ).otherwise(0)
                                          ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) )
  }

  def setAlertNameValue(): Column = {
    when(col("resource") === "events/warnings/pressure" || $"resource" === "wheel/pressure-warning"
      , when(col("category") === "3" && $"active" === "1"
        , "Low Pressure Alert").otherwise(
        when(col("category") === "2" && $"active" === "1"
          , "Low Pressure Warning").otherwise(
          when(col("category") === "1" && $"active" === "1"
            , "High Pressure Warning").otherwise(
            when( col("category") === "0" && $"active" === "1"
              , "High Pressure Alert").otherwise( lit("False Pres Warning") )
           )
         )
       )
     )
    .otherwise (
      when(col("resource") === "events/warnings/temperature" || $"resource" === "wheel/temperature-warning"
        , when(col("category") === "3" && $"active" === "1"
          , "Low Temperature Alert").otherwise(
          when(col("category") === "2" && $"active" === "1"
            , "Low Temperature Warning").otherwise(
            when(col("category") === "1" && $"active" === "1"
              , "High Temperature Warning").otherwise(
              when( col("category") === "0" && $"active" === "1"
                , "High Temperature Alert").otherwise( lit("False Temp Warning") )
            )
          )
        )
      ).otherwise(
        when(col("resource") === "events/warnings/fast-pressure-loss" || $"resource" === "wheel/dynamic-pressure-warning"
          , when(col("category").cast("int") === "1" && $"active" === "1"
           , "Fast Pressure Loss Warning").otherwise(
            when(col("category") === "2" && $"active" === "1"
              , "Fast Pressure Loss Warning").otherwise(
                when(col("category") === "0" && $"active" === "1"
                  , "Fast Pressure Loss Alert").otherwise( lit("False Fast-Pres Warning") )

           )
         )
        ).otherwise(
          when(col("resource") === "events/warnings/tyre-lock" || $"resource" === "wheel/tyre-lock-warning"
            , when(col("category") === "1" && $"active" === "1"
            , "Tyre Lock Warning").otherwise(lit("False Tyre-Lock Warning") )
          )

          .otherwise(
            when($"resource" === "wheel/battery-warning"
              , when(col("category") === "1" && $"active" === "1"
              , "Battery Warning").otherwise(lit("False Battery Warning") )
            )
              .otherwise(
              when($"resource" === "wheel/missing-sensor"
                , when(col("category") === "1" && $"active" === "1"
                , "Missing Sensor Warning").otherwise( lit("False Miss-Sensor Warning"))
        ).otherwise(
                when($"resource" === "events/warnings/tyre-burst"
                  , when(col("category") === "1" && $"active" === "1"
                    , "Tyre Burst").otherwise( lit("False Tyre-Burst Warning"))
                ).otherwise("Unknown Warning")
      )

        )
      )

    )
    )
    )
  }

  def setCategoryValue(): Column = {

    when($"resource" === "wheel/pressure-warning" && $"value" === 1, 3)
      .otherwise(when($"resource" === "wheel/pressure-warning" && $"value" === 2, lit(2))
        .otherwise(when($"resource" === "wheel/pressure-warning" && $"value" === 3, lit(1))
          .otherwise(when($"resource" === "wheel/pressure-warning" && $"value" === 4, lit(0))
            .otherwise(when($"resource" === "wheel/pressure-warning" && ($"value" === 0 || $"value" === "null"), 99)
              .otherwise(when($"resource" === "wheel/temperature-warning" && $"value" === 1, lit(3))
                .otherwise(when($"resource" === "wheel/temperature-warning" && $"value" === 2, lit(2))
                  .otherwise(when($"resource" === "wheel/temperature-warning" && $"value" === 3, lit(1))
                    .otherwise(when($"resource" === "wheel/temperature-warning" && $"value" === 4, lit(0))
                      .otherwise(when($"resource" === "wheel/temperature-warning" && $"value" === 0 || $"value" === "null",99)
                        .otherwise(when($"resource" === "wheel/dynamic-pressure-warning" && $"value" === 1, 99)
                          .otherwise(when($"resource" === "wheel/dynamic-pressure-warning" && $"value" === 2, lit(0))
                            .otherwise(when($"resource" === "wheel/dynamic-pressure-warning" && $"value" === 3, 99)
                              .otherwise(when($"resource" === "wheel/dynamic-pressure-warning" && $"value" === 0 || $"value" === "null",99)
                                .otherwise(when($"resource" === "wheel/tyre-lock-warning" && $"value" === "true", lit(1))
                                  .otherwise(when($"resource" === "wheel/tyre-lock-warning" && $"value" === "false", 99)
                                    .otherwise(when($"resource" === "wheel/battery-warning" && $"value" === "true", lit(1))
                                      .otherwise(when($"resource" === "wheel/battery-warning" && $"value" === "false", 99)
                                        .otherwise(when($"resource" === "wheel/missing-sensor" && ($"value" === "true" || $"value" === 1 ), lit(1))
                                          .otherwise(when($"resource" === "wheel/missing-sensor" && ($"value" === "false" || $"value" === "null"), 99)
                                            .otherwise(lit(99)).cast("int")
                                          ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) )
    )
  }

  def setAlertNameValuev2(): Column = {
    when(col("resource") === "wheel/pressure-warning"
      , when(col("category") === "1"
        , "Low Pressure Alert").otherwise(
        when(col("category") === "2"
          , "Low Pressure Warning").otherwise(
          when(col("category") === "3"
            , "High Pressure Warning").otherwise(
            when(col("category") === "4"
              , "High Pressure Alert").otherwise(
            when( col("category") === "0"
              , "Unknown Pressure Alert").otherwise( lit("Pressure Warning ") )
            )
         )
       )
     )
    ).otherwise (
      when(col("resource") === "wheel/temperature-warning"
        , when(col("category") === "1"
          , "Low Temperature Alert").otherwise(
          when(col("category") === "2"
            , "Low Temperature Warning").otherwise(
            when(col("category") === "3"
              , "High Temperature Warning").otherwise(
              when(col("category") === "4"
                , "High Temperature Alert").otherwise(
              when( col("category") === "0"
                , "No Warning").otherwise( lit("Temp. Warning") )
            )
          )
        )
      )
    ).otherwise(
        when(col("resource") === "wheel/dynamic-pressure-warning"
          , when(col("category") === "1"
            , "Slow Pressure Loss Warning").otherwise(
            when(col("category") === "2"
              , "Fast Pressure Loss Warning").otherwise(
              when(col("category") === "3"
                , "Fast Pressure Loss Alert").otherwise(
                when(col("category") === "0"
                  , "No Pressure Loss Alert").otherwise( lit("Fast Pressure Loss Warning"))
               )
             )
           )
        ).otherwise(
          when(col("resource") === "wheel/tyre-lock-warning"
            , when(col("category") === "1"
              , "Tyre Lock Warning"))


         .otherwise(when(col("resource") === "wheel/battery-warning"
            , when(col("category") === "1", "Battery Warning")
          .otherwise( lit("Unknown Warning"))
        )
      )
    )
  )
  )
  }


  def calcAlertDurationAndDistanceByAlertType(alert_df: DataFrame): DataFrame = {
    val totals_by_alert_name = alert_df
      .groupBy("asset_code","alert_name","reported_time")
      .agg(
        max(col("alert_duration_hrs")) as "max_alert_type_duration_hrs"
        , max(col("alert_distance")) as "max_alert_type_distance_miles"
      )

    alert_df.join(
      totals_by_alert_name
      , Seq("asset_code","alert_name","reported_time")
      , "left"
    )
  }

  def flagLastDeviceHistoryRecord(df: DataFrame, req_window: Option[WindowSpec]): DataFrame = {

    val byDeviceId = req_window.getOrElse(Window.partitionBy("asset_code"))


    df
      .withColumn("rec_rank"
        , rank() over byDeviceId.orderBy(asc("reported_time")) )
      .withColumn("max_rec_id"
      , max(col("rec_rank")) over byDeviceId )
      .withColumn("is_last_device_record"
        , when(col("rec_rank") === col("max_rec_id"), lit(1)
        ).otherwise(lit(0))
      ).drop("max_rec_id").drop("rec_rank")
  }

}
