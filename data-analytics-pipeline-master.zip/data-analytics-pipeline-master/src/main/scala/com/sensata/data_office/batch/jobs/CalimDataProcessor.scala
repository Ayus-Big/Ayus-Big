package com.sensata.data_office.batch.jobs

import com.sensata.data_office.data.GenericEventData
import com.typesafe.config.ConfigFactory
import com.typesafe.scalalogging.Logger
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}
import org.slf4j.LoggerFactory

object CalimDataProcessor {

  val pipelineConfig = ConfigFactory
    .load(s"application.${sys.env("ENVIRONMENT")}.conf")
    .getConfig("RawEventsProcessor").getConfig("pipeline")
  val dimentionalCfg = ConfigFactory
    .load(s"application.${sys.env("ENVIRONMENT")}.conf")
    .getConfig("dimensional_data")

  val batchCfg = ConfigFactory
    .load(s"application.${sys.env("ENVIRONMENT")}.conf")
    .getConfig("batch_pipeline")

  val VERSION = pipelineConfig.getString("version")

  val spark = SparkSession.builder.appName(pipelineConfig.getString("application_name")).getOrCreate()

  import spark.implicits._

  val appLogger = Logger(LoggerFactory.getLogger("spark"))

  def getPartitonTimeStamp(date_format: String) = {

    to_timestamp(
      from_unixtime(unix_timestamp(), date_format)
    ).cast("long")
  }


  def filterOutInvalidMessage(df: DataFrame, version: String): DataFrame = {
    df.where($"body" cast "string" rlike (".*\"service\":\"[a-zA-z/]+\".*"))
      .where($"body" cast "string" rlike (".*\"resource\":\"[a-zA-z/]+\".*"))
      .where($"body" cast "string" rlike (".*\"data\":.*"))
      .where($"body" cast "string" rlike (".*\"version\":\"" + version + "\".*"))
  }

  def buildJsonMessage(df: Dataset[GenericEventData], event_type: String, data_schema: StructType): DataFrame = {
    df.withColumnRenamed("data", "raw_data")
      .withColumn("data", from_json($"raw_data", data_schema)
      ).select(concat_ws("-", lit(event_type), $"time") as "id"
      , from_unixtime($"time" / 1000 cast "long", "yyyy-MM-dd") as "time"
      , to_json(
        struct($"service"
          , $"resource"
          , $"device_id"
          , $"device_name"
          , $"time"
          , $"version"
          , $"timestamp"
          , $"consumed_timestamp"
          , $"data"
          , $"raw_data")
      ) as "body"
    )
  }

  def main(args: Array[String]): Unit = {

    val query = ""
    val rawCalimData = spark.read.format("jdbc")
      .load()

  }
}
