package com.sensata.data_office.utilities

import com.databricks.dbutils_v1.DBUtilsHolder.dbutils
import com.sensata.data_office.data._
import com.sensata.data_office.utilities.Analytics.selectNCastDataFrameAsSchema
import com.typesafe.config.ConfigFactory
import org.apache.spark.SparkConf
import org.apache.spark.sql.catalyst.ScalaReflection
import org.apache.spark.sql.expressions.{Window, WindowSpec}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{LongType, StructType}
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.slf4j.LoggerFactory

import java.util.Properties
import scala.collection.JavaConverters._
import scala.collection.mutable.ListBuffer

object PipelineUtil {

  def getEnvVariable(key: String, defaultVal: String = "dev"): String = {
    sys.env.getOrElse(key, defaultVal)
  }

  val sparkCfgObj = new SparkConf()

  var environment = getEnvVariable("ENVIRONMENT")

  val received_timestamp_format = ConfigFactory
    .load(s"application.${environment}.conf").getConfig("high_watermark").getString("received_timestamp_format")

  val watermark_delay_threashold = ConfigFactory
    .load(s"application.${environment}.conf").getConfig("high_watermark").getString("watermark_delay_threashold")
  val processing_trigger_time = ConfigFactory
    .load(s"application.${environment}.conf").getConfig("high_watermark").getString("processing_trigger")

  val db_cache_invalidate_trigger_time = ConfigFactory
    .load(s"application.${environment}.conf").getConfig("high_watermark").getString("cache_db_invalidate_trigger")

  val kafka_cache_invalidate_trigger_time = ConfigFactory
    .load(s"application.${environment}.conf").getConfig("high_watermark").getString("cache_kafka_alert_invalidate_trigger")

  val data_lake_processing_trigger = ConfigFactory
    .load(s"application.${environment}.conf").getConfig("high_watermark").getString("data_lake_processing_trigger")

  val active_alerts_prev_state_topic = ConfigFactory
    .load(s"application.${environment}.conf")
    .getConfig("EventProcessors").getConfig("pipeline").getString("alerts_prev_notification_topic")

  val compact_curated_tpms_records_topic = ConfigFactory
    .load(s"application.${environment}.conf")
    .getConfig("EventProcessors").getConfig("pipeline").getString("compact_tpms_records_topic")

  val asset_prev_activity_topic = ConfigFactory
    .load(s"application.${environment}.conf")
    .getConfig("EventProcessors").getConfig("pipeline").getString("asset_prev_activity_topic")

  val asset_activity_topic = ConfigFactory
    .load(s"application.${environment}.conf")
    .getConfig("EventProcessors").getConfig("pipeline").getString("asset_activity_topic")

  val customer_device_routing_topic = ConfigFactory
    .load(s"application.${environment}.conf")
    .getConfig("EventProcessors").getConfig("pipeline").getString("device_customer_routing_topic")

  val cached_alerts_paths = ConfigFactory
    .load(s"application.${environment}.conf")
    .getConfig("EventProcessors")
    .getConfig("pipeline")
    .getString("active_cache_path")

  val sparkCfg = ConfigFactory.load(s"application.${environment}.conf").getConfig("spark")
  sparkCfg.getConfig("config").root().asScala.map(
    v => sparkCfgObj.set(String.valueOf(v._1), String.valueOf(v._2.unwrapped()))
  )

  var kafkaConfig = ConfigFactory
    .load(s"application.${environment}.conf")
    .getConfig("kafka_config").root.asScala.map(
    v => v._1 -> String.valueOf(v._2.unwrapped())
  ).toMap

  val redisConfig = ConfigFactory
    .load(s"application.${environment}.conf")
    .getConfig("redis_config").root.asScala.map(
    v => v._1 -> String.valueOf(v._2.unwrapped())
  ).toMap

  val spark = SparkSession
    .builder
    .appName("")
    .config(sparkCfgObj)
    .getOrCreate()

  import spark.implicits._

  //Logger.getLogger("org").setLevel(Level.ERROR)
  //Logger.getLogger("spark").setLevel(Level.ERROR)
  //Logger.getLogger("akka").setLevel(Level.ERROR)
  //Logger.getLogger("kafkashaded").setLevel(Level.ERROR)
  //Logger.getLogger("SubscriptionState").setLevel(Level.ERROR)

  val appLogger = LoggerFactory.getLogger("spark")

  val dimentionalCfg = ConfigFactory
    .load(s"application.${environment}.conf")
    .getConfig("dimensional_data")

  val postgresdbCfg = ConfigFactory
    .load(s"application.${environment}.conf")
    .getConfig("customerdim_postgresdb")

  def addImageUrlColumn() = {
    concat(
      lit("https://powerbistatic.azurewebsites.net/img/")
      , when(
        ($"v_wheel_config".isin(List("2,2,2", "2,2"): _*) && (lower($"company_asset_name") === "tractor"))
        , "TractorSuper"
      ).otherwise(initcap($"company_asset_name"))
      , lit("_")
      , regexp_replace($"v_wheel_config", ",", "_")
      , lit(".JPG")
    )
  }

  val postgresdb_prop = new Properties()
  val postgresdb_prop_stg = new Properties()
  val postgresdb_prop_sensdev = new Properties()
  val postgresdb_prop_staging = new Properties()
  val postgresdb_prop_sensprod = new Properties()
  val postgresdb_prop_fedx = new Properties()
  val postgresdb_prop_dske = new Properties()
  val postgresdb_prop_pnke = new Properties()
  val postgresdb_prop_ryes = new Properties()
  val postgresdb_prop_wrnr = new Properties()
  val postgresdb_prop_ppsi = new Properties()

  postgresdbCfg.getConfig("properties").entrySet().forEach(k => {
    postgresdb_prop.put(k.getKey, String.valueOf(k.getValue unwrapped))
    postgresdb_prop_stg.put(k.getKey, String.valueOf(k.getValue unwrapped))
    postgresdb_prop_sensdev.put(k.getKey, String.valueOf(k.getValue unwrapped))
    postgresdb_prop_staging.put(k.getKey, String.valueOf(k.getValue unwrapped))
    postgresdb_prop_sensprod.put(k.getKey, String.valueOf(k.getValue unwrapped))
    postgresdb_prop_fedx.put(k.getKey, String.valueOf(k.getValue unwrapped))
    postgresdb_prop_dske.put(k.getKey, String.valueOf(k.getValue unwrapped))
    postgresdb_prop_pnke.put(k.getKey, String.valueOf(k.getValue unwrapped))
    postgresdb_prop_ryes.put(k.getKey, String.valueOf(k.getValue unwrapped))
    postgresdb_prop_wrnr.put(k.getKey, String.valueOf(k.getValue unwrapped))
    postgresdb_prop_ppsi.put(k.getKey, String.valueOf(k.getValue unwrapped))
  })

  def setKafkaSecrets(is_prod: Boolean = false) = {
    if (is_prod) {
      kafkaConfig = kafkaConfig + ("kafka.sasl.jaas.config" -> s"kafkashaded.org.apache.kafka.common.security.plain.PlainLoginModule   required username='${dbutils.secrets.get("bdbkprodsensatacloudkv", "kafka-key")}'   password='${dbutils.secrets.get("bdbkprodsensatacloudkv", "kafka-secret")}';")
    } else {
      kafkaConfig = kafkaConfig + ("kafka.sasl.jaas.config" -> s"kafkashaded.org.apache.kafka.common.security.plain.PlainLoginModule   required username='${dbutils.secrets.get("bdbkdevsensatacloudkv", "kafka-key")}'   password='${dbutils.secrets.get("bdbkdevsensatacloudkv", "kafka-secret")}';")
    }
  }

  def setDBConnectString(is_prod: Boolean = false) = {
    if (is_prod) {
      postgresdb_prop.put("jdbcuri", s"jdbc:postgresql://" +
        s"${dbutils.secrets.get("bdbkprodsensatacloudkv", "db-config-fqdn-global-production")}:5432/" +
        s"${dbutils.secrets.get("bdbkprodsensatacloudkv", "db-config-database-global-production")}"
      );
      postgresdb_prop.put("uri", s"jdbc:postgresql://" +
        s"${dbutils.secrets.get("bdbkprodsensatacloudkv", "db-config-fqdn-global-production")}:5432/" +
        s"${dbutils.secrets.get("bdbkprodsensatacloudkv", "db-config-database-global-production")}"
      );
      postgresdb_prop.put("user"
        , s"${dbutils.secrets.get("bdbkprodsensatacloudkv", "db-config-username-global-production")}@" +
          s"${dbutils.secrets.get("bdbkprodsensatacloudkv", "db-config-fqdn-global-production").split("\\.")(0)}"
      );
      postgresdb_prop.put("password", dbutils.secrets.get("bdbkprodsensatacloudkv", "db-config-password-global-production"));
    } else {
      // dev device database
      postgresdb_prop.put("jdbcuri", s"jdbc:postgresql://" +
        s"${dbutils.secrets.get("bdbkdevsensatacloudkv", "db-config-fqdn-global-development")}:5432/" +
        s"${dbutils.secrets.get("bdbkdevsensatacloudkv", "db-config-database-global-development")}"
      );
      postgresdb_prop.put("uri", s"jdbc:postgresql://" +
        s"${dbutils.secrets.get("bdbkdevsensatacloudkv", "db-config-fqdn-global-development")}:5432/" +
        s"${dbutils.secrets.get("bdbkdevsensatacloudkv", "db-config-database-global-development")}"
      );
      postgresdb_prop.put("user"
        , s"${dbutils.secrets.get("bdbkdevsensatacloudkv", "db-config-username-global-development")}@" +
          s"${dbutils.secrets.get("bdbkdevsensatacloudkv", "db-config-fqdn-global-development").split("\\.")(0)}"
      );
      postgresdb_prop.put("password", dbutils.secrets.get("bdbkdevsensatacloudkv", "db-config-password-global-development"));

      // staging device database
      postgresdb_prop_stg.put("jdbcuri", s"jdbc:postgresql://" +
        s"${dbutils.secrets.get("bdbkstgsensatacloudkv", "db-config-fqdn-global-staging")}:5432/" +
        s"${dbutils.secrets.get("bdbkstgsensatacloudkv", "db-config-database-global-staging")}"
      );
      postgresdb_prop_stg.put("uri", s"jdbc:postgresql://" +
        s"${dbutils.secrets.get("bdbkstgsensatacloudkv", "db-config-fqdn-global-staging")}:5432/" +
        s"${dbutils.secrets.get("bdbkstgsensatacloudkv", "db-config-database-global-staging")}"
      );
      postgresdb_prop_stg.put("user"
        , s"${dbutils.secrets.get("bdbkstgsensatacloudkv", "db-config-username-global-staging")}@" +
          s"${dbutils.secrets.get("bdbkstgsensatacloudkv", "db-config-fqdn-global-staging").split("\\.")(0)}"
      );
      postgresdb_prop_stg.put("password", dbutils.secrets.get("bdbkstgsensatacloudkv", "db-config-password-global-staging"));

    }
  }

  def setCustomerConnectString(is_prod: Boolean = false) = {
    if (is_prod) {

      //This is for SENSPROD
      postgresdb_prop_sensprod.put("jdbcuri", s"jdbc:postgresql://" +
        s"${dbutils.secrets.get("dbksensprodsensatacldkv", "db-config-fqdn-sensata-prod")}:5432/" +
        s"${dbutils.secrets.get("dbksensprodsensatacldkv", "db-config-database-sensata-prod")}"
      );
      postgresdb_prop_sensprod.put("uri", s"jdbc:postgresql://" +
        s"${dbutils.secrets.get("dbksensprodsensatacldkv", "db-config-fqdn-sensata-prod")}:5432/" +
        s"${dbutils.secrets.get("dbksensprodsensatacldkv", "db-config-database-sensata-prod")}"
      );
      postgresdb_prop_sensprod.put("user"
        , s"${dbutils.secrets.get("dbksensprodsensatacldkv", "db-config-username-sensata-prod")}@" +
          s"${dbutils.secrets.get("dbksensprodsensatacldkv", "db-config-fqdn-sensata-prod").split("\\.")(0)}"
      );
      postgresdb_prop_sensprod.put("password", dbutils.secrets.get("dbksensprodsensatacldkv", "db-config-password-sensata-prod"));

      //This is for FEDEX
      postgresdb_prop_fedx.put("jdbcuri", s"jdbc:postgresql://" +
        s"${dbutils.secrets.get("dbkfedxsensatacloudkv", "db-config-fqdn-fedex")}:5432/" +
        s"${dbutils.secrets.get("dbkfedxsensatacloudkv", "db-config-database-fedex")}"
      );
      postgresdb_prop_fedx.put("uri", s"jdbc:postgresql://" +
        s"${dbutils.secrets.get("dbkfedxsensatacloudkv", "db-config-fqdn-fedex")}:5432/" +
        s"${dbutils.secrets.get("dbkfedxsensatacloudkv", "db-config-database-fedex")}"
      );
      postgresdb_prop_fedx.put("user"
        , s"${dbutils.secrets.get("dbkfedxsensatacloudkv", "db-config-username-fedex")}@" +
          s"${dbutils.secrets.get("dbkfedxsensatacloudkv", "db-config-fqdn-fedex").split("\\.")(0)}"
      );
      postgresdb_prop_fedx.put("password"
        , dbutils.secrets.get("dbkfedxsensatacloudkv", "db-config-password-fedex"));

      //This is for DASEKE

      postgresdb_prop_dske.put("jdbcuri", s"jdbc:postgresql://" +
        s"${dbutils.secrets.get("dbkdske2sensatacloudkv", "db-config-fqdn-daseke")}:5432/" +
        s"${dbutils.secrets.get("dbkdske2sensatacloudkv", "db-config-database-daseke")}"
      );
      postgresdb_prop_dske.put("uri", s"jdbc:postgresql://" +
        s"${dbutils.secrets.get("dbkdske2sensatacloudkv", "db-config-fqdn-daseke")}:5432/" +
        s"${dbutils.secrets.get("dbkdske2sensatacloudkv", "db-config-database-daseke")}"
      );
      postgresdb_prop_dske.put("user"
        , s"${dbutils.secrets.get("dbkdske2sensatacloudkv", "db-config-username-daseke")}@" +
          s"${dbutils.secrets.get("dbkdske2sensatacloudkv", "db-config-fqdn-daseke").split("\\.")(0)}"
      );
      postgresdb_prop_dske.put("password"
        , dbutils.secrets.get("dbkdske2sensatacloudkv", "db-config-password-daseke"));

      //This is for PENSKE

      postgresdb_prop_pnke.put("jdbcuri", s"jdbc:postgresql://" +
        s"${dbutils.secrets.get("dbkpnkesensatacloudkv", "db-config-fqdn-penske")}:5432/" +
        s"${dbutils.secrets.get("dbkpnkesensatacloudkv", "db-config-database-penske")}"
      );
      postgresdb_prop_pnke.put("uri", s"jdbc:postgresql://" +
        s"${dbutils.secrets.get("dbkpnkesensatacloudkv", "db-config-fqdn-penske")}:5432/" +
        s"${dbutils.secrets.get("dbkpnkesensatacloudkv", "db-config-database-penske")}"
      );
      postgresdb_prop_pnke.put("user"
        , s"${dbutils.secrets.get("dbkpnkesensatacloudkv", "db-config-username-penske")}@" +
          s"${dbutils.secrets.get("dbkpnkesensatacloudkv", "db-config-fqdn-penske").split("\\.")(0)}"
      );
      postgresdb_prop_pnke.put("password"
        , dbutils.secrets.get("dbkpnkesensatacloudkv", "db-config-password-penske"));

      //This is for REYES

      postgresdb_prop_ryes.put("jdbcuri", s"jdbc:postgresql://" +
        s"${dbutils.secrets.get("dbkryessensatacloudkv", "db-config-fqdn-reyes")}:5432/" +
        s"${dbutils.secrets.get("dbkryessensatacloudkv", "db-config-database-reyes")}"
      );
      postgresdb_prop_ryes.put("uri", s"jdbc:postgresql://" +
        s"${dbutils.secrets.get("dbkryessensatacloudkv", "db-config-fqdn-reyes")}:5432/" +
        s"${dbutils.secrets.get("dbkryessensatacloudkv", "db-config-database-reyes")}"
      );
      postgresdb_prop_ryes.put("user"
        , s"${dbutils.secrets.get("dbkryessensatacloudkv", "db-config-username-reyes")}@" +
          s"${dbutils.secrets.get("dbkryessensatacloudkv", "db-config-fqdn-reyes").split("\\.")(0)}"
      );
      postgresdb_prop_ryes.put("password"
        , dbutils.secrets.get("dbkryessensatacloudkv", "db-config-password-reyes"));

      //This is for WERNER

      postgresdb_prop_wrnr.put("jdbcuri", s"jdbc:postgresql://" +
        s"${dbutils.secrets.get("dbkwrnrsensatacloudkv", "db-config-fqdn-werner")}:5432/" +
        s"${dbutils.secrets.get("dbkwrnrsensatacloudkv", "db-config-database-werner")}"
      );
      postgresdb_prop_wrnr.put("uri", s"jdbc:postgresql://" +
        s"${dbutils.secrets.get("dbkwrnrsensatacloudkv", "db-config-fqdn-werner")}:5432/" +
        s"${dbutils.secrets.get("dbkwrnrsensatacloudkv", "db-config-database-werner")}"
      );
      postgresdb_prop_wrnr.put("user"
        , s"${dbutils.secrets.get("dbkwrnrsensatacloudkv", "db-config-username-werner")}@" +
          s"${dbutils.secrets.get("dbkwrnrsensatacloudkv", "db-config-fqdn-werner").split("\\.")(0)}"
      );
      postgresdb_prop_wrnr.put("password"
        , dbutils.secrets.get("dbkwrnrsensatacloudkv", "db-config-password-werner"));

      //This is for PEPSI

      postgresdb_prop_ppsi.put("jdbcuri", s"jdbc:postgresql://" +
        s"${dbutils.secrets.get("dbkppsisensatacloudkv", "db-config-fqdn-pepsi")}:5432/" +
        s"${dbutils.secrets.get("dbkppsisensatacloudkv", "db-config-database-pepsi")}"
      );
      postgresdb_prop_ppsi.put("uri", s"jdbc:postgresql://" +
        s"${dbutils.secrets.get("dbkppsisensatacloudkv", "db-config-fqdn-pepsi")}:5432/" +
        s"${dbutils.secrets.get("dbkppsisensatacloudkv", "db-config-database-pepsi")}"
      );
      postgresdb_prop_ppsi.put("user"
        , s"${dbutils.secrets.get("dbkppsisensatacloudkv", "db-config-username-pepsi")}@" +
          s"${dbutils.secrets.get("dbkppsisensatacloudkv", "db-config-fqdn-pepsi").split("\\.")(0)}"
      );
      postgresdb_prop_ppsi.put("password"
        , dbutils.secrets.get("dbkppsisensatacloudkv", "db-config-password-pepsi"));

  } else {

      //This is for Sensdev Database

      postgresdb_prop_sensdev.put("jdbcuri", s"jdbc:postgresql://" +
        s"${dbutils.secrets.get("dbksensdevsensatacloudkv", "db-config-fqdn-sensatadev")}:5432/" +
        s"${dbutils.secrets.get("dbksensdevsensatacloudkv", "db-config-database-sensatadev")}"
      );
      postgresdb_prop_sensdev.put("uri", s"jdbc:postgresql://" +
        s"${dbutils.secrets.get("dbksensdevsensatacloudkv", "db-config-fqdn-sensatadev")}:5432/" +
        s"${dbutils.secrets.get("dbksensdevsensatacloudkv", "db-config-database-sensatadev")}"
      );
      postgresdb_prop_sensdev.put("user"
        , s"${dbutils.secrets.get("dbksensdevsensatacloudkv", "db-config-username-sensatadev")}@" +
          s"${dbutils.secrets.get("dbksensdevsensatacloudkv", "db-config-fqdn-sensatadev").split("\\.")(0)}"
      );
      postgresdb_prop_sensdev.put("password"
        , dbutils.secrets.get("dbksensdevsensatacloudkv", "db-config-password-sensatadev-user"));

      //this is for staging database

      postgresdb_prop_staging.put("jdbcuri", s"jdbc:postgresql://" +
        s"${dbutils.secrets.get("dbkstagingsensatacloudkv", "db-config-fqdn-staging")}:5432/" +
        s"${dbutils.secrets.get("dbkstagingsensatacloudkv", "db-config-database-staging")}"
      );
      postgresdb_prop_staging.put("uri", s"jdbc:postgresql://" +
        s"${dbutils.secrets.get("dbkstagingsensatacloudkv", "db-config-fqdn-staging")}:5432/" +
        s"${dbutils.secrets.get("dbkstagingsensatacloudkv", "db-config-database-staging")}"
      );
      postgresdb_prop_staging.put("user"
        , s"${dbutils.secrets.get("dbkstagingsensatacloudkv", "db-config-username-staging")}@" +
          s"${dbutils.secrets.get("dbkstagingsensatacloudkv", "db-config-fqdn-staging").split("\\.")(0)}"
      );
      postgresdb_prop_staging.put("password"
        , dbutils.secrets.get("dbkstagingsensatacloudkv", "db-config-password-staging"));

    }
  }

  def AlertHistory(df: DataFrame): DataFrame = {

    df
      //.filter($"asset_id" =!= "0")
      .withColumn("asset_id",$"asset_id".cast("long"))
      .withColumn("alert_id",$"alert_id".cast("long"))
      .withColumn("battery_status",$"battery_status".cast("long"))
      .withColumn("on_alert_duration",$"on_alert_duration".cast("long"))
      .withColumn("on_alert_previous_active_duration",$"on_alert_previous_active_duration".cast("long"))
      .withColumn("off_alert_duration",$"off_alert_duration".cast("long"))
      .withColumn("off_alert_previous_active_duration",$"off_alert_previous_active_duration".cast("long"))
      .withColumn("on_alerts_first_reported_time",$"on_alerts_first_reported_time".cast("timestamp"))
      .withColumn("on_alerts_last_reported_time",$"on_alerts_last_reported_time".cast("timestamp"))
      .withColumn("off_alerts_first_reported_time",$"off_alerts_first_reported_time".cast("timestamp"))
      .withColumn("off_alerts_last_reported_time",$"off_alerts_last_reported_time".cast("timestamp"))
     //.dropDuplicates("location","asset_code","reported_time_dashboard_format","frequency")

  }

  def WheelHistory(df: DataFrame): DataFrame = {

    df
      .withColumn("asset_id",$"asset_id".cast("long"))
      .withColumn("reported_time",$"reported_time".cast("timestamp"))
      .withColumn("max_battery_status",$"max_battery_status".cast("long"))
      .withColumn("min_battery_status",$"min_battery_status".cast("long"))
      .withColumn("high_pressure_value", lit(0))
      .withColumn("high_temperature_value", lit(0))
    // .filter($"asset_id" =!= "0")

  }

  def VehicleHistory(df: DataFrame): DataFrame = {

   df
      .withColumn("asset_id",$"asset_id".cast("long"))
      .withColumn("last_active_reported_time",$"last_active_reported_time".cast("timestamp"))
      .withColumn("first_active_reported_time",$"first_active_reported_time".cast("timestamp"))
      .withColumn("last_known_latitude",$"last_known_latitude".cast("long"))
      .withColumn("last_known_longitude",$"last_known_longitude".cast("long"))
      .withColumn("last_known_altitude",$"last_known_altitude".cast("long"))
      .withColumn("last_known_speed",$"last_known_speed".cast("long"))
      .withColumn("last_known_heading",$"last_known_heading".cast("long"))
      .withColumn("first_known_latitude",$"first_known_latitude".cast("long"))
      .withColumn("first_known_longitude",$"first_known_longitude".cast("long"))
      .withColumn("first_known_altitude",$"first_known_altitude".cast("long"))
      .withColumn("first_known_speed",$"first_known_speed".cast("long"))
      .withColumn("first_known_heading",$"first_known_heading".cast("long"))
    // .filter($"asset_id".isNotNull)
  
  }

  def wheelalerteventfact(df: DataFrame): DataFrame = {

    df
      .withColumn("alert_status", $"alert_status".cast("long"))
      .withColumn("event_stop_time", $"event_stop_time".cast("timestamp"))
      .withColumn("trip_duration", $"trip_duration".cast("long"))
      .withColumn("trip_distance", $"trip_distance".cast("long"))
      .withColumn("category", $"category".cast("long"))
      .withColumn("battery_status", $"battery_status".cast("long"))
  }

  def vehicleeventfact(df: DataFrame): DataFrame = {

    df
      .withColumn("pipeline_timestamp", $"pipeline_timestamp".cast("timestamp"))
      .withColumn("latitude", $"latitude".cast("double"))
      .withColumn("longitude", $"longitude".cast("double"))
      .withColumn("altitude", $"altitude".cast("double"))
      .withColumn("gps_timestamp", $"gps_timestamp".cast("timestamp"))
      .withColumn("measured_speed", $"measured_speed".cast("long"))
      .withColumn("measured_heading", $"measured_heading".cast("long"))
      .withColumn("odometer", $"odometer".cast("long"))
      .withColumn("odometer_total", $"odometer_total".cast("long"))
      .withColumn("odometer_in_miles", $"odometer_in_miles".cast("double"))
      .withColumn("odometer_total_in_miles", $"odometer_total_in_miles".cast("double"))
      .withColumn("device_has_alerts", $"device_has_alerts".cast("long"))
      .withColumn("alerts_duration_hrs", $"alerts_duration_hrs".cast("double"))
      .withColumn("active_trip", $"active_trip".cast("long"))
      .withColumn("distance_travelled", $"distance_travelled".cast("double"))
      .withColumn("active_duration", $"active_duration".cast("double"))
      .withColumn("total_duration", $"total_duration".cast("double"))
      .withColumn("total_distance_travelled", $"total_distance_travelled".cast("double"))
      .withColumn("consumed_timestamp", $"consumed_timestamp".cast("timestamp"))
  }

  def wheeleventfact(df: DataFrame): DataFrame = {

    df
      .withColumn("battery_status", $"battery_status".cast("long"))
      .withColumn("consumed_timestamp", $"consumed_timestamp".cast("timestamp"))
      .withColumn("extra_low_pressure_value", $"extra_low_pressure_value".cast("double"))
      .withColumn("extra_low_temperature_value", $"extra_low_temperature_value".cast("double"))
      .withColumn("low_pressure_value", $"low_pressure_value".cast("double"))
      .withColumn("low_temperature_value", $"low_temperature_value".cast("double"))
      .withColumn("measured_pressure", $"measured_pressure".cast("double"))
      .withColumn("measured_pressure_psi", $"measured_pressure_psi".cast("double"))
      .withColumn("measured_temperature", $"measured_temperature".cast("double"))
      .withColumn("measured_temperature_c", $"measured_temperature_c".cast("double"))
      .withColumn("measured_temperature_f", $"measured_temperature_f".cast("double"))
      .withColumn("normal_pressure_value", $"normal_pressure_value".cast("double"))
      .withColumn("normal_temperature_value", $"normal_temperature_value".cast("double"))
      .withColumn("temp_comp", $"temp_comp".cast("double"))
      .withColumn("pipeline_timestamp", $"pipeline_timestamp".cast("timestamp"))
  }

  def leakeventfact(df: DataFrame): DataFrame = {

    df
      .withColumn("asset_id", $"asset_id".cast("long"))
      .withColumn("reported_time", $"reported_time".cast("timestamp"))
      .withColumn("time_to_failure_summed30", $"time_to_failure_summed30".cast("long"))
      .withColumn("alerttrigger", $"alerttrigger".cast("long"))
  }

  def purgeOffsetList(anOffsetList: ListBuffer[String], max_size: Int = 5): Unit = {
    // only retain last 5
    if (anOffsetList.size > max_size) {
      anOffsetList.remove(0)
    }
  }

  def v2MessageToStandSchema(df: Dataset[GenericEventData]): DataFrame = {
    df
      .withColumn("data_location"
        , regexp_extract($"resource", ".*\\/([0-9a-zA-z]{2,2})\\/.*", 1)
      )
  }

  def getKafkaOffsets(df: DataFrame): String = {
    df.select(
      $"partition" cast "string"
      , $"offset"
      , $"timestamp"
      , $"topic"
    ).groupBy("partition").agg(
      max("offset") as "offset"
      , max("timestamp") as "timestamp"
      , first("topic") as "topic"

    ).select(
      $"topic"
      , concat_ws(":", concat(lit("\""), $"partition", lit("\"")), $"offset") as "offset"
    ).groupBy($"topic").agg(
      concat_ws(",", collect_list("offset")) as "offsets"
    )
      .select(
        concat(lit("\""), $"topic", lit("\"")) as "topic"
        , $"offsets"
      )
      .collectAsList().asScala.map(
      r => {
        s"{${r.getString(0)}:{${r.getString(1)}}}"
      }
    ).mkString(",")
  }

  def createEmptyActivityRecord() = {
    spark.emptyDataFrame.select(
      lit(null) as "asset_code"
      , current_timestamp() as "reported_time"
      , lit(0) as "measured_speed"
      , lit(0) as "measured_heading"
      , lit(-1) as "odometer"
      , lit(-1) as "odometer_total"
      , lit(-1) as "odometer_miles"
      , lit(-1) as "odometer_total_miles"
      , lit(null) as "atis_state"
      , lit(null) as "atis_reported_time"
      , lit(current_timestamp()) as "prev_reported_time"
      , lit(-1) as "prev_odometer"
      , lit(-1) as "prev_odometer_total"
      , lit(-1) as "prev_odometer_miles"
      , lit(-1) as "prev_odometer_total_miles"
      , lit(null) as "prev_atis_state"
      , lit(null) as "prev_atis_reported_time"
      , lit(-1) as "active_trip"
      , lit(-1) as "distance_travelled"
      , lit(-1) as "active_duration"
      , lit(-1) as "total_duration"
      , lit(-1) as "total_distance_travelled"
      , lit("false") as "moving"
      , lit(null) as "ttl_active"
      , lit(null) as "kl15_pin_state"
      , current_timestamp() as "last_updated"
    )
      .withColumn("checkpoint_timestamp", floor(lit(System.currentTimeMillis() / (3600 * 1000))) * 3600)
  }

  def createEmptyActiveAlertRecord() = {
    spark.emptyDataFrame.select(
      lit(null) as "asset_id"
      , lit(null) as "asset_code"
      , lit(null) as "location"
      , lit("events/warnings/pressure") as "resource"
      , lit(-1) as "active"
      , lit(-1) as "category"
      , current_timestamp() as "reported_time"
      , lit(0) as "device_duration"
      , lit(0) as "calc_duration"
      , lit(0) as "est_duration"
      , lit(0) as "odometer_miles"
      , lit(0) as "odometer_total_miles"
      , lit(0) as "distance_travel"
      , lit(0) as "distance_travel_with_alert"
      , lit(0) as "old_active"
      , lit(0) as "old_category"
      , current_timestamp() as "old_reported_time"
      , lit(0) as "old_odometer_miles"
      , lit(0) as "old_odometer_total_miles"
      , lit(0) as "old_distance_travel"
      , lit(0) as "old_distance_travel_with_alert"
      , lit(0) as "old_calc_duration"
      , lit("false") as "state_changed"
      , lit(null) cast "double" as "pressure"
      , lit(null) cast "double" as "pressure_psi"
      , lit(null) cast "double" as "temperature"
      , lit(null) cast "double" as "temperature_f"
      , lit(null) cast "double" as "temp_comp_pressure"
      , lit(null) cast "timestamp" as "event_start_time"
      , current_timestamp() as "last_updated"
    )
      .withColumn("checkpoint_timestamp", floor(lit(System.currentTimeMillis() / (3600 * 1000))) * 3600)
  }

  def initaliseFedExThreshold() = {
    var cached_alerts = spark.emptyDataFrame
    try {

      if (!cached_alerts.columns.contains("asset_code")) {
        cached_alerts = cached_alerts.withColumn("asset_code", $"asset_id")
      } else {
        cached_alerts = cached_alerts.withColumn("asset_code"
          , when($"asset_code" isNull, $"asset_id").otherwise($"asset_code")
        )
      }
      if (!cached_alerts.columns.contains("measured_speed")) {
        cached_alerts = cached_alerts
          .withColumn("measured_speed", lit(0))
          .withColumn("measured_heading", lit(0))
      }
      if (!cached_alerts.columns.contains("atis_state")) {
        cached_alerts = cached_alerts
          .withColumn("atis_state", lit(null))
          .withColumn("ttl_active", lit(null))
          .withColumn("kl15_pin_state", lit(null))
          .withColumn("atis_reported_time", lit(null))
      }
    } catch {
      case _ => cached_alerts = createEmptyActivityRecord()
    }
    dedupActivityToLatest(cached_alerts)
      .as[AssetActivityNotification]
  }

  def initaliseLiveAlerts() = {

    val checkpoint_timestamp = (System.currentTimeMillis() / (3600 * 1000)).floor.toInt * 3600
    var cached_alerts = spark.emptyDataFrame
    try {
      cached_alerts = spark.read
        .format("parquet")
        .load(s"$cached_alerts_paths/active_alerts/checkpoint_timestamp=$checkpoint_timestamp")
        .withColumn("checkpoint_timestamp", lit(checkpoint_timestamp))
        .union(
          spark.read
            .format("parquet")
            .load(s"$cached_alerts_paths/active_alerts/checkpoint_timestamp=${checkpoint_timestamp - 3600}")
            .withColumn("checkpoint_timestamp", lit(checkpoint_timestamp - 3600))
        )

      if (!cached_alerts.columns.contains("asset_code")) {
        cached_alerts = cached_alerts.withColumn("asset_code", $"asset_id")
      } else {
        cached_alerts = cached_alerts.withColumn("asset_code"
          , when($"asset_code" isNull, $"asset_id").otherwise($"asset_code")
        )
      }
      if (!cached_alerts.columns.contains("old_calc_duration")) {
        cached_alerts = cached_alerts.withColumn("old_calc_duration", lit(0))
      }
      if (!cached_alerts.columns.contains("event_start_time")) {
        cached_alerts = cached_alerts.withColumn("event_start_time", lit(null))
      }
      if (!cached_alerts.columns.contains("pressure")) {
        cached_alerts = cached_alerts.withColumn("pressure", lit(null))
      }
      if (!cached_alerts.columns.contains("pressure_psi")) {
        cached_alerts = cached_alerts.withColumn("pressure_psi", lit(null))
      }
      if (!cached_alerts.columns.contains("temperature")) {
        cached_alerts = cached_alerts.withColumn("temperature", lit(null))
      }
      if (!cached_alerts.columns.contains("temperature_f")) {
        cached_alerts = cached_alerts.withColumn("temperature_f", lit(null))
      }
      if (!cached_alerts.columns.contains("temp_comp_pressure")) {
        cached_alerts = cached_alerts.withColumn("temp_comp_pressure", lit(null))
      }

    } catch {
      case _ => cached_alerts = createEmptyActiveAlertRecord()
    }
    dedupToLatest(cached_alerts.where(($"active" === 1) || ($"active" === 0)))
      .as[ActiveAlertNotification]
  }

  def loadDataFrameAndOffsetsFromKafka(kafkaTopic: String, data_schema: StructType, startingOffset: String = "earliest"): (DataFrame, String) = {
    val resDfs = try {
      val tmpdf = spark.read
        .format("kafka")
        .options(kafkaConfig)
        .option("startingOffsets", startingOffset)
        .option("subscribe", kafkaTopic)
        .load()

      (
        selectNCastDataFrameAsSchema(tmpdf
          .select(
            from_json($"value" cast "string"
              , data_schema
            ) as "events"
          ).select($"events.*")
          , data_schema
        )

        , getKafkaOffsets(tmpdf)
      )

    } catch {
      case _ => (createEmptyActiveAlertRecord(), "earliest")
    }

    (
      resDfs._1
      , resDfs._2
    )
  }

  def loadWheelTPMSData(kafkaOffset: String = "earliest"): (DataFrame, String) = {

    try {
      val tmpDf = spark.read
        .format("kafka")
        .option("startingOffsets", kafkaOffset)
        .options(kafkaConfig)
        .option("subscribe", compact_curated_tpms_records_topic)
        .load()

      (
        tmpDf
          .select(
            get_json_object($"value" cast "string", "$.asset_code") as "asset_code"
            , get_json_object($"value" cast "string", "$.device_id") as "device_id"
            , get_json_object($"value" cast "string", "$.location") as "location"
            , get_json_object($"value" cast "string", "$.measured_temperature_c") cast ("double") as "measured_temperature_c"
            , get_json_object($"value" cast "string", "$.measured_temperature_f") cast ("double") as "measured_temperature_f"
            , get_json_object($"value" cast "string", "$.measured_pressure_psi") cast ("double") as "measured_pressure_psi"
            , get_json_object($"value" cast "string", "$.battery_status") cast ("double") as "battery_status"
            , get_json_object($"value" cast "string", "$.reported_time") cast ("timestamp") as "reported_time"
            , get_json_object($"value" cast "string", "$.last_updated") cast ("timestamp") as "last_updated"
          )
          .withColumn("resource", lit("wheel-tpms-data"))
        , getKafkaOffsets(tmpDf)
      )

    } catch {
      case _ => (
        spark.emptyDataFrame.select(
          lit(null) as "asset_code"
          , lit(null) as "device_id"
          , lit(null) as "location"
          , lit(null) as "measured_temperature_c"
          , lit(null) as "measured_temperature_f"
          , lit(null) as "measured_pressure_psi"
          , lit(null) as "battery_status"
          , lit(null) as "reported_time"
          , current_timestamp() as "last_updated"
          , lit("wheel-tpms-data") as "resource"
        )
        , "earliest"
      )
    }
  }

  def dedupToLatest(df: DataFrame) = {
    df
      .withColumn(
        "rec_rank"
        , rank over Window.partitionBy("asset_code", "location", "resource").orderBy(asc("reported_time"))
      )
      .withColumn(
        "max_rank"
        , max("rec_rank") over Window.partitionBy("asset_code", "location", "resource")
      )
      .where($"max_rank" === $"rec_rank") // select the last record
      .drop("max_rank", "rec_rank")
      .dropDuplicates("asset_code", "location", "resource")
  }

  def dedupActivityToLatest(df: DataFrame) = {
    df.withColumn(
      "rec_rank"
      , rank over Window.partitionBy("asset_code").orderBy(asc("reported_time"), asc("last_updated"))
    )
      .withColumn(
        "max_rank"
        , max("rec_rank") over Window.partitionBy("asset_code")
      )
      .where($"max_rank" === $"rec_rank") // select the last record
      .drop("max_rank", "rec_rank")
      .dropDuplicates("asset_code")
  }

  def dedupByColumn(df: DataFrame, akey: String, rank_wnd: WindowSpec) = {
    df.withColumn(
      "rec_rank"
      , rank over rank_wnd
    )
      .withColumn(
        "max_rank"
        , max("rec_rank") over Window.partitionBy("asset_code")
      )
      .where($"max_rank" === $"rec_rank") // select the last record
      .drop("max_rank", "rec_rank")
      .dropDuplicates(akey)
  }

  def updateCustomerDimCache(lastOffset: String = "earliest"): (DataFrame, String) = {

    val notify_schema = ScalaReflection.schemaFor[CustomerRoutingRecord].dataType.asInstanceOf[StructType]
    val assetRouteswithOffset = PipelineUtil.loadDataFrameAndOffsetsFromKafka(
      customer_device_routing_topic
      , notify_schema
      , "earliest" //lastOffset
    )
    try {

      (
        assetRouteswithOffset._1.dropDuplicates("device_id"), assetRouteswithOffset._2
      )

    } catch {
      case _ => (spark.emptyDataset[CustomerRoutingRecord].toDF(), "earliest")
    }
  }

  def getAssetActivityStateFromDatabaseCache() = {

    setDBConnectString(sys.env("ENVIRONMENT") == "prod")

    // cache information regarding fleet and customers from DB
    val customer_data =
      spark
        .read
        .option("numPartitions", 1)
        .jdbc(
          postgresdb_prop.getProperty("jdbcuri")
          ,
          s"""(SELECT DISTINCT spark_key
             |, activity_state as asset_state
             | FROM ${getEnvVariable("ASSET_ACTIVITY_CACHE_TABLE", "data.asset_last_activity")}
             | WHERE last_updated between now() - interval '${getEnvVariable("CACHE_EXPRY_DAYS", "10")} days' and now()
             |) as query
             |""".stripMargin
          , postgresdb_prop
        )
        .select(
          from_json($"asset_state" cast "string"
            , ScalaReflection.schemaFor[AssetActivityNotification].dataType.asInstanceOf[StructType]
          ) as "events"
        ).select($"events.*")

    // materialise the DataFrame
    customer_data.count()

    customer_data
  }

  def getAssetAlertStateFromDatabaseCache() = {

    setDBConnectString(sys.env("ENVIRONMENT") == "prod")

    // cache information regarding fleet and customers from DB
    var customer_data =
      spark
        .read
        .option("numPartitions", 1)
        .jdbc(
          postgresdb_prop.getProperty("jdbcuri")
          ,
          s"""
             |(SELECT DISTINCT spark_key
             |, alert_state as asset_state
             |FROM ${getEnvVariable("ASSET_ALERT_CACHE_TABLE", "data.asset_alert_activity")}
             | WHERE last_updated between now() - interval '${getEnvVariable("CACHE_EXPRY_DAYS", "10")} days' and now()
             |) as query
             |""".stripMargin
          , postgresdb_prop
        )
        .select(
          from_json($"asset_state" cast "string"
            , ScalaReflection.schemaFor[ActiveAlertNotification].dataType.asInstanceOf[StructType]
          ) as "events"
        ).select($"events.*")

    // materialise the DataFrame
    customer_data.count()

    customer_data
  }

  def updateCustomerDimCacheFromDatabase() = {

    setDBConnectString(sys.env("ENVIRONMENT") == "prod")

    // cache information regarding fleet and customers from DB
    var customer_data1 =
      spark
        .read
        .option("numPartitions", 1)
        .jdbc(
          postgresdb_prop.getProperty("jdbcuri")
          ,
          s"""
             |(SELECT d.deviceexternalid as device_id
             |, d.deviceexternalid as reported_device_id
             |, c.name as company_name
             |, split_part(assetid,'-',1)::text as fleet_name
             |, d.table as company_asset_name
             |, '0,0,0' as v_wheel_config
             |, '0' as v_no_axles
             |, 'N/A' as v_image_url
             |, split_part(assetid,'-',2)::integer as v_asset_id
             |, assetid as v_asset_code
             |, 'all' as v_topic_id
             | FROM public.devices d
             | JOIN public.customers c on c.customerid = d.customerid
             | WHERE assetid IS NOT NULL
             | ) as query
             |""".stripMargin
          , postgresdb_prop
        )

    // for dev env, add staging global
    if (Seq("dev", "stg").contains(environment)) {

      val stag_devs = spark
        .read
        .option("numPartitions", 1)
        .jdbc(
          postgresdb_prop_stg.getProperty("jdbcuri")
          ,
          s"""
             |(SELECT d.deviceexternalid as device_id
             |, d.deviceexternalid as reported_device_id
             |, c.name as company_name
             , split_part(assetid,'-',1)::text as fleet_name
             |, d.table as company_asset_name
             |, '0,0,0' as v_wheel_config
             |, '0' as v_no_axles
             |, 'N/A' as v_image_url
             |, split_part(assetid,'-',2)::integer as v_asset_id
             |, assetid as v_asset_code
             |, 'all' as v_topic_id
             | FROM public.devices d
             | JOIN public.customers c on c.customerid = d.customerid
             |  WHERE assetid IS NOT NULL
             | ) as query
             |""".stripMargin
          , postgresdb_prop_stg
        )

      appLogger.info(s"Environment is : ${environment}")
      appLogger.info(s"Stagging connection is: ${postgresdb_prop_stg.getProperty("jdbcuri")}")
      appLogger.info(s"Stagging devices are ${stag_devs.count()}")
      appLogger.info(s"Dev devices are ${customer_data1.count()}")
      customer_data1 = customer_data1.union(stag_devs).dropDuplicates()

      appLogger.info(s"Device id to topic mapping : ${
        customer_data1.select(concat_ws(" -> ", $"device_id", $"v_topic_id") as "device_2_topic")
          .collect().map(r => r.getString(0)).mkString("\n")
      }")

    }


    val customer_data = customer_data1
      .groupBy($"device_id").agg(
      first($"company_name", ignoreNulls = true) as "company_name"
      , first($"fleet_name", ignoreNulls = true) as "fleet_name"
      , first($"company_asset_name", ignoreNulls = true) as "company_asset_name"
      , first($"v_wheel_config", ignoreNulls = true) as "v_wheel_config"
      , first($"v_no_axles", ignoreNulls = true) as "v_no_axles"
      , first($"v_image_url", ignoreNulls = true) as "v_image_url"
      , first($"v_topic_id", ignoreNulls = true) as "v_topic_id"
      , first($"v_asset_id", ignoreNulls = true) as "v_asset_id"
      , first($"v_asset_code", ignoreNulls = true) as "v_asset_code"
      , first($"reported_device_id", ignoreNulls = true) as "reported_device_id"
    )
      .withColumn("v_image_url"
        , lit("") //addImageUrlColumn()
      )
      .persist(StorageLevel.MEMORY_AND_DISK)

    // materialise the DataFrame
    customer_data.count()

    customer_data
  }

  def FetchCustomerDeviceFromDatabase() = {

    setDBConnectString(sys.env("ENVIRONMENT") == "prod")

    var prods_new = spark
      .read
      .option("numPartitions", 1)
      .jdbc(
        postgresdb_prop.getProperty("jdbcuri")
        ,
        s"""
           |(SELECT d.deviceexternalid as device_id
           |, d.deviceexternalid as reported_device_id
           |, c.name as company_name
           |, split_part(assetid,'-',1)::text as fleet_name
           |, d.table as company_asset_name
           |, '0,0,0' as v_wheel_config
           |, '0' as v_no_axles
           |, 'N/A' as v_image_url
           |, split_part(assetid,'-',2)::integer as v_asset_id
           |, assetid as v_asset_code
           |, 'all' as v_topic_id
           | FROM public.devices d
           | JOIN public.customers c on c.customerid = d.customerid
           | WHERE assetid IS NOT NULL
           | ) as query
           |""".stripMargin
        , postgresdb_prop
      )

    // for dev env, add staging global
    if (Seq("dev", "stg").contains(environment)) {

      val stag_devs_new = spark
        .read
        .option("numPartitions", 1)
        .jdbc(
          postgresdb_prop_stg.getProperty("jdbcuri")
          ,
          s"""
             |(SELECT d.deviceexternalid as device_id
             |, d.deviceexternalid as reported_device_id
             |, c.name as company_name
             , split_part(assetid,'-',1)::text as fleet_name
             |, d.table as company_asset_name
             |, '0,0,0' as v_wheel_config
             |, '0' as v_no_axles
             |, 'N/A' as v_image_url
             |, split_part(assetid,'-',2)::integer as v_asset_id
             |, assetid as v_asset_code
             |, 'all' as v_topic_id
             | FROM public.devices d
             | JOIN public.customers c on c.customerid = d.customerid
             |  WHERE assetid IS NOT NULL
             | ) as query
             |""".stripMargin
          , postgresdb_prop_stg
        )

      prods_new = prods_new.union(stag_devs_new).dropDuplicates()
      prods_new.select(concat_ws(" -> ", $"device_id", $"v_topic_id") as "device_2_topic")
        .collect().map(r => r.getString(0)).mkString("\n")


    }

    val prods_new_data = prods_new
      .groupBy($"device_id").agg(
      first($"company_name", ignoreNulls = true) as "company_name"
      , first($"fleet_name", ignoreNulls = true) as "fleet_name"
      , first($"company_asset_name", ignoreNulls = true) as "company_asset_name"
      , first($"v_wheel_config", ignoreNulls = true) as "v_wheel_config"
      , first($"v_no_axles", ignoreNulls = true) as "v_no_axles"
      , first($"v_image_url", ignoreNulls = true) as "v_image_url"
      , first($"v_topic_id", ignoreNulls = true) as "v_topic_id"
      , first($"v_asset_id", ignoreNulls = true) as "v_asset_id"
      , first($"v_asset_code", ignoreNulls = true) as "v_asset_code"
      , first($"reported_device_id", ignoreNulls = true) as "reported_device_id"
    )
      .withColumn("v_image_url"
        , lit("") //addImageUrlColumn()
      )
      .persist(StorageLevel.MEMORY_AND_DISK)

    prods_new_data.count()
    prods_new_data

  }

  def readDataFrameFromKafkaWithConsumedTimestamp(kafka_topic: String, kafkaOptions: Map[String, String]): DataFrame = {
    spark.readStream
      .format("kafka")
      .options(kafkaOptions)
      .option("subscribe", kafka_topic)
      .load()
      .withColumn("consumed_timestamp"
        , getPartitonTimeStamp(received_timestamp_format)

      )
  }

  def readDataFrameFromKafkaAndExtractTimestamp(kafka_topic: String, kafkaOptions: Map[String, String]): DataFrame = {
    readDataFrameFromKafka(kafka_topic, kafkaOptions)
      .withColumn("timestamp",
        ((get_json_object($"value" cast "string", "$.timestamp") cast "long") / 1000) cast "timestamp"
      )
  }

  def readDataFrameFromKafka(kafka_topic: String, kafkaOptions: Map[String, String]): DataFrame = {
    spark.readStream
      .format("kafka")
      .options(kafkaOptions)
      .option("subscribe", kafka_topic)
      .load()
      .withColumn("consumed_timestamp"
        , getPartitonTimeStamp(received_timestamp_format)

      )
  }

  def readDataFrameFromBlobStore(file_path: String, data_schema: StructType): DataFrame = {
    spark
      .read
      .format("parquet")
      .schema(data_schema)
      .load(file_path)
  }

  def readDataFrameToRedisBucket(redisOptions: Map[String, String], redis_bucket: String, key_column: String): DataFrame = {
    spark
      .read
      .format("org.apache.spark.sql.redis")
      .options(redisOptions)
      .option("key.column", key_column)
      .option("table", redis_bucket)
      .load()
  }

  def writeDataFrameToRedisBucket(df: DataFrame, write_mode: String = "append", redisOptions: Map[String, String], redis_bucket: String, key_column: String): Unit = {
    df
      .write
      .format("org.apache.spark.sql.redis")
      .mode(write_mode)
      .options(redisOptions)
      .option("key.column", key_column)
      .option("table", redis_bucket)
      .save()
  }

  def writeDataFrameToKafkaTopic(df: DataFrame, write_mode: String, kafkaOptions: Map[String, String], kafka_topic: String): Unit = {
    df
      .write
      .format("kafka")
      .mode(write_mode)
      .options(kafkaOptions)
      .option("topic", kafka_topic)
      .save()
  }

  def writeDataFrameToKafkaTopic1(df: DataFrame, write_mode: String, kafkaOptions: Map[String, String], kafka_topic: String): Unit = {
    df
      .write
      .format("kafka")
      .mode(write_mode)
      .options(kafkaOptions)
      .option("topic", kafka_topic)
      .save()
  }

  def writeDataFrameToEmailNotificationKafkaTopic(df: DataFrame, write_mode: String, kafkaOptions: Map[String, String], kafka_topic: String): Unit = {
    writeDataFrameToKafkaTopic(df, write_mode, kafkaOptions, kafka_topic)
  }

  def writeDataFrameToBlobStorageUnPartitioned(df: DataFrame, write_mode: String, target_path: String): Unit = {
    df
      .write
      .format("parquet")
      .mode(write_mode)
      .option("mergeSchema", "true")
      .save(target_path)
  }

  def writeDataFrameToBlobStorage(df: DataFrame, write_mode: String, target_path: String): Unit = {
    df
      .write
      .partitionBy("consumed_timestamp")
      .format("parquet")
      .mode(write_mode)
      .option("mergeSchema", "true")
      .save(target_path)
  }

  def writeDataFrameToKafka(df: DataFrame, write_mode: String, kafkaOptions: Map[String, String]): Unit = {
    df
      .write
      .format("kafka")
      .mode(write_mode)
      .options(kafkaOptions)
      .save()
  }

  def getPartitonTimeStamp(date_format: String) = {

    to_timestamp(
      from_unixtime(unix_timestamp(), date_format)
    ).cast("long")
  }


  def filterOutInvalidMessage(df: DataFrame, version: String): DataFrame = {
    df.where($"body" cast "string" rlike (".*\"service\":\"[a-zA-z/]+\".*"))
      .where($"body" cast "string" rlike (".*\"resource\":\"[a-zA-z/]+\".*"))
      .where($"body" cast "string" rlike (".*\"data\":.*"))
      .where($"body" cast "string" rlike (".*\"version\":\"" + version + "\".*"))
  }

  def buildJsonMessageV2(df: DataFrame, data_schema: StructType, has_locaton: Boolean): DataFrame = {

    //val v2_data_schema = data_schema.add("update-time",LongType,true)

  /*  println("**************************************this is for V2 build message******************************")
    df.show(false)
   // df.printSchema()*/

    if (!has_locaton) {
      df.withColumnRenamed("data", "raw_data")
        .withColumn("data", from_json($"raw_data", data_schema.add("update-time", LongType, true)))
        .withColumn("time", $"data.update-time")
        .select(concat_ws("-", $"deviceId", $"service", $"time") as "key"
          , to_json(
            struct($"service"
              , $"resource"
              , $"deviceId"
              , $"customer"
              , $"time" / 1000 cast "long" as "time"
              , $"version"
              , $"timestamp"
              , $"consumed_timestamp"
              , $"data"
              , $"raw_data")
          ) as "value"
        )
    } else {
       df.withColumnRenamed("data", "raw_data")
        .withColumn("data", from_json($"raw_data",
          data_schema))
        //   .add("update-time",LongType,true)))
        //  .add("value",StringType,true)
        // .add("updated",StringType,true)
        //  .add("changed",StringType,true)))

     /* println("**************************************this is for v2df message******************************")
      v2df.show(false)*/

       .withColumn("time", $"data.update-time")
        //  .withColumn("location", regexp_extract($"resource",".*\\/([0-9a-zA-z]{2,2})\\/.*",1))
        .withColumn("data",
          struct(
            $"data.*", // <-- the wildcard here
            $"location" as "location")
        )
        //    .withColumn("resource", regexp_replace($"resource","\\/.*\\/","/"))
        .select(concat_ws("-", $"deviceId", $"service", $"time") as "key"
          , to_json(
            struct($"service"
              , $"resource"
              , $"deviceId"
              , $"customer"
              , $"time" / 1000 cast "long" as "time"
              , $"version"
              , $"timestamp"
              , $"consumed_timestamp"
              //  , $"location"
              , $"category"
              , $"data"
              , $"raw_data")
          ) as "value"
        )

    }
  }


  def buildJsonMessage(df: DataFrame, data_schema: StructType): DataFrame = {

    /*println("**************************************this is for V1 build message******************************")
    df_v1.show(false)
    df_v1.printSchema()*/

     df.withColumnRenamed("data", "raw_data")
        .withColumn("data", from_json($"raw_data",
          data_schema))

     /* println("**************************************this is for newdf V1******************************")
      newdf.select($"data.*").show(false)*/

      .select(concat_ws("-", $"deviceId", $"service", $"time") as "key"
          , to_json(
            struct($"service"
              , $"resource"
              , $"deviceId"
              , $"customer"
              , $"time" / 1000 cast "long" as "time"
              , $"version"
              , $"timestamp"
              , $"consumed_timestamp"
              , $"data"
              , $"raw_data")
          ) as "value"

        )
     }


  /**
   * Extrat the TPMS message from any analytics messages received
   * @param df
   * @return Dataset[GenericEventData]
   */
  def extractAnalyticMessageTPMS(df: DataFrame): Dataset[GenericEventData] = {
    val analytics_event_schema = ScalaReflection.schemaFor[AnalyticWarningEventData].dataType.asInstanceOf[StructType]
    df.
      where($"resource" === MessageTypes.WarningEventGeneric)
      .withColumn("analytic_data", from_json($"data", analytics_event_schema))
      .select($"src_deviceId"
        , $"src_customer"
        ,  explode($"analytic_data.additional_data") as "tpms"
        , $"atimestamp"
        , $"ctimestamp"
        , $"deviceId"
        , $"customer"
        , $"category"
        , $"timestamp"
        , $"consumed_timestamp"
      )
      .select($"src_deviceId"
        , $"src_customer"
        , $"tpms.*"
        , $"atimestamp"
        , $"ctimestamp"
        , $"deviceId"
        , $"customer"
        , $"category"
        , $"timestamp"
        , $"consumed_timestamp"
      )
      .select(df.columns.toList.map(col(_)):_*) // select in same order as outer dataframe
      .as[GenericEventData]
  }

  /**
   * Extrat the alert message from any analytics messages received
   * @param df
   * @return Dataset[GenericEventData]
   */
  def extractAnalyticMessageAlerts(df: DataFrame): Dataset[GenericEventData] = {
    val analytics_event_schema = ScalaReflection.schemaFor[AnalyticWarningEventData].dataType.asInstanceOf[StructType]
    df
      .toDF()
      .where($"resource" === MessageTypes.WarningEventGeneric)
      .withColumn("analytic_data", from_json($"data", analytics_event_schema))
      .select($"src_deviceId"
        , $"src_customer"
        , $"analytic_data.trigger.*"
        , $"atimestamp"
        , $"ctimestamp"
        , $"deviceId"
        , $"customer"
        , $"category"
        , $"timestamp"
        , $"consumed_timestamp"
      )
      .select(df.columns.toList.map(col(_)):_*) // select in same order as outer dataframe
      .as[GenericEventData]
  }

  def constructGenericIOTEventMessage(batchDF: DataFrame): Dataset[GenericEventData] = {
    val generic_event_schema = ScalaReflection.schemaFor[GenericEvent].dataType.asInstanceOf[StructType]

    val decoded_data = batchDF
      .select(from_json($"value" cast "string", generic_event_schema) as "events", $"consumed_timestamp" as "ctimestamp")
      .select($"events.deviceId" as "src_deviceId"
        , $"events.customer" as "src_customer"
        , $"events.tstamp" cast "long" as "atimestamp"
        , $"events.evt" as "metrics"
        , $"ctimestamp")

    decoded_data
      .select($"src_deviceId"
        , $"src_customer"
        , $"metrics.*"
        , $"atimestamp"
        , $"ctimestamp")
      .withColumn("deviceId", $"src_deviceId")
      .withColumn("customer", $"src_customer")
      .withColumn("timestamp", $"atimestamp")
      .withColumn("consumed_timestamp", $"ctimestamp")
      .where($"timestamp".isNotNull && (($"timestamp" cast "long") > 0))
      .orderBy(asc("time"),asc("deviceId"))
      .as[GenericEventData]
  }

}

/*object PipelineHelper {
  private val service = PipelineHelper()

  def apply() = service
}*/
