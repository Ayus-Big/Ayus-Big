package com.sensata.data_office.pipeline.queries

import com.sensata.data_office.data._
import com.sensata.data_office.pipeline.queries.CustomerDataPublisher.{asKafkaConnectJsonMessage, setNullableStateForAllColumns}
import com.sensata.data_office.utilities.Analytics.selectNCastDataFrameAsSchema
import com.sensata.data_office.utilities.PipelineUtil
import com.sensata.data_office.utilities.PipelineUtil.dedupToLatest
import com.typesafe.config.ConfigFactory
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.catalyst.ScalaReflection
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{abs, _}
import org.apache.spark.sql.streaming.Trigger
import org.apache.spark.sql.types.StructType
import org.apache.spark.storage.StorageLevel


object WarningNotificationProcessor {


  val pipelineConfig = ConfigFactory
    .load(s"application.${PipelineUtil.getEnvVariable("ENVIRONMENT")}.conf")
    .getConfig("EventProcessors").getConfig("pipeline")

  val dimentionalCfg = ConfigFactory
    .load(s"application.${PipelineUtil.getEnvVariable("ENVIRONMENT")}.conf")
    .getConfig("dimensional_data")

  val VERSION = pipelineConfig.getString("version")

  val watermark_column = ConfigFactory
    .load(s"application.${PipelineUtil.getEnvVariable("ENVIRONMENT")}.conf").getConfig("high_watermark").getString("watermark_column")
  val watermark_delay_threashold = ConfigFactory
    .load(s"application.${PipelineUtil.getEnvVariable("ENVIRONMENT")}.conf").getConfig("high_watermark").getString("watermark_delay_threashold")
  val late_record_threshold_sec = ConfigFactory
    .load(s"application.${PipelineUtil.getEnvVariable("ENVIRONMENT")}.conf").getConfig("high_watermark").getString("late_record_threshold_sec")

  import PipelineUtil.spark.implicits._

  def processMessagesByBatch(batchMessage: DataFrame, batchId: Long): Unit = {

    val prevActiveAlerts = PipelineUtil.getAssetAlertStateFromDatabaseCache()

    val wheel2distance = dedupToLatest(batchMessage
        .select(
        from_json($"value" cast "string"
          , ScalaReflection.schemaFor[ActiveAlertNotification].dataType.asInstanceOf[StructType]
        ) as "events"
      ).select($"events.*")
    )
      .as[ActiveAlertNotification]
      .persist(StorageLevel.MEMORY_AND_DISK)

    PipelineUtil.appLogger.info(s"Alert Messages in Batch $batchId are: ${wheel2distance.count()}")

    if (pipelineConfig.getBoolean("in_debug")) {
      wheel2distance.write
        .format("delta")
        .mode("append")
        .option("mergeSchema", "true")
        .save(pipelineConfig.getString("dest_data_path") + "warning_notfiy_raw")
    }

    val notify_schema = ScalaReflection.schemaFor[ActiveAlertNotification].dataType.asInstanceOf[StructType]

    val assets_with_alert = prevActiveAlerts.join(
          wheel2distance.select(
            $"asset_id"
            , $"asset_code"
            , $"location"
            , $"resource"
            , $"odometer_miles" cast "double" as "new_odometer_miles"
            , $"active" as "new_active"
            , $"odometer_total_miles" cast "double" as "new_odometer_total_miles"
            , $"reported_time" cast "timestamp" as "new_reported_time"
            , $"device_duration" cast "long" as "new_device_duration"
            , $"category" as "new_category"
            , $"distance_travel"  cast "double" as "new_distance_travel"
            , $"distance_travel_with_alert" cast "double" as "new_distance_travel_with_alert"
            , $"pressure" cast "long" as "new_pressure"
            , $"pressure_psi" cast "double" as "new_pressure_psi"
            , $"temperature" cast "double" as "new_temperature"
            , $"temperature_f" cast "double" as "new_temperature_f"
            , $"temp_comp_pressure" as "new_temp_comp_pressure"
            , $"battery_status" as "new_battery_status"

          )
          , Seq("asset_code","asset_id", "location", "resource")
          , "right"
        )
        .where(
          ($"asset_code" isNotNull ) && ((($"active" isNotNull) && ($"reported_time" isNotNull)) ||
            (($"new_active" isNotNull) && ($"new_reported_time" isNotNull)) )
        )
        .withColumn("distance_travel_with_alert"
          , when($"distance_travel_with_alert" isNull, lit(0)).otherwise($"distance_travel_with_alert")
        )
        .withColumn("device_duration",$"new_device_duration")
        .withColumn("old_active",$"active")
        .withColumn("old_category",when($"category" isNull, -1).otherwise($"category") )
        .withColumn("old_odometer_miles",$"odometer_miles" )
        .withColumn("old_odometer_total_miles",$"odometer_total_miles")
        .withColumn("odometer_miles",coalesce($"new_odometer_miles",lit(0.0)) )
        .withColumn("odometer_total_miles",coalesce($"new_odometer_total_miles",lit(0.0)))
        .withColumn("old_distance_travel",$"distance_travel")
        .withColumn("old_distance_travel_with_alert",$"distance_travel_with_alert")
        .withColumn("old_calc_duration",$"calc_duration")

        .withColumn("temperature"
          , when(($"new_temperature" isNotNull)
            , $"new_temperature"
          ).otherwise($"temperature")
        )
        .withColumn("temperature_f"
          , when(($"new_temperature_f" isNotNull)
            , $"new_temperature_f"
          ).otherwise($"temperature_f")
        )
        .withColumn("pressure_psi"
          , when(($"new_pressure_psi" isNotNull)
            , $"new_pressure_psi"
          ).otherwise($"pressure_psi")
        )
        .withColumn("pressure"
          , when(($"new_pressure" isNotNull)
            , $"new_pressure"
          ).otherwise($"pressure")
        )
        .withColumn("temp_comp_pressure"
            , when(($"new_temp_comp_pressure" isNotNull)
            , $"new_temp_comp_pressure"
          ).otherwise($"temp_comp_pressure")
        )
       .withColumn("battery_status"
        , when(($"new_battery_status" isNotNull)
          , $"new_battery_status"
          ).otherwise($"battery_status")
       )
        .withColumn("distance_travel"
          , when(
            $"new_odometer_miles" < $"old_odometer_miles"
            , $"new_odometer_miles" // set distance travelled to new value as this indicates a rest
          ).otherwise( abs($"new_odometer_miles" - $"old_odometer_miles") )
        )
        .withColumn("active"
          , when($"new_active" isNotNull, $"new_active").otherwise($"active")
        )

        .withColumn("category"
          , when($"new_category" isNotNull, $"new_category").otherwise($"category")
        )
        .withColumn(
          "state_changed"
          , when( // only check for changed state if the on alert reported_time is 5min old or its an off alert.
            (
              ( ($"new_active" === 1) && ($"new_reported_time" cast "long") - ( coalesce($"reported_time",$"old_reported_time",current_timestamp) cast "long")  >= (PipelineUtil.getEnvVariable("ALERT_STATE_CHANGE_HOLDOFF_MINS","5").toInt * 60) )
              || ($"new_active" === 0)
              )
            , when( ($"new_active" isNull)
              , $"state_changed"
            ).otherwise(
              when(
                ( ($"old_active" isNull) && ($"new_active" === 1) )
                , "true"
              ).otherwise(
                when( ($"new_active" =!= $"old_active")
                  , "true"
                ).otherwise(
                  when(
                    ($"new_category" isNotNull) && (coalesce($"old_category",lit(0)) =!= $"new_category")
                    , "true"
                  ).otherwise("false")
                )
              )
            )
          ).otherwise("false")
        )
        .withColumn("old_distance_travel_with_alert"
          , when($"old_distance_travel_with_alert" isNull, lit(0)).otherwise($"old_distance_travel_with_alert") cast "double"
        )
        .withColumn("distance_travel_with_alert"
          , when(($"new_active" === 1) || ($"active" === 1)
            , ($"old_distance_travel_with_alert" cast "double") + ($"distance_travel" cast "double")
          ).otherwise(0)
        )
        .withColumn("calc_duration",
          when($"old_active" === 0 && $"new_active" === 1 // reset duration when transition from off to on
            , lit(0)
          ).otherwise(abs(($"new_reported_time" cast "long") - ($"reported_time" cast "long")))
        )
        .withColumn("old_reported_time"
          , when(($"state_changed" === "true")
            , $"reported_time"
          ).otherwise($"old_reported_time")
        )
        .withColumn("reported_time"
          , when(($"state_changed" === "true")
            , $"new_reported_time"
          ).otherwise(
            when( $"reported_time" isNull, $"new_reported_time").otherwise($"reported_time")
          )
        )
        .withColumn("category"
          , when($"state_changed" === "true"
            , $"new_category"
          ).otherwise(
            when( $"category" isNull, $"new_category").otherwise($"category")
          )
        )
        .withColumn("last_updated", current_timestamp() )
        .withColumn("event_start_time"
          , when($"active" === 1
            , when(($"event_start_time" isNull) || ($"event_start_time" > $"reported_time")
              , $"reported_time"
            ).otherwise(
              when(
                (abs( ($"old_reported_time" cast "long") - ($"new_reported_time" cast "long") ) >= (PipelineUtil.getEnvVariable("ALERT_EVENT_DELTA_HRS","16").toInt * 3600))
                && ($"state_changed" === "true")
                , $"new_reported_time"
              ).otherwise($"event_start_time")
            )
          ).otherwise( // if event_start_time is null set it to the reported time of the off event
            when( ($"event_start_time" isNull) && ($"active" === 0)
              , $"new_reported_time"
            ).otherwise($"event_start_time")
          )
        )
        .withColumn("est_duration"
          , when($"active" === 1
            , abs(($"last_updated" cast "long") - ($"reported_time" cast "long"))
          ).otherwise(0)
        )
        .where(($"asset_code" isNotNull) && ($"active" isNotNull))
        .select(notify_schema.fields.toList.map(r => col(r.name)): _*)
        .persist(StorageLevel.MEMORY_AND_DISK)


    val current_asset_with_alerts = assets_with_alert
      .withColumn("checkpoint_timestamp",floor( lit( System.currentTimeMillis() / (3600 * 1000) ) ) * 3600)
      .as[ActiveAlertNotification]
      .withColumn(
        "rec_rank"
        , rank over Window.partitionBy("asset_code","location","resource").orderBy(asc("reported_time"))
      )
      .withColumn(
        "max_rank"
        , max("rec_rank") over Window.partitionBy("asset_code","location","resource")
      )
      .withColumn(
        "category"
        , when($"category" isNull, lit(0)).otherwise($"category")
      )
      .where($"max_rank" === $"rec_rank") // select the last record
      .drop("max_rank","rec_rank")
      .dropDuplicates("asset_code","location","resource")
      .as[ActiveAlertNotification]

    //appLogger.info(s"New alert count: current_asset_with_alerts.count()")

    val final_asset_alert_state = current_asset_with_alerts
      .where(
        ($"state_changed" === "true") && ($"active" isNotNull)

      ) // only send notification for alerts that have changed state
      .withColumn("duration"
        , when(($"active" === 1)
          , when( ($"calc_duration" isNull) || ($"calc_duration" <= 0 )
            , when($"old_calc_duration" isNotNull
              ,$"old_calc_duration"
            ).otherwise($"est_duration")
          ).otherwise($"calc_duration")
        ).otherwise(0)
      )
      .withColumn("distance_travel_with_alert"
        , when( ($"distance_travel_with_alert" isNull) || ($"distance_travel_with_alert" <= 0 )
          , $"old_distance_travel_with_alert"
        ).otherwise($"distance_travel_with_alert") cast "double"
      )
      .select(concat_ws("-", $"asset_code", $"location",$"resource") as "key"
        , to_json(
          struct(current_asset_with_alerts.columns.map(col(_)): _*)
        ) as "value"
      )

    // if email notifications are enabled then update notification topic
    if (PipelineUtil.getEnvVariable("EMAIL_NOTIFICATION_ENABLED","True").toBoolean) {
      PipelineUtil.writeDataFrameToEmailNotificationKafkaTopic(
        final_asset_alert_state.coalesce(6)
        , "append"
        , PipelineUtil.kafkaConfig
        , pipelineConfig.getString("email_alerts_topic")
      )
    }

    // persist new state
    val cached_df = current_asset_with_alerts
      .select(concat_ws("-", $"asset_code", $"location",$"resource") as "spark_key"
        , to_json(
          struct(current_asset_with_alerts.columns.map(col(_)): _*)
        ) as "alert_state"
        , $"asset_code"
        , $"location" as "wheel_location"
        , $"resource"
        , $"last_updated"
        , lit(pipelineConfig.getString("alerts_prev_notification_topic")) as "topic"
      ).dropDuplicates("spark_key")


    val cached_df_schema = ScalaReflection.schemaFor[ActiveAlertNotificationCache].dataType.asInstanceOf[StructType]
    val finalDf = asKafkaConnectJsonMessage(selectNCastDataFrameAsSchema(cached_df, cached_df_schema)
      , setNullableStateForAllColumns( cached_df_schema, true)
      , Seq("schema","payload","topic","spark_key").toList
    )
      .select($"spark_key" as "key"
        , to_json(struct($"schema",$"payload")) as "value"
        , $"topic"
      )

   // PipelineUtil.writeDataFrameToKafka(finalDf, "append", PipelineUtil.kafkaConfig)

    PipelineUtil.writeDataFrameToKafkaTopic(finalDf, "append", PipelineUtil.kafkaConfig
      , pipelineConfig.getString("alerts_prev_notification_topic")
    )

    assets_with_alert.unpersist()
    wheel2distance.unpersist()
  }

  def doNotificationEventsProcessing() {

    val AllMessage = PipelineUtil.readDataFrameFromKafka(
      pipelineConfig.getString("alerts_notification_topic")
      , PipelineUtil.kafkaConfig
    )

    // persist wheel information
    AllMessage.writeStream
      .trigger(Trigger.ProcessingTime("1 minutes"))
      .outputMode("append")
      //.option("checkpointLocation", pipelineConfig.getString("checkpoint_path") + "/active_alerts")
      .foreachBatch(processMessagesByBatch _)
      .queryName("Process Active Alert Notifications")
      .start()


  }
}
