package com.sensata.data_office.pipeline.queries

import com.sensata.data_office.data._
import com.sensata.data_office.utilities.PipelineUtil
import com.typesafe.config.ConfigFactory
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.catalyst.ScalaReflection
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{first, _}
import org.apache.spark.sql.streaming.Trigger
import org.apache.spark.sql.types.StructType
import org.apache.spark.storage.StorageLevel

/**
 *
 */
object GnssEventProcessor {

  val pipelineConfig = ConfigFactory
    .load(s"application.${PipelineUtil.getEnvVariable("ENVIRONMENT")}.conf")
    .getConfig("EventProcessors").getConfig("pipeline")

  val VERSION = pipelineConfig.getString("version")

  val watermark_column = ConfigFactory
    .load(s"application.${PipelineUtil.getEnvVariable("ENVIRONMENT")}.conf").getConfig("high_watermark").getString("watermark_column")
  val watermark_delay_threashold = ConfigFactory
    .load(s"application.${PipelineUtil.getEnvVariable("ENVIRONMENT")}.conf").getConfig("high_watermark").getString("watermark_delay_threashold")
  val late_record_threshold_sec = ConfigFactory
    .load(s"application.${PipelineUtil.getEnvVariable("ENVIRONMENT")}.conf").getConfig("high_watermark").getString("late_record_threshold_sec")

  import PipelineUtil.spark.implicits._


  def joinCustomerMetaData(gnss_df: DataFrame, customer_data: DataFrame): DataFrame = {
    gnss_df.join(
      customer_data
      , Seq("device_id")
      , "left"
    )
      .withColumnRenamed("v_asset_id","asset_id" )
      .withColumnRenamed("v_asset_code","asset_code")
      .withColumn("company", $"company_name")
      .withColumn("fleet", $"fleet_name")
      .withColumn("asset_name", $"company_asset_name")
      .withColumn("wheel_config", $"v_wheel_config")
      .withColumn("no_axles", $"v_no_axles")
      .withColumn("image_url", $"v_image_url")
      .withColumn("topic_id", when(($"v_topic_id" isNull) || ($"v_topic_id" === "N/A")
        , lit("all")).otherwise($"v_topic_id")
      )
      .where($"asset_code" isNotNull) // any message with out an asset_code is useless at this stage.
  }

  def addAndFilterByMaxReportedTimeByAssetCode(df: DataFrame): DataFrame = {
    df.withColumn("max_reported_msg_time"
      , max("reported_time") over Window.partitionBy($"asset_code").orderBy($"reported_time")
    )
      .where($"max_reported_msg_time" === $"reported_time")
  }

  def processMessagesByBatch(batchMessage: DataFrame, batchId: Long): Unit = {

  /*  val assetRoutesNOffset = PipelineUtil.updateCustomerDimCache()


    val customer_data  = try {
      PipelineUtil.updateCustomerDimCacheFromDatabase()
    } catch {
      case _=> assetRoutesNOffset._1
    }*/

    val customer_data = try {
      PipelineUtil.updateCustomerDimCacheFromDatabase()
        .persist(StorageLevel.MEMORY_AND_DISK)
    } catch {
      case _ => PipelineUtil.FetchCustomerDeviceFromDatabase()
        .persist(StorageLevel.MEMORY_AND_DISK)
    }

    val list_fedx = customer_data
      .select($"device_id")
      .where($"company_name" === "FedEx")
      .as[String]
      .collect
      .toList


    val AllMessage = batchMessage
      .repartition(10)
      .persist(StorageLevel.MEMORY_AND_DISK)

    if (pipelineConfig.getBoolean("in_debug")) {
      AllMessage.write
        .format("delta")
        .mode("append")
        .option("mergeSchema", "true")
        .save(pipelineConfig.getString("dest_data_path") + "gps_raw")
    }

    // read the new motion data and get the pos data from it.
    val posDataMotion = AllMessage
      .where(get_json_object($"value" cast "string", "$.resource") === MessageTypes.GnssMotion)
      .select(
        from_json($"value" cast "string"
          , ScalaReflection.schemaFor[VehicleGnssMotion].dataType.asInstanceOf[StructType]
        ) as "events"
      ).select($"events.*")
      .as[VehicleGnssMotion]
      .withColumn("latitude", $"data.position.latitude" cast "double")
      .withColumn("longitude", $"data.position.longitude" cast "double")
      .withColumn("altitude", $"data.position.altitude" cast "double")
      .withColumn("data", $"data.position")
      .withColumn("resource", lit("position"))


    // read the new motion data and get the time data from it.
    val timeDataMotion = AllMessage
      .where(get_json_object($"value" cast "string", "$.resource") === MessageTypes.GnssMotion)
      .select(
        from_json($"value" cast "string"
          , ScalaReflection.schemaFor[VehicleGnssMotion].dataType.asInstanceOf[StructType]
        ) as "events"
      ).select($"events.*")
      .as[VehicleGnssMotion]
      .withColumn("gps_time", ($"data.time.time" / 1000) cast "timestamp")
      .withColumn("data", $"data.time")
      .withColumn("resource", lit("time"))


    // read the new motion data and get the time data from it - ticket 2688
    val velDataMotion = AllMessage
      .where(get_json_object($"value" cast "string", "$.resource") === MessageTypes.GnssMotion)
      .select(
        from_json($"value" cast "string"
          , ScalaReflection.schemaFor[VehicleGnssMotion].dataType.asInstanceOf[StructType]
        ) as "events"
      ).select($"events.*")
      .as[VehicleGnssMotion]
      .withColumn("speed", $"data.velocity.speed" cast "double")
      .withColumn("heading", $"data.velocity.heading" cast "double")
      .withColumn("data", $"data.velocity")
      .withColumn("resource", lit("velocity"))


    val prevActiveAlerts = PipelineUtil.getAssetAlertStateFromDatabaseCache()
      .where( ($"active" === 1) || ($"active" === 0)).cache()

    val prevActivity = PipelineUtil.getAssetActivityStateFromDatabaseCache()

    val no_alerts_df = prevActiveAlerts.select(
      $"asset_code"
      , when($"resource" === MessageTypes.WarningEventPressure,1).otherwise(0) as "has_pressure_alert"
      , $"category" cast "int"
    ).where($"active" === 1)
      .withColumn("max_alert_category",
        max("category") over Window.partitionBy("asset_code")
      )
      .groupBy("asset_code").agg(
      first("max_alert_category", true) as "max_alert_category"
      , sum($"has_pressure_alert") as "has_pressure_alert"
    )

    // get the GPS data
    val posDataOld = AllMessage
      .where(get_json_object($"value" cast "string", "$.resource") === MessageTypes.GnssPos)
      .select(
        from_json($"value" cast "string"
          , ScalaReflection.schemaFor[VehicleGnssPos].dataType.asInstanceOf[StructType]
        ) as "events"
      ).select($"events.*")
      .as[VehicleGnssPos]
      .withColumn("latitude", $"data.latitude" cast "double")
      .withColumn("longitude", $"data.longitude" cast "double")
      .withColumn("altitude", $"data.altitude" cast "double")

    val posData = posDataOld.union(posDataMotion)

    val timeDataOld = AllMessage
      .where(get_json_object($"value" cast "string", "$.resource") === MessageTypes.GnssTime)
      .select(
        from_json($"value" cast "string"
          , ScalaReflection.schemaFor[VehicleGnssTime].dataType.asInstanceOf[StructType]
        ) as "events"
      ).select($"events.*")
      .as[VehicleGnssTime]
      .withColumn("gps_time", ($"data.time" / 1000) cast "timestamp")

    val timeData = timeDataOld.union(timeDataMotion)

    val velDataOld = AllMessage
      .where(get_json_object($"value" cast "string", "$.resource") === MessageTypes.GnssVelocity)
      .select(
        from_json($"value" cast "string"
          , ScalaReflection.schemaFor[VehicleGnssVelocity].dataType.asInstanceOf[StructType]
        ) as "events"
      ).select($"events.*")
      .as[VehicleGnssVelocity]
      .withColumn("speed", $"data.speed" cast "integer")
      .withColumn("heading", $"data.heading" cast "integer")

    val velData = velDataOld.union(velDataMotion)

    val distanceOldData = AllMessage
      .where(get_json_object($"value" cast "string", "$.resource") === MessageTypes.GnssDistance)
      .select(
        from_json($"value" cast "string"
          , ScalaReflection.schemaFor[VehicleGnssDistance].dataType.asInstanceOf[StructType]
        ) as "events"
      ).select($"events.*")
      .as[VehicleGnssDistance]
      .withColumn("odometer", $"data.odometer" cast "integer")
      .withColumn("odometer_total", $"data.odometer_total" cast "integer")

    //this is for New Odometer total msg from Hub - ticket - 2635
    val OdoDistData = AllMessage
      .where(get_json_object($"value" cast "string", "$.resource") === MessageTypes.OdometerDist)
      .select(
        from_json($"value" cast "string"
          , ScalaReflection.schemaFor[VehicleOdoDist].dataType.asInstanceOf[StructType]
        ) as "events"
      ).select($"events.*")
      .as[VehicleOdoDist]
      .withColumn("odometer_total_in_KM", $"data.distance" cast "integer")

    //this is for New Odometer msg from Hub - ticket - 2635
    val OdoTripDistData = AllMessage
      .where(get_json_object($"value" cast "string", "$.resource") === MessageTypes.OdometerTripDist)
      .select(
        from_json($"value" cast "string"
          , ScalaReflection.schemaFor[VehicleOdoTripDist].dataType.asInstanceOf[StructType]
        ) as "events"
      ).select($"events.*")
      .as[VehicleOdoTripDist]
      .withColumn("odometer_in_KM", $"data.trip-distance" cast "integer")

    val OdoFinal = OdoDistData.alias("odisd").join(
      OdoTripDistData.alias("otdisd")
      , (
        ($"odisd.deviceId" === $"otdisd.deviceId")
        )
      , "outer"
    )
      .select(coalesce($"odisd.deviceId",$"otdisd.deviceId") as "deviceId",
        coalesce($"odisd.time",$"otdisd.time") as "time",
        coalesce($"odisd.timestamp",$"otdisd.timestamp") as "timestamp",
        coalesce($"odisd.consumed_timestamp",$"otdisd.consumed_timestamp") as "consumed_timestamp",
        coalesce($"odisd.customer",$"otdisd.customer") as "customer",
        coalesce($"odisd.version",$"otdisd.version") as "version",
        $"odometer_in_KM" * 1000 as "odometer",
        $"odometer_total_in_KM" * 1000 as "odometer_total"
       )

    val distanceData = distanceOldData.alias("odold").join(
      OdoFinal.alias("odofin")
    , (
      ($"odold.deviceId" === $"odofin.deviceId")
      )
    , "outer"
    )
     .select(
         when($"odold.consumed_timestamp" isNotNull
         , $"odold.consumed_timestamp").otherwise(lit(null)) as "consumed_timestamp_o"
       , when($"odofin.consumed_timestamp" isNotNull
         , $"odofin.consumed_timestamp").otherwise(lit(null)) as "consumed_timestamp_n"
       , when($"odold.deviceId" isNotNull
         , $"odold.deviceId").otherwise(lit(null)) as "deviceId_o"
       , when($"odofin.deviceId" isNotNull
         , $"odofin.deviceId").otherwise(lit(null)) as "deviceId_n"
       , when($"odold.deviceId" isNotNull
         , $"odold.time").otherwise(lit(null)) as "time_o"
       , when($"odofin.deviceId" isNotNull
         , $"odofin.time").otherwise(lit(null)) as "time_n"
       , when($"odold.deviceId" isNotNull
         , $"odold.timestamp").otherwise(lit(null)) as "timestamp_o"
       , when($"odofin.deviceId" isNotNull
         , $"odofin.timestamp").otherwise(lit(null)) as "timestamp_n"
       , when($"odold.deviceId" isNotNull
         , $"odold.odometer").otherwise(lit(null)) cast "integer" as "odometer_o"
       , when($"odofin.deviceId" isNotNull
         , $"odofin.odometer").otherwise(lit(null)) cast "integer" as "odometer_n"
       , when($"odold.deviceId" isNotNull
         , $"odold.odometer_total").otherwise(lit(null)) cast "integer" as "odometer_total_o"
       , when($"odofin.deviceId" isNotNull
         , $"odofin.odometer_total").otherwise(lit(null)) cast "integer" as "odometer_total_n"
       , when($"odold.customer" isNotNull
         , $"odold.customer").otherwise(lit(null)) cast "string" as "customer_o"
       , when($"odofin.customer" isNotNull
         , $"odofin.customer").otherwise(lit(null)) cast "string" as "customer_n"
       , when($"odold.version" isNotNull
         , $"odold.version").otherwise(lit(null)) cast "double" as "version_o"
       , when($"odofin.version" isNotNull
         , $"odofin.version").otherwise(lit(null)) cast "double" as "version_n"
      )
      .withColumn("deviceId",coalesce($"deviceId_n",$"deviceId_o"))
      .withColumn("time",coalesce($"time_n",$"time_o"))
      .withColumn("timestamp",coalesce($"timestamp_n",$"timestamp_o"))
      .withColumn("consumed_timestamp",coalesce($"consumed_timestamp_n",$"consumed_timestamp_o"))
      .withColumn("odometer",coalesce($"odometer_n",$"odometer_o"))
      .withColumn("odometer_total",coalesce($"odometer_total_n",$"odometer_total_o"))
      .withColumn("service", lit("gnss"))
      .withColumn("version", coalesce($"version_n",$"version_o"))
      .withColumn("customer", coalesce($"customer_n",$"customer_o"))
      .dropDuplicates("deviceId")
      .drop("deviceId_n",
        "deviceId_o",
        "time_n",
        "time_o",
        "timestamp_n",
        "timestamp_o",
        "consumed_timestamp_n",
        "consumed_timestamp_o",
        "odometer_n",
        "odometer_o",
        "odometer_total_n",
        "odometer_total_o",
        "customer_n",
        "customer_o",
        "version_n",
        "version_o"

        )

    // add new functionality for Atis message - ticket 2237
    val atisData = addAndFilterByMaxReportedTimeByAssetCode(
      joinCustomerMetaData(
      AllMessage
      .where(get_json_object($"value" cast "string", "$.resource") === MessageTypes.AtisAlerts)
      .select(
        from_json($"value" cast "string"
          , ScalaReflection.schemaFor[VehicleAtis].dataType.asInstanceOf[StructType]
        ) as "events"
      ).select($"events.*")
      .as[VehicleAtis]
      .withColumn("state", $"data.state")
      .withColumn("device_id", $"deviceId")
        .withColumn("reported_time", $"time" cast "timestamp")
        , customer_data
      )
    )
      .drop("max_reported_msg_time")

       //*****************************************This is for FEDX ATIS****************************************

    val device_list_fedx = List("1KqjV1xC2C12","1JXjSbXCWPF2","1KqjV1xC2H12","1JXjTVLCZCF2","55090041",
      "54990065","1JZGMSg1H112","54990142","1JZGMSg1Gg12","54990170","1JZGMSg1Hp12","54990211","50700238","1KqjV1xC2g12"
      ,"1JXjTVLCZ3F2","1KqjV1xC1j12","1JXjTVLCYtF2","1JXjTVLCYyF2","1KqjV1xC2r12","1JXjTVLCZHF2","1KqjV1xC1d12"
      ,"1JXjTVLCYPF2","1KqjV1xC1t12","1JXjpFXC6312","1JXjpFXC9F12","1JXk3nkC1t12","1KqjyYXC1d12","1JXjkgXC6g12"
      ,"1JXjpFXC8b12","1Kqjw1XC2b12","1JXjpFXCCP12","1JXjpFXC5d12","1JXjpFXC4w12","1JXjpVLC1Y12","1JXjpFXC7K12"
      ,"1JXjpVLC7j12","1JXjpFXC9112","1KqjyYXC1Y12","1JXjpVLC3F12","1JXjpVLC4712","1JXjpVLC4H12","1JXjpVLC7512"
      ,"1JXjpFXC8g12","1JXjpFXC8312","1JXjpVLC7P12","1JXjpVLC2H12","1JXjpVLC3Y12","1JXjpVLC6312","1JXjpFXCBC12"
      ,"1JXjpFXCBM12","1JXjpVLC7d12","24100026","24100006","24100035","24100058","1JXjpFXC5p12","1JXjpVLC3P12"
      ,"1JXjpFXC5t12","1JXjpVLC4W12","24100005","24100011","24100030","24100016","24100023","24100047","24100054"
      ,"24100020","24100021","24100019","24100008","24100060","24100038","23344444","24100055","1JXjpFXC8M12"
      ,"24100036","1JXjpFXC6C12","1Kqjw1XC3112","1JXjpFXC5Y12","1JXjpFXC7112","1JXjmr8C2R12","1JXjpFXC5912"
      ,"1JXjpVLC2R12","1JXjpFXC2C12","1JXjpFXC1t12","1JXjpVLC3d12","1KqjsqkC1912","1JXjpFXC6R12","1KqjYb8C2312"
      ,"1JXjpVLC3t12","1JXjpFXC3112","1JXjpVLC5112","1JXjpVLC5512","1JXjpVLC5K12","1JXjpVLC4r12","1JXjpVLC6H12"
      ,"1JXjpVLC3512","1JXjpFXC3512","1JXjpFXC1P12","1JXjpFXC3F12","1JXjpFXC3d12","1JXjpVLC2g12","1JXjpFXC3j12"
      ,"1JXjpVLC2w12","1JXjpFXC2w12","1JXjpFXC7t12"
    )

    val Fedx_Atis_Message = AllMessage
      .where(get_json_object($"value" cast "string", "$.resource") === MessageTypes.AtisAlerts)
      //  && get_json_object($"value" cast "string", "$.version") < 2.0)
      .filter(get_json_object($"value" cast "string", "$.deviceId").isin(list_fedx:_*))
      .select($"value")

      PipelineUtil.writeDataFrameToKafkaTopic(Fedx_Atis_Message, "append", PipelineUtil.kafkaConfig
        , pipelineConfig.getString("fedx_alerts_new_topic")
      )

    //**************************************This is for FEDX ATIS********************************************

      // add new funtionality for Truck-Trailer message - ticket 2369
    val ttlData = addAndFilterByMaxReportedTimeByAssetCode(
      joinCustomerMetaData(AllMessage
      .where(get_json_object($"value" cast "string", "$.resource") === MessageTypes.TtlAlerts)
      .select(
        from_json($"value" cast "string"
          , ScalaReflection.schemaFor[VehicleTtl].dataType.asInstanceOf[StructType]
        ) as "events"
      ).select($"events.*")
      .as[VehicleTtl]
      .withColumn("ip_addresses", $"data.ip_addresses")
      .withColumn("device_id", $"deviceId")
        .withColumn("reported_time", $"time" cast "timestamp")
        , customer_data
      )
    )
      .drop("max_reported_msg_time")


       // add new funntionality for KL15-Monitor message - ticket 2369
    val kl15Data = addAndFilterByMaxReportedTimeByAssetCode(
      joinCustomerMetaData(AllMessage
      .where(get_json_object($"value" cast "string", "$.resource") === MessageTypes.Kl15Alerts)
      .select(
        from_json($"value" cast "string"
          , ScalaReflection.schemaFor[VehicleKl15].dataType.asInstanceOf[StructType]
        ) as "events"
      ).select($"events.*")
      .as[VehicleKl15]
      .withColumn("kl15_pin_state", when($"data.kl15_pin_state" === "active",1).otherwise(0))
      .withColumn("device_id", $"deviceId")
        .withColumn("reported_time", $"time" cast "timestamp")
        , customer_data
      )
    )
      .drop("max_reported_msg_time")

    // join the velocity data. union a right and a left join to get devices that don't
    // send position but send velocity
    val pos_with_vel = posData.alias("apos").join(
      velData.alias("avel")
      , (
        ($"apos.deviceId" === $"avel.deviceId")
         && (abs((($"apos.time" cast "long") - ($"avel.time" cast "long"))) < lit(late_record_threshold_sec))
        )
      , "outer"
    )
       .withColumn("join_key",coalesce($"apos.deviceId",$"avel.deviceId"))
      .withColumn("join_time_key",coalesce($"apos.time",$"avel.time"))
      .withColumn("join_timestamp",coalesce($"apos.timestamp",$"avel.timestamp"))
      .withColumn("join_customer",coalesce($"apos.customer",$"avel.customer"))
      .withColumn("join_consumed_timestamp",coalesce($"apos.consumed_timestamp",$"avel.consumed_timestamp"))
      .withColumn("join_key_service",coalesce($"apos.service",$"avel.service"))
      .withColumn("join_version",coalesce($"apos.version",$"avel.version"))
      .dropDuplicates("join_key")

    // join the distance data. union a right and a left join to get devices that don't
    // send position or veloctiy but send odometer
    val GpsDfwithDups1 = pos_with_vel.join(
      distanceData.alias("adist")
      , (
        ($"join_key" === $"adist.deviceId")
          && (abs((($"join_time_key" cast "long") - ($"adist.time" cast "long"))) < lit(late_record_threshold_sec))
        )
      , "outer"
    )
      .withColumn("join_key",coalesce($"join_key",$"adist.deviceId"))
      .withColumn("join_time_key",coalesce($"join_time_key",$"adist.time"))
      .withColumn("join_timestamp",coalesce($"join_timestamp",$"adist.timestamp"))
      .withColumn("join_customer",coalesce($"join_customer",$"adist.customer"))
      .withColumn("join_consumed_timestamp",coalesce($"join_consumed_timestamp",$"adist.consumed_timestamp"))
      .withColumn("join_key_service",coalesce($"join_key_service",$"adist.service"))
      .withColumn("join_version",coalesce($"join_version",$"adist.version"))
      .dropDuplicates("join_key")
      .join(
      timeData.alias("atime")
      , (
        ($"join_key" === $"atime.deviceId")
          && (abs((($"join_time_key" cast "long") - ($"atime.time" cast "long"))) < lit(late_record_threshold_sec))
        )
      , "left"
    )

      val GpsDfwithDups = GpsDfwithDups1.select(
      concat_ws("-", $"join_key_service", lit("curated")) as "service"
      , $"join_key" as "device_id"
      , $"join_customer" as "device_name"
      , $"join_time_key" cast "timestamp" as "reported_time"
      , $"join_version" as "schema_version"
      , $"join_timestamp" cast "timestamp" as "pipeline_timestamp"
      , $"join_consumed_timestamp" cast "long" as "consumed_timestamp"
      , when($"apos.latitude" isNotNull
          , $"apos.latitude").otherwise(lit(null)) cast "double" as "latitude"
      , when($"apos.longitude" isNotNull
          , $"apos.longitude").otherwise(lit(null)) cast "double" as "longitude"
      , when($"apos.altitude" isNotNull
          ,$"apos.altitude").otherwise(lit(null)) cast "integer" as "altitude"
      , when($"atime.deviceId" isNotNull
         , $"atime.gps_time").otherwise($"join_time_key" cast "timestamp") cast "timestamp" as "gps_timestamp"
      , when($"avel.deviceId" isNotNull
         , $"avel.speed").otherwise(lit(null)) cast "double" as "measured_speed"
      , when($"avel.deviceId" isNotNull
         , $"avel.heading").otherwise(lit(null)) cast "double" as "measured_heading"
      , when($"adist.deviceId" isNotNull
         , $"adist.odometer").otherwise(lit(null)) cast "integer" as "odometer"
      , when($"adist.deviceId" isNotNull
         , $"adist.odometer_total").otherwise(lit(null)) cast "integer" as "odometer_total")
      .drop("join_key_service")
      .drop("join_key")
      .drop("join_customer")
      .drop("join_time_key")
      .drop("join_version")
      .drop("join_timestamp")
      .drop("join_consumed_timestamp")
      .withColumn("odometer_in_miles",
      $"odometer" * 0.000621371)
      .withColumn("odometer_total_in_miles",
        $"odometer_total" * 0.000621371)
      .na.fill(
      Map(
        "device_name" -> "N/A",
        "schema_version" -> 0
      )
    )

    // remove any duplicate due to the odometer being from a different device
    val GpsDf = joinCustomerMetaData(
      GpsDfwithDups
      , customer_data
    )

    // get final message schema
    val gps_data_schema = ScalaReflection.schemaFor[ProcessedGPSRecord].dataType.asInstanceOf[StructType]

    val batchData1 = GpsDf.alias("joincusgps")
      .withColumn("join_key",$"joincusgps.asset_code")
      .join(
        atisData.alias("aatis")
        , ($"join_key" === $"aatis.asset_code")
          , "outer"
      )
      //add two more full outer join for TTL & kl15 messages - ticket 2369
      .join(
        ttlData.alias("attl")
        , ($"join_key" === $"attl.asset_code")
        , "outer"
      )
      .join(
        kl15Data.alias("akl15")
        , ($"join_key" === $"akl15.asset_code")
          , "outer"
      )
      .join(  // join alerts after because device id has to be set first
        no_alerts_df.select("asset_code","max_alert_category","has_pressure_alert")
        , Seq("asset_code")
        , "left"
      )
      .withColumn("atis_state", $"aatis.state")
      .withColumn("atis_reported_time", $"aatis.time" cast "timestamp")
      .withColumn("ttl_active", $"attl.ip_addresses" cast "string")
      .withColumn("kl15_pin_state", $"akl15.kl15_pin_state" cast "integer")
      .withColumn("final_device_id"
        , coalesce($"joincusgps.device_id",$"aatis.device_id",$"attl.device_id",$"akl15.device_id")
      )
      .withColumn("final_asset_code"
        , coalesce($"joincusgps.asset_code",$"aatis.asset_code",$"attl.asset_code",$"akl15.asset_code")
      )
      .withColumn("final_asset_id"
        , coalesce($"joincusgps.asset_id",$"aatis.asset_id",$"attl.asset_id",$"akl15.asset_id")
      )
      .withColumn("final_asset_name"
        , coalesce($"joincusgps.asset_name",$"aatis.asset_name",$"attl.asset_name",$"akl15.asset_name")
      )
      .withColumn("final_company"
        , coalesce($"joincusgps.company",$"aatis.company",$"attl.company",$"akl15.company")
      )
      .withColumn("final_fleet"
        , coalesce($"joincusgps.fleet",$"aatis.fleet",$"attl.fleet",$"akl15.fleet")
      )
      .withColumn("final_reported_time"
        , coalesce($"joincusgps.reported_time",$"aatis.reported_time",$"attl.reported_time",$"akl15.reported_time")
      )
      .withColumn("final_device_name"
        , coalesce($"joincusgps.device_name",$"aatis.company",$"attl.company",$"akl15.company")
      )
      .withColumn("final_pipeline_timestamp"
        , coalesce($"joincusgps.pipeline_timestamp",$"aatis.timestamp",$"attl.timestamp",$"akl15.timestamp")
      )
      .withColumn("final_consumed_timestamp"
        , coalesce($"joincusgps.consumed_timestamp",$"aatis.consumed_timestamp",$"attl.consumed_timestamp",$"akl15.consumed_timestamp")
      )
      .withColumn("final_schema_version"
        , coalesce($"joincusgps.schema_version",$"aatis.version",$"attl.version",$"akl15.version")
      )
      .withColumn("not_null_topic_id"
        , coalesce($"joincusgps.topic_id",$"aatis.topic_id",$"attl.topic_id",$"akl15.topic_id")
      )
      .withColumn("final_topic_id"
        , when($"not_null_topic_id" isNull, lit("all")).otherwise($"not_null_topic_id")
      )
      .withColumn("topic", concat_ws("-", $"final_topic_id", lit("vehicle-stream-current")))
      .withColumn("last_updated"
        , to_timestamp(
          from_unixtime(unix_timestamp(), "yyyy-MM-dd HH:mm:ss")
        )
      )
        .select(
          concat_ws("-", lit("gnss"), lit("curated")) as "service",
          $"final_device_id" as "device_id",
          $"final_device_name" as "device_name",
          $"final_asset_id" as "asset_id",
          $"final_asset_code" as "asset_code",
          $"final_topic_id" as "topic_id",
          $"final_reported_time" as "reported_time",
          $"final_schema_version" as "schema_version",
          $"final_pipeline_timestamp" as "pipeline_timestamp",
          $"final_consumed_timestamp" as "consumed_timestamp",
          $"joincusgps.latitude" as "latitude",
          $"joincusgps.longitude" as "longitude",
          $"joincusgps.altitude" as "altitude",
          $"joincusgps.measured_speed" as "measured_speed",
          $"joincusgps.measured_heading" as "measured_heading",
          $"joincusgps.odometer" as "odometer",
          $"joincusgps.odometer_total" as "odometer_total",
          $"joincusgps.odometer_in_miles" as "odometer_in_miles",
          $"joincusgps.odometer_total_in_miles" as "odometer_total_in_miles",
          $"final_company" as "company",
          $"final_fleet" as "fleet",
          $"final_asset_name" as "asset_name",
          $"joincusgps.wheel_config" as "wheel_config",
          $"joincusgps.no_axles" as "no_axles",
          $"atis_reported_time",
          $"joincusgps.gps_timestamp" as "gps_timestamp",
          $"joincusgps.image_url" as "image_url",
          $"atis_state",
          $"ttl_active",
          $"kl15_pin_state",
          $"topic",
          $"max_alert_category",
          $"has_pressure_alert",
          $"last_updated"
          )

     val batchData = batchData1
      .withColumn("device_has_alerts"
        , when($"has_pressure_alert" > 0
          , when(($"max_alert_category" isin (0,1,3))
            , lit(3)   // alert
          ).otherwise(
            when( ($"max_alert_category" isin(2,1))
              , lit(2)  // warning
            ).otherwise(0)
          )
        ).otherwise(
          when(($"max_alert_category" === 0)
            , lit(3)   // alert
          ).otherwise(
            when( ($"max_alert_category" isin(2,1))
              , lit(2)  // warning
            ).otherwise(0)
          )
        )
      ).join(
        prevActiveAlerts.select(
        $"asset_code"
        , $"location"
        , $"resource"
        , $"reported_time" as "alert_reported_time"
        , $"old_reported_time"
        , $"distance_travel_with_alert"
        , $"distance_travel" as "distance_travelled"
        , $"calc_duration"
        , $"old_calc_duration"
        , $"old_distance_travel_with_alert"
        , $"est_duration"
        , $"old_category"
        , $"event_start_time"
        , $"last_updated" as "alert_last_updated"
      )
        .where($"active" === 1)
        .withColumn("duration"
          , when( ($"calc_duration" isNull) || ($"calc_duration" <= 0 )
            , when($"old_calc_duration" isNotNull
              ,$"old_calc_duration"
            ).otherwise($"est_duration")
          ).otherwise($"calc_duration")
        )
        .groupBy("asset_code").agg(max("duration") as "duration" )
        .select($"asset_code",$"duration")
      , Seq("asset_code")
      , "left"
    )
      .withColumn("alerts_duration_hrs"
        , when($"duration" isNotNull
          , $"duration" / 3600
        ).otherwise( lit(0) )
      )
      .withColumn("vehicle_key", concat($"device_id", $"asset_name", lit("Last 24 Hours")))
      .drop("no_alerts")
      .drop("reported_device_id")
      .join(
        prevActivity.select(
          $"asset_code"
          , $"active_trip"
          , $"distance_travelled"
          , $"active_duration"
          , $"total_duration"
          , $"total_distance_travelled"
          , $"moving"
          , $"atis_state" as "cached_atis_state"
          , $"atis_reported_time" as "cached_atis_reported_time"
        )
        , Seq("asset_code")
        , "left"
      )
      // set ATIS state to the last know data
      .withColumn("atis_state"
        , when($"atis_state" isNotNull
          , $"atis_state"
        ).otherwise($"cached_atis_state")
      )
      .withColumn("atis_reported_time"
        , when($"atis_state" isNotNull
          , $"atis_reported_time"
        ).otherwise($"cached_atis_reported_time")
      )
      .select(gps_data_schema.fields.map(_.name).map(col(_)):_*)
        .where(
          ($"asset_code" isNotNull)
        )
        .dropDuplicates("asset_code")


    // this is for the curated GPS record
    PipelineUtil.writeDataFrameToKafkaTopic(batchData
      .select(concat_ws("-", $"service",$"device_id",$"reported_time") as "key"
        , to_json(
          struct(batchData.columns.map(col(_)): _*)
        ) as "value"
      ).coalesce(6)
      , "append"
      , PipelineUtil.kafkaConfig
      , pipelineConfig.getString("curated_gps_records_topic")
    )

    // publish to asset activity topic
    val df2publish = batchData
      .groupBy("asset_code")
      .agg(
        max("reported_time") as "reported_time"
        , avg("measured_speed") as "measured_speed"
        , avg("measured_heading") as "measured_heading"
        , max("odometer") as "odometer"
        , max("odometer_total") as "odometer_total"
        , max("odometer_in_miles") as "odometer_in_miles"
        , max("odometer_total_in_miles") as "odometer_total_in_miles"
        , first("atis_state",true) as "atis_state"
        , first("atis_reported_time",true) as "atis_reported_time"
        , first("ttl_active",true) as "ttl_active"
        , first("kl15_pin_state",true) as "kl15_pin_state"
      )
      .withColumn("msg_type",lit("gnss"))
      .withColumn("last_updated", current_timestamp())
      .select(concat_ws("-",$"msg_type",$"asset_code") as "key"
        , to_json(
          struct(
            $"msg_type"
            ,$"asset_code"
            ,$"reported_time"
            ,$"measured_speed"
            ,$"measured_heading"
            ,$"odometer"
            ,$"odometer_total"
            ,$"odometer_in_miles"
            ,$"odometer_total_in_miles"
            ,$"atis_state"
            ,$"ttl_active"
            ,$"kl15_pin_state"
            ,$"atis_reported_time"
            , $"last_updated"
          )
        ) as "value"
      ).coalesce(3)

    PipelineUtil.writeDataFrameToKafkaTopic(df2publish, "append", PipelineUtil.kafkaConfig
      , pipelineConfig.getString("asset_activity_topic")
    )

    AllMessage.unpersist()
  }

  def doGnssEventsProcessing() {

    val gnssMessage = PipelineUtil.readDataFrameFromKafkaAndExtractTimestamp(
      pipelineConfig.getString("source_gnss_stream_records_topic")
      , PipelineUtil.kafkaConfig
    )

    // persist wheel information
    gnssMessage
      .writeStream
      .trigger(Trigger.ProcessingTime(PipelineUtil.processing_trigger_time))
      .foreachBatch(processMessagesByBatch _)
      .queryName("Process Vehicle GPS Stream")
      .start()
  }
}
