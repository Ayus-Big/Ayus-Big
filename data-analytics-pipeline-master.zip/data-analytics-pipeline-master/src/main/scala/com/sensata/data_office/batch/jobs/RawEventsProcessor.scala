package com.sensata.data_office.batch.jobs

import com.sensata.data_office.data.{GenericEvent, GenericEventData, MessageTypes}
import com.sensata.data_office.utilities.PipelineUtil
import com.typesafe.config.ConfigFactory
import com.typesafe.scalalogging.Logger
import org.apache.spark.sql.catalyst.ScalaReflection
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}
import org.slf4j.LoggerFactory

object RawEventsProcessor {

  val pipelineConfig = ConfigFactory
    .load(s"application.${sys.env("ENVIRONMENT")}.conf")
    .getConfig("RawEventsProcessor").getConfig("pipeline")
  val dimentionalCfg = ConfigFactory
    .load(s"application.${sys.env("ENVIRONMENT")}.conf")
    .getConfig("dimensional_data")

  val batchCfg = ConfigFactory
    .load(s"application.${sys.env("ENVIRONMENT")}.conf")
    .getConfig("batch_pipeline")

  val VERSION = pipelineConfig.getString("version")

  val spark = SparkSession.builder.appName(pipelineConfig.getString("application_name")).getOrCreate()

  import PipelineUtil.spark.implicits._

  val appLogger = Logger(LoggerFactory.getLogger("spark"))

  def getPartitonTimeStamp(date_format: String) = {

    to_timestamp(
      from_unixtime(unix_timestamp(), date_format)
    ).cast("long")
  }


  def filterOutInvalidMessage(df: DataFrame, version: String): DataFrame = {
    df.where($"body" cast "string" rlike (".*\"service\":\"[a-zA-z/]+\".*"))
      .where($"body" cast "string" rlike (".*\"resource\":\"[a-zA-z/]+\".*"))
      .where($"body" cast "string" rlike (".*\"data\":.*"))
      .where($"body" cast "string" rlike (".*\"version\":\"" + version + "\".*"))
  }

  def buildJsonMessage(df: Dataset[GenericEventData], event_type: String, data_schema: StructType): DataFrame = {
    df.withColumnRenamed("data", "raw_data")
      .withColumn("data", from_json($"raw_data", data_schema)
      ).select(concat_ws("-", lit(event_type), $"time") as "id"
      , from_unixtime($"time" / 1000 cast "long", "yyyy-MM-dd") as "time"
      , to_json(
        struct($"service"
          , $"resource"
          , $"device_id"
          , $"device_name"
          , $"time"
          , $"version"
          , $"timestamp"
          , $"consumed_timestamp"
          , $"data"
          , $"raw_data")
      ) as "body"
    )
  }

  def main(args: Array[String]) {

    val rawMessage =
      spark.read
        .format("delta")
        .load(batchCfg.getString("raw_data_path"))
        .withColumn("consumed_timestamp"
          , getPartitonTimeStamp(pipelineConfig.getString("received_timestamp_format"))

        )


    val generic_event_schema = ScalaReflection.schemaFor[GenericEvent].dataType.asInstanceOf[StructType]
    val event_schema = ScalaReflection.schemaFor[GenericEventData].dataType.asInstanceOf[StructType]
    var decoded_data = spark.emptyDataFrame
    var df_list: List[DataFrame] = Nil
    try {
      decoded_data = rawMessage
        .select(from_json($"body" cast "string", generic_event_schema) as "events", $"consumed_timestamp" as "ctimestamp")
        .select($"events.device_id" as "device_id"
          , $"events.device_name" as "device_name"
          , $"events.timestamp" as "atimestamp"
          , explode($"events.data") as "metrics"
          , $"ctimestamp")
    } catch {
      case e: org.apache.spark.sql.AnalysisException => {
        appLogger.warn(s"Failed to process some messages in batch: ${e.getMessage()}. Attempt timestamp fix")
        decoded_data = rawMessage
          .select(from_json($"body" cast "string", generic_event_schema) as "events", $"consumed_timestamp" as "ctimestamp")
          .withColumn("atimestamp", lit(System.currentTimeMillis()))
          .select($"events.device_id" as "device_id"
            , $"events.device_name" as "device_name"
            , $"atimestamp"
            , explode($"events.data") as "metrics"
            , $"ctimestamp")
      }
    }
    val IoTEvents = decoded_data.select($"device_id" as "src_device_id"
      , $"device_name" as "src_device_name"
      , $"metrics.*"
      , $"atimestamp"
      , $"ctimestamp")
      .withColumn("device_id", $"src_device_id")
      .withColumn("device_name", $"src_device_name")
      .withColumn("timestamp", $"atimestamp")
      .withColumn("consumed_timestamp", $"ctimestamp")
      .where($"timestamp".isNotNull && (($"timestamp" as "long") > 0))
      .as[GenericEventData]

    for ((aevent, event_topic) <- MessageTypes.eventTopics) {
      // write the message type to the required topic
      df_list = buildJsonMessage(
        IoTEvents.where($"resource" === aevent)
        , aevent
        , MessageTypes.eventDataSchema.getOrElse(aevent, event_schema)
      )
        .withColumn("resource", lit(aevent.replace("/", "_")))
        .withColumn("topic", lit(event_topic)) :: df_list
    }

    // persist to delta lake
    df_list.reduce(_.union(_))
      .repartition(50)
      .write
      .format("delta")
      .mode("overwrite")
      .partitionBy("time", "resource")
      .save(batchCfg.getString("src_data_path") + "processed_message")
  }
}
