package com.sensata.data_office.pipeline.queries

import com.sensata.data_office.data._
import com.sensata.data_office.utilities.Analytics.selectNCastDataFrameAsSchema
import com.sensata.data_office.utilities.PipelineUtil
import com.typesafe.config.ConfigFactory
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.catalyst.ScalaReflection
import org.apache.spark.sql.functions._
import org.apache.spark.sql.streaming.Trigger
import org.apache.spark.sql.types.DataTypes.{TimestampType, createArrayType, createStructType}
import org.apache.spark.sql.types.{BooleanType, StructField, StructType}
import org.apache.spark.storage.StorageLevel

object CustomerDataPublisher {

  val appConfig = ConfigFactory.load(s"application.${PipelineUtil.getEnvVariable("ENVIRONMENT")}.conf").getConfig("CustomerDataPublisher")
  val sparkCfg = ConfigFactory.load(s"application.${PipelineUtil.getEnvVariable("ENVIRONMENT")}.conf").getConfig("CustomerDataPublisher").getConfig("spark")
  val avro_schemas = ConfigFactory.load(s"application.${PipelineUtil.getEnvVariable("ENVIRONMENT")}.conf").getConfig("avro_schemas")
  val pipelineConfig = appConfig.getConfig("pipeline")


  val VERSION = pipelineConfig.getString("version")

  import PipelineUtil.spark.implicits._

  /**
   * Create a combined data from of all records related to a list of customers by filtering the records from a parent dataframe
   * @param parentDf
   * @param df_filter_value_list
   * @return
   */
  def filterNUnionSubDataFrames(parentDf: DataFrame, df_filter_value_list: List[String]): DataFrame = {
    df_filter_value_list
      .map(
        tokn => {
          parentDf.where($"asset_code" like s"${tokn.toUpperCase}-%")
            .withColumn("topic",regexp_replace($"topic",lit("all-"),lit(s"${tokn.toLowerCase}-")))
        }
      )
      .filter(df => !df.isEmpty )
      .reduceOption((df1,df2) => df1.union(df2))
      .getOrElse(
        PipelineUtil.spark.emptyDataFrame.select(
          parentDf.columns
            .map(acol => lit("") as acol ):_*
        )
      )
  }

  def asKafkaConnectJsonMessage(df: DataFrame, req_schema: StructType, columns_to_select: List[String], send_null: Boolean = false): DataFrame = {
    val timestamp_cols_list = req_schema
      .fields
      .toList
      .filter(_.dataType == TimestampType)
      .map(_.name)

    val schema_json_str = req_schema.json
    val schema_col_struct = new StructType()
      .add("type", "string")
      .add("optional", BooleanType, true, "None")
      .add("fields"
        , createArrayType(
          createStructType(
            new StructType()
              .add("field", "string" )
              .add("type", "string")
              //.add("type", createArrayType(DataTypes.StringType))
              .add("optional", "boolean")
              .add("metadata","string")
              .add("name", "string", true)
              .fields
          )
        )
        , true
      )

    // send nulls
    var final_kafka_df = PipelineUtil.spark.emptyDataFrame
    if (send_null) {
      final_kafka_df = df
    } else {
      final_kafka_df = df.na.fill(0)
    }

    final_kafka_df
      .withColumn("schema_str",lit(schema_json_str))
      .withColumn("schema_str",regexp_replace($"schema_str","\"name\"","\"field\""))
      .withColumn("schema_str",regexp_replace($"schema_str","\"integer\"","\"int32\""))
      .withColumn("schema_str",regexp_replace($"schema_str","\"long\"","\"int64\""))
      .withColumn("schema_str"
        , regexp_replace($"schema_str"
          ,"\"timestamp\"","\"int64\",\"name\": \"org.apache.kafka.connect.data.Timestamp\""
        )
      )
      .withColumn("schema_str",regexp_replace($"schema_str","nullable","optional"))
      .withColumn("schema", from_json($"schema_str", schema_col_struct))
      .withColumn("payload"
        , struct(
          df.drop("topic", "topic_id")
          .columns
          .toList.map( c => if (timestamp_cols_list.contains(c)) (col(c).cast("long") * 1000).as(c) else col(c) ): _*
        )
      ).select(columns_to_select.map(col(_)):_*)
  }

  def setNullableStateForAllColumns( df_schema: StructType, nullable: Boolean) : StructType = {
    // get schema
    val schema = df_schema
    // modify [[StructField] with name `cn`
    val newSchema = StructType(schema.map {
      case StructField( c, t, _, m) ⇒ StructField( c, t, nullable = nullable, m)
    })
    // apply new schema
    newSchema
  }

  def createNotificationMessage(df: DataFrame, notification_str: String) : DataFrame = {
    val adatetime_epoch = System.currentTimeMillis() / 1000

   /* df.select($"topic_id").dropDuplicates("topic_id")
      .withColumnRenamed("topic_id","customer")*/

     df.select($"asset_code").dropDuplicates("asset_code")
       .filter(($"asset_code".isNotNull) && ($"asset_code" =!= "N/A"))
      .withColumn("customer", regexp_replace($"asset_code","[^A-Z]",""))
      .dropDuplicates("customer")
      .withColumn("notification",lit(s"$notification_str-stream"))
      .withColumn("datetime"
        ,to_timestamp(
          from_unixtime(lit(adatetime_epoch), "yyyy-MM-dd HH:mm:ss")
        )
      )
      .groupBy("notification").agg(
      collect_list("customer").as("customers")
      , first($"datetime", ignoreNulls = true) as "datetime"
    ).select($"notification" as "key"
      , to_json(
        struct(
          $"notification"
          , $"customers"
          , $"datetime"
        )
      ) as "value"
      , lit(pipelineConfig.getString("batch-run-notifications")) as "topic",
    )
  }

  def doPublishCuratedVehicleRecords(batchMessage: DataFrame, batchId: Long): Unit = {
    val gps_curr_schema =  ScalaReflection.schemaFor[DashBoardVehicleRecordCurrent].dataType.asInstanceOf[StructType]
    val AllMessage = batchMessage.persist(StorageLevel.MEMORY_AND_DISK)

    // HACK to publish data to customer topic. Remove in Future as all customer data should go to the same topic
    val data2cust = filterNUnionSubDataFrames(AllMessage
      , PipelineUtil.getEnvVariable("CUSTOMER_SLUGS","sensdev,staging,fedx,dske,wrnr,pnke")
        .split(",")
        .toList
    )

    try {
      val gpsDf = asKafkaConnectJsonMessage(selectNCastDataFrameAsSchema(AllMessage.union(data2cust),gps_curr_schema)
        , setNullableStateForAllColumns( gps_curr_schema, true)
        , Seq("service","device_id","schema","payload","topic", "topic_id").toList
        ,true
      )
        .select(concat_ws("-", $"service", $"device_id") as "key"
          , to_json(struct($"schema",$"payload")) as "value"
          , $"topic"
        )
        .union(
          createNotificationMessage(AllMessage, "gps-data")
        )

      PipelineUtil.writeDataFrameToKafka(gpsDf, "append", PipelineUtil.kafkaConfig)
        /*.write
        .format("kafka")
        .options(PipelineUtil.kafkaConfig)
        .save()*/
    } catch {
      case _ => val gpsDfE = asKafkaConnectJsonMessage(selectNCastDataFrameAsSchema(AllMessage.union(data2cust),gps_curr_schema)
        , gps_curr_schema
        , Seq("service","device_id","schema","payload","topic", "topic_id").toList
      )
        .withColumn("topic",regexp_replace($"topic",concat(lit($"topic_id"),lit("-")),lit("all-")))
        .select(concat_ws("-", $"service", $"device_id") as "key"
          , to_json(struct($"schema",$"payload")) as "value"
          , $"topic"
        )
        .union(
          createNotificationMessage(AllMessage, "gps-data")
        )

        PipelineUtil.writeDataFrameToKafka(gpsDfE, "append", PipelineUtil.kafkaConfig)
       /* .write
        .format("kafka")
        .options(PipelineUtil.kafkaConfig)
        .save()*/
    }

    AllMessage.unpersist()
  }

  /**
   * Publish TPMS data records to kafka ensuring the correct schema and datatype
   * @param batchMessage
   * @param batchId
   */
  def doPublishCuratedWheelRecords(batchMessage: DataFrame, batchId: Long): Unit = {
    val wheel_rec_schema =  ScalaReflection.schemaFor[DashBoardWheelRecord].dataType.asInstanceOf[StructType]
    val AllMessage = batchMessage.persist(StorageLevel.MEMORY_AND_DISK)

    // HACK to publish data to customer topic. Remove in Future as all customer data should go to the same topic
    val data2cust = filterNUnionSubDataFrames(AllMessage
      , PipelineUtil.getEnvVariable("CUSTOMER_SLUGS","sensdev,staging,fedx,dske,wrnr,pnke")
        .split(",")
        .toList
    )
    /*println("**********************************data2cust*******************************************")
    data2cust.show(false)*/

    try {
      asKafkaConnectJsonMessage(selectNCastDataFrameAsSchema(AllMessage.union(data2cust),wheel_rec_schema)
        , setNullableStateForAllColumns(wheel_rec_schema, true)
        , Seq("service", "device_id", "schema", "payload", "topic", "topic_id").toList
        , true
      )
        .select(concat_ws("-", $"service", $"device_id") as "key"
          , to_json(struct($"schema", $"payload")) as "value"
          , $"topic"
        )
        .union(
          createNotificationMessage(AllMessage, "wheel-data")
        )
        //.coalesce(3)
        .write
        .format("kafka")
        .options(PipelineUtil.kafkaConfig)
        .save()
    } catch {
      case _ => asKafkaConnectJsonMessage(selectNCastDataFrameAsSchema(AllMessage.union(data2cust),wheel_rec_schema)   // attempt to write whole batch to the all topic
        , wheel_rec_schema
        , Seq("service", "device_id", "schema", "payload", "topic","topic_id").toList
      )
        .withColumn("topic",regexp_replace($"topic",concat(lit($"topic_id"),lit("-")),lit("all-")))
        .select(concat_ws("-", $"service", $"device_id") as "key"
          , to_json(struct($"schema", $"payload")) as "value"
          , $"topic"
        )
        .union(
          createNotificationMessage(AllMessage, "wheel-data")
        )
        //.coalesce(3)
        /*println("**********************************wheelDfe*******************************************")
        PipelineUtil.writeDataFrameToKafka(wheelDfe, "append", PipelineUtil.kafkaConfig)*/
    //  )
      .write
        .format("kafka")
        .options(PipelineUtil.kafkaConfig)
        .save()
    }

    AllMessage.unpersist()
  }

  def doPublishCuratedWheelAlertRecords(batchMessage: DataFrame, batchId: Long): Unit = {
    val alert_rec_schema =  ScalaReflection.schemaFor[DashBoardWheelAlertRecord].dataType.asInstanceOf[StructType]
    val AllMessage = batchMessage.persist(StorageLevel.MEMORY_AND_DISK)

    // HACK to publish data to customer topic. Remove in Future as all customer data should go to the same topic
    val data2cust = filterNUnionSubDataFrames(AllMessage
      , PipelineUtil.getEnvVariable("CUSTOMER_SLUGS","sensdev,staging,fedx,dske,wrnr,pnke")
        .split(",")
        .toList
    )

    try {
      asKafkaConnectJsonMessage(selectNCastDataFrameAsSchema(AllMessage.union(data2cust),alert_rec_schema)
        , setNullableStateForAllColumns(alert_rec_schema, true)
        , Seq("service", "device_id", "schema", "payload", "topic", "topic_id").toList
        , true
      )
        .select(concat_ws("-", $"service", $"device_id") as "key"
          , to_json(struct($"schema", $"payload")) as "value"
          , $"topic"
        )
        .union(
          createNotificationMessage(AllMessage, "wheel-alert-data")
        )
        //.coalesce(3)
        .write
        .format("kafka")
        .options(PipelineUtil.kafkaConfig)
        .save()
    } catch {
      case _ =>  asKafkaConnectJsonMessage(selectNCastDataFrameAsSchema(AllMessage.union(data2cust),alert_rec_schema)
        , alert_rec_schema
        , Seq("service", "device_id", "schema", "payload", "topic", "topic_id").toList
      )
        .withColumn("topic",regexp_replace($"topic",concat(lit($"topic_id"),lit("-")),lit("all-")))
        .select(concat_ws("-", $"service", $"device_id") as "key"
          , to_json(struct($"schema", $"payload")) as "value"
          , $"topic"
        )
        .union(
          createNotificationMessage(AllMessage, "wheel-alert-data")
        )
        //.coalesce(3)
        .write
        .format("kafka")
        .options(PipelineUtil.kafkaConfig)
        .save()
    }

    AllMessage.unpersist()
  }

  /**
   * CustomerDataPuyblisher: Spark Streaming query responsible for publishing the final curated data to the connectors for
   * entry into the external data sources (PostgresSQL)
   */
  def doCustomerDatabasePush(): Unit = {

    val position_data_scheam = ScalaReflection.schemaFor[ProcessedGPSRecord].dataType.asInstanceOf[StructType]
    val wheel_data_scheam = ScalaReflection.schemaFor[ProcessedWheelRecord].dataType.asInstanceOf[StructType]
    val alert_data_scheam = ScalaReflection.schemaFor[ProcessedWheelWarningRecord].dataType.asInstanceOf[StructType]

    // get GPS messages
    val gpsMessgaes = PipelineUtil.spark.readStream
      .format("kafka")
      .options(PipelineUtil.kafkaConfig)
      //.option("groupIdPrefix", pipelineConfig.getString("consumer_group"))
      .option("subscribe",pipelineConfig.getString("curated_gps_records_topic"))
      .load()
      .where($"value" cast "string" rlike (".*\"service\":\"gnss-curated\".*"))
      .where($"value" cast "string" rlike (".*\"consumed_timestamp\":.*"))
      .select(
        from_json($"value" cast "string"
          , position_data_scheam
        ) as "events"
      ).select($"events.*")
    .na.fill(
      Map(
        "service" -> "N/A",
        "reported_time" -> "N/A",
        "schema_version" -> "N/A",
        "device_id" -> "N/A",
        "device_name" -> "N/A",
        "wheel_config" -> "N/A",
        "no_axles" -> "N/A",
      )
    )
      .as[ProcessedGPSRecord]


    // get warning alerts messages
    val alertMessgaes = PipelineUtil.spark.readStream
      .format("kafka")
      .options(PipelineUtil.kafkaConfig)
      //.option("groupIdPrefix", pipelineConfig.getString("consumer_group"))
      .option("subscribe",pipelineConfig.getString("curated_alerts_topic"))
      .load()
      .where($"value" cast "string" rlike (".*\"service\":\"alerts-curated\".*"))
      .where($"value" cast "string" rlike (".*\"device_id\":.*"))
      .where($"value" cast "string" rlike (".*\"alert_name\":.*"))
      .select(
        from_json($"value" cast "string"
          , alert_data_scheam
        ) as "events"
      ).select($"events.*")
      .withColumn("active"
        ,when($"active" isNull , 0).otherwise($"active")
      )
      //.where($"active" === 1) // filter out off messages from the database topics
      .na.fill(
      Map(
        "service" -> "N/A",
        "reported_time" -> "N/A",
        "schema_version" -> "N/A",
        "resource" -> "N/A",
        "location" -> "N/A",
        "location_name" -> "N/A",
        "device_name" -> "N/A",
        "wheel_config" -> "N/A",
        "no_axles" -> "N/A",
        "wheel_key" -> "N/A",
        "vehicle_key" -> "N/A",
        "asset_wheel_config_key" -> "N/A"
      )
    )
      .as[ProcessedWheelWarningRecord]


    val wheelMessages = PipelineUtil.spark.readStream
      .format("kafka")
      .options(PipelineUtil.kafkaConfig)
      //.option("groupIdPrefix", pipelineConfig.getString("consumer_group"))
      .option("subscribe",pipelineConfig.getString("curated_wheel_records_topic"))
      .load()
      .where($"value" cast "string" rlike (".*\"service\":\"tpms-curated\".*"))
      .where($"value" cast "string" rlike (".*\"location\":.*"))
      .where($"value" cast "string" rlike (".*\"device_id\":.*"))
      .where(
        ($"value" cast "string" rlike (".*\"battery_status\":.*"))
        || ($"value" cast "string" rlike (".*\"measured_pressure\":.*"))
        || ($"value" cast "string" rlike (".*\"measured_temperature\":.*"))
        )
      .where($"value" cast "string" rlike (".*\"consumed_timestamp\":.*"))
      .select(
        from_json($"value" cast "string"
          , wheel_data_scheam
        ) as "events"
      )
      .select($"events.*")
      .where( // only send records with temperature and pressure and battery to the database
        ($"measured_pressure" isNotNull) &&
          ($"measured_temperature" isNotNull) &&
          ($"battery_status" isNotNull)
      )
      .na.fill(
      Map(
        "service" -> "N/A",
          "reported_time" -> "N/A",
          "schema_version" -> "N/A",
          "location" -> "N/A",
          "location_name" -> "N/A",
          "device_id" -> "N/A",
          "device_name" -> "N/A",
          "wheel_config" -> "N/A",
          "no_axles" -> "N/A",
          "low_pressure_value" -> 0,
          "extra_low_pressure_value" -> 0,
          "normal_pressure_value" -> 0,
          "low_temperature_value" -> 0,
          "extra_low_temperature_value" -> 0,
          "normal_temperature_value" -> 0,
          "wheel_key" -> "N/A",
          "vehicle_key" -> "N/A",
          "asset_wheel_config_key" -> "N/A",
          "last_updated" -> "N/A",
      )
    )
      .as[ProcessedWheelRecord]

    // publish wheel data
    wheelMessages.toDF()
      //.coalesce(3)
      .writeStream
      .trigger(Trigger.ProcessingTime(PipelineUtil.processing_trigger_time))
      .foreachBatch(doPublishCuratedWheelRecords _)
      .queryName("Realtime Wheel TPMS Stream")
      .start()

    // publish GPS/Vehicle data
    gpsMessgaes.toDF()
      //.coalesce(3)
      .writeStream
      .trigger(Trigger.ProcessingTime(PipelineUtil.processing_trigger_time))
      .foreachBatch(doPublishCuratedVehicleRecords _)
      .queryName("Realtime Vehicle GPS Stream")
      .start()

    // publish GPS/Vehicle data
    alertMessgaes.toDF()
      //.coalesce(3)
      .writeStream
      .trigger(Trigger.ProcessingTime(PipelineUtil.processing_trigger_time))
      .foreachBatch(doPublishCuratedWheelAlertRecords _)
      .queryName("Realtime Wheel TPMS Alert Stream")
      .start()


  }
}
