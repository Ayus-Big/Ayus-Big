package com.sensata.data_office.pipeline.queries

import com.sensata.data_office.data.{GenericEvent, GenericEventData, MessageTypes}
import com.sensata.data_office.utilities.PipelineUtil
import com.typesafe.config.ConfigFactory
import com.typesafe.scalalogging.Logger
import org.apache.spark.sql.catalyst.ScalaReflection
import org.apache.spark.sql.functions.{to_timestamp, _}
import org.apache.spark.sql.streaming.Trigger
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.{DataFrame, Dataset, Row}
import org.slf4j.LoggerFactory
import org.joda.time.{DateTime, DateTimeZone}
import org.joda.time.format.DateTimeFormat

import scala.collection.JavaConverters._

object RawEventsAzureBlobSink {

  val pipelineConfig = ConfigFactory
    .load(s"application.${sys.env("ENVIRONMENT")}.conf")
    .getConfig("RawEventsProcessor").getConfig("pipeline")

  val VERSION = pipelineConfig.getString("version")

  def doWritetoAzureBlobStore() {

    //val partition_timestamp =  new DateTime(System.currentTimeMillis() / 1000).toDateTime.toString("yyyy-MM-ddHH")

    PipelineUtil.spark.readStream
        .format("kafka")
        .option("subscribe", pipelineConfig.getString("source_stream_topic"))
        .options(PipelineUtil.kafkaConfig)
        .option("failOnDataLoss", "false")
        .load()
        //.withColumn("timestamp", (lit(System.currentTimeMillis())) cast "long")
        .withColumn("consumed_timestamp" ,
          to_timestamp(
            from_unixtime(unix_timestamp(), pipelineConfig.getString("received_timestamp_format"))
          ).cast("long")
        ).withColumn("consumed_date_hour" ,
          from_unixtime(unix_timestamp(), "yyyy-MM-ddHH0000")
        )
        .writeStream
        .partitionBy("consumed_date_hour")
        .outputMode("append")
        .format("parquet")
        //.option("checkpointLocation", pipelineConfig.getString("raw_json_checkpoint_location"))
        .trigger(Trigger.ProcessingTime(pipelineConfig.getString("processing_trigger")))
        .queryName("Azure Blob Storage Sink")
        .start(pipelineConfig.getString("blob_data_path"))
  }
}
