package com.sensata.data_office.pipeline.queries

import com.sensata.data_office.data.{ActiveAlertNotification, AssetActivityNotification, ProcessedAlertSnapshot, ProcessedGPSRecord, ProcessedWheelRecord, ProcessedWheelWarningRecord}
import com.sensata.data_office.utilities.PipelineUtil
import com.sensata.data_office.utilities.PipelineUtil.getEnvVariable
import com.typesafe.config.ConfigFactory
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.catalyst.ScalaReflection
import org.apache.spark.sql.functions.{concat_ws, from_json, lit, when}
import org.apache.spark.sql.streaming.Trigger
import org.apache.spark.sql.types.StructType
import org.apache.spark.storage.StorageLevel

/**
 *
 */
object LakeDataLoader {

  val appConfig = ConfigFactory.load(s"application.${getEnvVariable("ENVIRONMENT")}.conf").getConfig("LakeDataLoader")
  val sparkCfg = ConfigFactory.load(s"application.${getEnvVariable("ENVIRONMENT")}.conf").getConfig("LakeDataLoader").getConfig("spark")
  val pipelineConfig = appConfig.getConfig("pipeline")


  val VERSION = pipelineConfig.getString("version")

  import PipelineUtil.spark.implicits._

  def processGPSMessagesByBatch(batchMessage: DataFrame, batchId: Long): Unit = {

    val AllMessage = batchMessage.persist(StorageLevel.MEMORY_AND_DISK)

    val position_data_scheam = ScalaReflection.schemaFor[ProcessedGPSRecord].dataType.asInstanceOf[StructType]
    val gnssdf = AllMessage
      .where($"value" cast "string" rlike (".*\"service\":\"gnss-curated\".*") )
      .where($"value" cast "string" rlike (".*\"consumed_timestamp\":.*") )
      .select(
        from_json($"value" cast "string"
          , position_data_scheam
        ) as "events"
      ).select($"events.*")
      .withColumn("no_axles", when($"no_axles" isNull
        , "N/A").otherwise($"no_axles")
      ).withColumn("wheel_config", when($"wheel_config" isNull
      , "N/A").otherwise($"wheel_config")
    )
      .withColumn("asset_id",$"asset_id")
      .withColumn("asset_code",$"asset_code")
      .as[ProcessedGPSRecord]
      .repartition(10)
      .toDF()

      PipelineUtil.writeDataFrameToBlobStorage(gnssdf,"append",pipelineConfig.getString("dest_data_path") + "gps")

    AllMessage.unpersist()
  }

  def processAlertSnapShotMessagesByBatch(batchMessage: DataFrame, batchId: Long): Unit = {
    val AllMessage = batchMessage.persist(StorageLevel.MEMORY_AND_DISK)

    val alert_data_scheam = ScalaReflection.schemaFor[ProcessedAlertSnapshot].dataType.asInstanceOf[StructType]
    val alertSnapDf = AllMessage
      .where($"value" cast "string" rlike (".*\"service\":\"analytics\".*") )
      .where($"value" cast "string" rlike (".*\"device_id\":.*") )
      .select(
        from_json($"value" cast "string"
          , alert_data_scheam
        ) as "events"
      ).select($"events.*")
      .withColumn("topic_id", when(($"topic_id" isNull) || ($"topic_id" === "N/A")
        , lit("all")).otherwise($"topic_id")
      )
      .withColumn("topic", concat_ws("-", $"topic_id", lit("wheel-alert-snapshot-current")))
      .as[ProcessedAlertSnapshot]
      .repartition(10)
      .toDF()

    PipelineUtil.writeDataFrameToBlobStorage(alertSnapDf,"append",pipelineConfig.getString("dest_data_path") + "wheel_alert_snapshots")


    AllMessage.unpersist()
  }

  def processAlertsMessagesByBatch(batchMessage: DataFrame, batchId: Long): Unit = {

    val AllMessage = batchMessage.persist(StorageLevel.MEMORY_AND_DISK)

    val alert_data_scheam = ScalaReflection.schemaFor[ProcessedWheelWarningRecord].dataType.asInstanceOf[StructType]
    val alertMsgDf = AllMessage
      .where($"value" cast "string" rlike (".*\"service\":\"alerts-curated\".*") )
      .where($"value" cast "string" rlike (".*\"device_id\":.*") )
      .where($"value" cast "string" rlike (".*\"alert_name\":.*") )
      .select(
        from_json($"value" cast "string"
          , alert_data_scheam
        ) as "events"
      ).select($"events.*")
      .withColumn("topic_id", when(($"topic_id" isNull) || ($"topic_id" === "N/A")
        , lit("all")).otherwise($"topic_id")
      )
      .withColumn("topic", concat_ws("-", $"topic_id", lit("wheel-alert-current")))
      .withColumn("no_axles", when($"no_axles" isNull
        , "N/A").otherwise($"no_axles")
      ).withColumn("wheel_config", when($"wheel_config" isNull
      , "N/A").otherwise($"wheel_config")
    ).withColumn("location_name", when($"location_name" isNull
      , "$location").otherwise($"location_name")
    )
      .withColumn("asset_id",$"asset_id")
      .withColumn("asset_code",$"asset_code")
      .as[ProcessedWheelWarningRecord]
      .repartition(10)
      .toDF()

    PipelineUtil.writeDataFrameToBlobStorage(alertMsgDf,"append",pipelineConfig.getString("dest_data_path") + "wheel_alerts")


    AllMessage.unpersist()
  }

  def processActiveAlertMessagesByBatch(batchMessage: DataFrame, batchId: Long): Unit = {

    val AllMessage = batchMessage.persist(StorageLevel.MEMORY_AND_DISK)

    val active_alert_data_schema = ScalaReflection.schemaFor[ActiveAlertNotification].dataType.asInstanceOf[StructType]
    val active_alert_Df = AllMessage.select(
      from_json($"value" cast "string"
        , active_alert_data_schema
      ) as "events"
    )
      .select($"events.*")

      .repartition(10)
      .toDF()

    PipelineUtil.writeDataFrameToBlobStorageUnPartitioned(active_alert_Df,"overwrite",
      pipelineConfig.getString("active_cache_path") + "active_alerts")

    AllMessage.unpersist()
  }

  def processAssetActivityMessagesByBatch(batchMessage: DataFrame, batchId: Long): Unit = {

    val AllMessage = batchMessage.persist(StorageLevel.MEMORY_AND_DISK)

    val asset_activity_data_schema = ScalaReflection.schemaFor[AssetActivityNotification].dataType.asInstanceOf[StructType]
    val asset_activity_Df = AllMessage.select(
        from_json($"value" cast "string"
          , asset_activity_data_schema
        ) as "events"
      )
      .select($"events.*")

      .repartition(10)
      .toDF()

    PipelineUtil.writeDataFrameToBlobStorageUnPartitioned(asset_activity_Df,"overwrite",
      pipelineConfig.getString("active_cache_path") + "asset_activity")

    AllMessage.unpersist()
  }

  def processWheelsMessagesByBatch(batchMessage: DataFrame, batchId: Long): Unit = {

    val AllMessage = batchMessage.persist(StorageLevel.MEMORY_AND_DISK)

    val wheel_data_scheam = ScalaReflection.schemaFor[ProcessedWheelRecord].dataType.asInstanceOf[StructType]
    val wheelDf = AllMessage
      .where($"value" cast "string" rlike (".*\"service\":\"tpms-curated\".*") )
      .where($"value" cast "string" rlike (".*\"location\":.*") )
      .where($"value" cast "string" rlike (".*\"device_id\":.*") )
      .where($"value" cast "string" rlike (".*\"battery_status\":.*") )
      .where($"value" cast "string" rlike (".*\"measured_pressure\":.*") )
      .where($"value" cast "string" rlike (".*\"measured_temperature\":.*") )
      .where($"value" cast "string" rlike (".*\"consumed_timestamp\":.*") )
      .select(
        from_json($"value" cast "string"
          , wheel_data_scheam
        ) as "events"
      )
      .select($"events.*")
      .withColumn("topic_id", when(($"topic_id" isNull) || ($"topic_id" === "N/A")
        , lit("all")).otherwise($"topic_id")
      )
      .withColumn("topic", concat_ws("-", $"topic_id", lit("wheel-data-current")))
      .withColumn("no_axles", when($"no_axles" isNull
        , "N/A").otherwise($"no_axles")
      ).withColumn("wheel_config", when($"wheel_config" isNull
      , "N/A").otherwise($"wheel_config")
    ).withColumn("location_name", when($"location_name" isNull
      , $"location").otherwise($"location_name")
    )
      .withColumn("asset_id",$"asset_id")
      .withColumn("asset_code",$"asset_code")
      .as[ProcessedWheelRecord]
      .repartition(10)
      .toDF()

   PipelineUtil.writeDataFrameToBlobStorage(wheelDf,"append",pipelineConfig.getString("dest_data_path") + "wheels")

    AllMessage.unpersist()
  }


  def doDataLakeLoader(): Unit = {

    // get GPS messages
    val gpsMessgaes = PipelineUtil.spark.readStream
      .format("kafka")
      .options(PipelineUtil.kafkaConfig)
      //.option("groupIdPrefix", pipelineConfig.getString("consumer_group"))
      .option("subscribe",pipelineConfig.getString("curated_gps_records_topic"))
      .load()

     gpsMessgaes
      .writeStream
      .trigger(Trigger.ProcessingTime(PipelineUtil.data_lake_processing_trigger))
      //.option("checkpointLocation", pipelineConfig.getString("wheels_checkpoint_location"))
      .foreachBatch(processGPSMessagesByBatch _)
      .queryName("DataLake Vehicle GPS Stream")
      .start()


    // get warning alerts messages
    val alertMessgaes = PipelineUtil.spark.readStream
      .format("kafka")
      .options(PipelineUtil.kafkaConfig)
      //.option("groupIdPrefix", pipelineConfig.getString("consumer_group"))
      .option("subscribe",pipelineConfig.getString("curated_alerts_topic"))
      .load()

    // persist alert information
    alertMessgaes
      .writeStream
      .trigger(Trigger.ProcessingTime(PipelineUtil.data_lake_processing_trigger))
      //.option("checkpointLocation", pipelineConfig.getString("wheels_checkpoint_location"))
      .foreachBatch(processAlertsMessagesByBatch _)
      .queryName("DataLake Wheel TPMS Alert Stream")
      .start()

    // get snapshot alert messages
    val alertSnapShotMessgaes = PipelineUtil.spark.readStream
      .format("kafka")
      .options(PipelineUtil.kafkaConfig)
      //.option("groupIdPrefix", pipelineConfig.getString("consumer_group"))
      .option("subscribe",pipelineConfig.getString("curated_analytics_topic"))
      .load()

    alertSnapShotMessgaes
      .writeStream
      .trigger(Trigger.ProcessingTime(PipelineUtil.data_lake_processing_trigger))
      .foreachBatch(processAlertSnapShotMessagesByBatch _)
      .queryName("DataLake Wheel Alert Snaphot Stream")
      .start()



    //get wheel message
    val wheelMessgaes = PipelineUtil.spark.readStream
      .format("kafka")
      .options(PipelineUtil.kafkaConfig)
      //.option("groupIdPrefix", pipelineConfig.getString("consumer_group"))
      .option("subscribe",pipelineConfig.getString("curated_wheel_records_topic"))
      .load()

    // persist wheel information
    wheelMessgaes
      .writeStream
      .trigger(Trigger.ProcessingTime(PipelineUtil.data_lake_processing_trigger))
      //.option("checkpointLocation", pipelineConfig.getString("wheels_checkpoint_location"))
      .foreachBatch(processWheelsMessagesByBatch _)
      .queryName("DataLake Wheel TPMS Stream")
      .start()

    //get active alerts message
    val alertActiveMessgaes = PipelineUtil.spark.readStream
      .format("kafka")
      .options(PipelineUtil.kafkaConfig)
      //.option("groupIdPrefix", pipelineConfig.getString("consumer_group"))
      .option("subscribe",pipelineConfig.getString("alerts_notification_topic"))
      .load()

    // persist active alerts information
    alertActiveMessgaes
      .writeStream
      .trigger(Trigger.ProcessingTime(PipelineUtil.data_lake_processing_trigger))
      //.option("checkpointLocation", pipelineConfig.getString("wheels_checkpoint_location"))
      .foreachBatch(processActiveAlertMessagesByBatch _)
      .queryName("DataLake Live Alerts Cache")
      .start()

    //get activity message
    val activityMessgaes = PipelineUtil.spark.readStream
      .format("kafka")
      .options(PipelineUtil.kafkaConfig)
      //.option("groupIdPrefix", pipelineConfig.getString("consumer_group"))
      .option("subscribe",pipelineConfig.getString("asset_activity_topic"))
      .load()

    // persist activity information
    activityMessgaes
      .writeStream
      .trigger(Trigger.ProcessingTime(PipelineUtil.data_lake_processing_trigger))
      //.option("checkpointLocation", pipelineConfig.getString("wheels_checkpoint_location"))
      .foreachBatch(processAssetActivityMessagesByBatch _)
      .queryName("DataLake Asset Activity Cache")
      .start()

  }
}
