package com.sensata.data_office.batch

import java.sql.Timestamp
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Properties

import com.sensata.data_office.batch.jobs.OptimiseBlobStorage
import com.typesafe.config.ConfigFactory
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.slf4j.LoggerFactory

import scala.collection.JavaConverters._

object OptimisationDataPipeline {

  val appConfig = ConfigFactory.load(s"application.${sys.env("ENVIRONMENT")}.conf").getConfig("DashBoardDataLoader")
  val dbConfig = ConfigFactory.load(s"application.${sys.env("ENVIRONMENT")}.conf").getConfig("jdbcDataLoader")
  val pipelineConfig = appConfig.getConfig("pipeline")

  val num_partitions = pipelineConfig.getInt("num_partitions")

  val default_assumed_speed_mph = pipelineConfig.getInt("default_assumed_speed_mph")

  val postgresdb_cfg = new Properties()
  dbConfig.getConfig("postgresdb").getConfig("properties").entrySet().forEach(k => {
    postgresdb_cfg.put(k.getKey, k.getValue unwrapped)
  })

  val late_record_threshold_sec = ConfigFactory
    .load(s"application.${sys.env("ENVIRONMENT")}.conf").getConfig("high_watermark").getInt("late_record_threshold_sec")

  val sparkCfgObj = new SparkConf()

  val sparkCfg = ConfigFactory.load(s"application.${sys.env("ENVIRONMENT")}.conf").getConfig("spark")
  sparkCfg.getConfig("config").root().asScala.map(
    v => sparkCfgObj.set( String.valueOf(v._1),String.valueOf(v._2.unwrapped()) )
  )

  val spark = SparkSession
    .builder
    .appName(pipelineConfig.getString("application_name"))
    .config(sparkCfgObj)
    .getOrCreate()


  val appLogger = LoggerFactory.getLogger("spark")



  def main(args: Array[String]): Unit = {

    // run batch job
    val do_delete = if (args.length > 0 && args(0).toInt == 1) true else false
    val num_of_folders = if (args.length > 1 && args(1).toInt > 0) args(1).toInt else 50
    appLogger.info(s"Arguments are : ${args.map(_.toString).mkString(",")}")

    // run optimisation job for processed streaming files
    OptimiseBlobStorage.doSmallFilesOptimisation(num_of_folders,do_delete)

  }

}