package com.sensata.data_office.batch.jobs

import java.time.format.DateTimeFormatter

import com.databricks.dbutils_v1.DBUtilsHolder.dbutils
import com.sensata.data_office.batch.DashBoardDataPipeline.{pipelineConfig, spark}
import com.sensata.data_office.data.{ProcessedAlertSnapshot, ProcessedGPSRecord, ProcessedWheelRecord, ProcessedWheelWarningRecord}
import org.apache.spark.sql.catalyst.ScalaReflection
import org.apache.spark.sql.functions.desc
import org.apache.spark.sql.types.StructType
import org.apache.spark.storage.StorageLevel
import org.joda.time.format.DateTimeFormat

import scala.collection.JavaConverters._

object StorageRetensionManager {

  import spark.implicits._


}
