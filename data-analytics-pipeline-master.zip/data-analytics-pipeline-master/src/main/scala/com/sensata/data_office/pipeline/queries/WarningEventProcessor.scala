package com.sensata.data_office.pipeline.queries

import com.sensata.data_office.data._
import com.sensata.data_office.utilities.Analytics.{flattenAnalyticalMessage, setAlertId, setAlertNameValue, setCategoryValue}
import com.sensata.data_office.utilities.PipelineUtil
import com.sensata.data_office.utilities.PipelineUtil.dedupToLatest
import com.typesafe.config.ConfigFactory
import org.apache.spark.sql.catalyst.ScalaReflection
import org.apache.spark.sql.functions.{when, _}
import org.apache.spark.sql.streaming.Trigger
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.{DataFrame, Dataset}
import org.apache.spark.storage.StorageLevel


object WarningEventProcessor {


  val pipelineConfig = ConfigFactory
    .load(s"application.${PipelineUtil.getEnvVariable("ENVIRONMENT")}.conf")
    .getConfig("EventProcessors").getConfig("pipeline")

  val dimentionalCfg = ConfigFactory
    .load(s"application.${PipelineUtil.getEnvVariable("ENVIRONMENT")}.conf")
    .getConfig("dimensional_data")

  val VERSION = pipelineConfig.getString("version")

  val watermark_column = ConfigFactory
    .load(s"application.${PipelineUtil.getEnvVariable("ENVIRONMENT")}.conf").getConfig("high_watermark").getString("watermark_column")
  val watermark_delay_threashold = ConfigFactory
    .load(s"application.${PipelineUtil.getEnvVariable("ENVIRONMENT")}.conf").getConfig("high_watermark").getString("watermark_delay_threashold")
  val late_record_threshold_sec = ConfigFactory
    .load(s"application.${PipelineUtil.getEnvVariable("ENVIRONMENT")}.conf").getConfig("high_watermark").getString("late_record_threshold_sec")

  import PipelineUtil.spark.implicits._

  def processWheelBatch(WheelbatchDF: DataFrame, odometerDF: DataFrame, analytic_msg: DataFrame, wheel_tmps_msg: DataFrame, customer_data:DataFrame): Dataset[ProcessedWheelWarningRecord] = {

    val prevActiveAlerts = PipelineUtil.getAssetAlertStateFromDatabaseCache()


    val wheelMessage = WheelbatchDF

    val slowPressureAlert = addTimeStampColumns(wheelMessage
      .where((get_json_object($"value" cast "string", "$.resource") === MessageTypes.WarningEventPressure))
      .select(
        from_json($"value" cast "string"
          , ScalaReflection.schemaFor[WarningEventPressure].dataType.asInstanceOf[StructType]
          ) as "events"
      ).select($"events.*")
    )

  /*  println("************************************slowPressureAlert*****************************************")
    slowPressureAlert.show(false)*/

    val slowPressureAlertv2 = addTimeStampColumns(wheelMessage
      .where((get_json_object($"value" cast "string", "$.resource") === MessageTypes.WheelWarningPressureV2))
      .select(
        from_json($"value" cast "string"
          , ScalaReflection.schemaFor[WheelWarningPressureV2].dataType.asInstanceOf[StructType]
        ) as "events"
      ).select($"events.*")
    )

    val fastPressureAlert = addTimeStampColumns(wheelMessage
      .where(get_json_object($"value" cast "string", "$.resource") === MessageTypes.WarningEventFastPressureLoss)
      .select(
        from_json($"value" cast "string"
          , ScalaReflection.schemaFor[WarningEventFastPressureLoss].dataType.asInstanceOf[StructType]
        ) as "events"
      ).select($"events.*")
    )

   /* println("************************************fastPressureAlert*****************************************")
    fastPressureAlert.show(false)
*/
    val fastPressureAlertv2 = addTimeStampColumns(wheelMessage
      .where(get_json_object($"value" cast "string", "$.resource") === MessageTypes.WheelWarningDynamic)
      .select(
        from_json($"value" cast "string"
          , ScalaReflection.schemaFor[WheelWarningDynamic].dataType.asInstanceOf[StructType]
        ) as "events"
      ).select($"events.*")
    )

    /*println("************************************fastPressureAlertv2*****************************************")
    fastPressureAlertv2.show(false)*/

    val typeBurstAlert = addTimeStampColumns(wheelMessage
      .where(get_json_object($"value" cast "string", "$.resource") === MessageTypes.WarningEventTyreBurst)
      .select(
        from_json($"value" cast "string"
          , ScalaReflection.schemaFor[WarningEventTyreBurst].dataType.asInstanceOf[StructType]
        ) as "events"
      ).select($"events.*")
    )

    /*println("************************************typeBurstAlert*****************************************")
    typeBurstAlert.show(false)*/

    val typeBatteryAlert = addTimeStampColumns(wheelMessage
      .where(get_json_object($"value" cast "string", "$.resource") === MessageTypes.WheelWarningBattery)
      .select(
        from_json($"value" cast "string"
          , ScalaReflection.schemaFor[WheelWarningBattery].dataType.asInstanceOf[StructType]
        ) as "events"
      ).select($"events.*")
    )

    /*println("************************************typeBatteryAlert*****************************************")
    typeBatteryAlert.show(false)*/

    val temperatureAlert = addTimeStampColumns(wheelMessage
      .where(get_json_object($"value" cast "string", "$.resource") === MessageTypes.WheelWarningTemperature)
      .select(
        from_json($"value" cast "string"
          , ScalaReflection.schemaFor[WheelWarningTemperature].dataType.asInstanceOf[StructType]
        ) as "events"
      ).select($"events.*")
    )

   /* println("************************************temperatureAlert*****************************************")
    temperatureAlert.show(false)*/

    val temperatureAlertv2 = addTimeStampColumns(wheelMessage
      .where(get_json_object($"value" cast "string", "$.resource") === MessageTypes.WheelWarningTemperatureV2)
      .select(
        from_json($"value" cast "string"
          , ScalaReflection.schemaFor[WheelWarningTemperatureV2].dataType.asInstanceOf[StructType]
        ) as "events"
      ).select($"events.*")
    )
/*
    println("************************************temperatureAlertv2*****************************************")
    temperatureAlertv2.show(false)*/

    val tyreLockAlert = addTimeStampColumns(wheelMessage
      .where(get_json_object($"value" cast "string", "$.resource") === MessageTypes.WarningEventTyreLock)
      .select(
        from_json($"value" cast "string"
          , ScalaReflection.schemaFor[WarningEventTyreLock].dataType.asInstanceOf[StructType]
        ) as "events"
      ).select($"events.*")
    )

   /* println("************************************tyreLockAlert*****************************************")
    tyreLockAlert.show(false)*/

    val tyreLockAlertv2 = addTimeStampColumns(wheelMessage
      .where(get_json_object($"value" cast "string", "$.resource") === MessageTypes.WheelWarningTyreLock)
      .select(
        from_json($"value" cast "string"
          , ScalaReflection.schemaFor[WheelWarningTyreLock].dataType.asInstanceOf[StructType]
        ) as "events"
      ).select($"events.*")
    )

   /* println("************************************tyreLockAlertV2*****************************************")
    tyreLockAlertv2.show(false)*/

    val missingsensorv2 = addTimeStampColumns(wheelMessage
      .where(get_json_object($"value" cast "string", "$.resource") === MessageTypes.WheelMissingSensor)
      .select(
        from_json($"value" cast "string"
          , ScalaReflection.schemaFor[WheelMissingSensor].dataType.asInstanceOf[StructType]
        ) as "events"
      ).select($"events.*")
    )

     /*println("************************************missingsensorv2*****************************************")
     missingsensorv2.show(false)*/


    // merge the wheel alert streams to get a flat table DATA PLANE 1.0
    val wheeAlerts_combind = slowPressureAlert
      .union(fastPressureAlert)
      .union(typeBurstAlert)
      .union(temperatureAlert)
      .union(tyreLockAlert)
      .select(
        concat_ws("-", lit("alerts"), lit("curated")) as "service"
        , $"deviceId" as "device_id"
        , $"customer" as "device_name"
        , $"time" cast "timestamp" as "reported_time"
        , $"data.location" cast "string" as "location"
        , $"version" as "schema_version"
        , $"resource" as "resource"
        , $"timestamp" cast "timestamp" as "pipeline_timestamp"
        , $"consumed_timestamp" cast "long" as "consumed_timestamp"
        , element_at($"data.event", "active") as "active"
        , element_at($"data.event", "duration") cast "int" as "duration"
        , element_at($"data.event", "previous_active_duration") cast "int" as "previous_active_duration"
        , $"data.category" cast "int" as "category"

      )
      .withColumn("active"
        , when(($"active" === lit("1")) || ($"active" === lit("true")) && ($"category" isNotNull)
          , lit(1)
        ).otherwise(lit(0)).cast("int")
      )
      .withColumn("category"
        , when($"category" isNull , lit(99)).otherwise($"category")
      )
      .withColumn("alert_name"
        , setAlertNameValue()
      )

    /*println("************************************wheeAlerts_combind*****************************************")
    wheeAlerts_combind.show(false)*/

    // merge the wheel alert streams to get a flat table for DATA PLANE 2.0
    val wheeAlerts_combined_v2 = slowPressureAlertv2
      .union(fastPressureAlertv2)
      .union(typeBatteryAlert)
      .union(temperatureAlertv2)
      .union(tyreLockAlertv2)
      .union(missingsensorv2)
      .select(
        concat_ws("-", lit("alerts"), lit("curated")) as "service"
        , $"deviceId" as "device_id"
        , $"customer" as "device_name"
        , $"time" cast "timestamp" as "reported_time"
        , $"data.location" cast "string" as "location"
        , $"version" as "schema_version"
        , $"resource" as "resource"
        , $"timestamp" cast "timestamp" as "pipeline_timestamp"
        , $"consumed_timestamp" cast "long" as "consumed_timestamp"
        , $"data.value" as "value"

      )
      .withColumn("active"
        , when($"value" === "false" || $"value" === 0 || $"value" === "null", lit(0))
            .otherwise(lit(1).cast("int")
           )
      )
      .withColumn("duration", lit(0).cast("long"))
      .withColumn("previous_active_duration", lit(0))
      .withColumn("category", setCategoryValue)
      .withColumn("alert_name" , setAlertNameValue)
      .drop("value")

    /*println("************************************wheeAlerts_combined_v2*****************************************")
    wheeAlerts_combined_v2.show(false)*/


    val wheeAlerts_combind_final = wheeAlerts_combind.union(wheeAlerts_combined_v2)
      .withColumn("active",when($"active" === 1 && $"category" === 99, 0).otherwise($"active"))
      .withColumn("alert_id",setAlertId())

    /*println("************************************wheeAlerts_combind_final*****************************************")
    wheeAlerts_combind_final.show(false)*/


    val wheeAlerts = wheeAlerts_combind_final
      .join(
        customer_data
        , Seq("device_id")
        , "left"
      )
      .drop("reported_device_id")
      .withColumn("company", $"company_name")
      .withColumn("fleet", $"fleet_name")
      .withColumn("asset_name", $"company_asset_name")
      .withColumn("wheel_config", $"v_wheel_config")
      .withColumn("no_axles", $"v_no_axles")
      .withColumn("asset_id", $"v_asset_id")
      .withColumn("asset_code", $"v_asset_code")
      .withColumn("image_url", $"v_image_url")
      .withColumn("location_name", $"location")
      .withColumn("wheel_key", concat($"device_id", $"asset_name", $"location"))
      .withColumn("vehicle_key", concat($"device_id", $"asset_name", lit("Last 24 Hours")))
      .withColumn("asset_wheel_config_key", concat($"asset_name", $"wheel_config"))
      .withColumn("topic_id", when(($"v_topic_id" isNull) || ($"v_topic_id" === "N/A")
        , lit("all")).otherwise($"v_topic_id")
      )
      .withColumn("topic", concat_ws("-", $"topic_id", lit("wheel-alert-current")))
      .withColumn("last_updated"
        , to_timestamp(
          from_unixtime(unix_timestamp(), "yyyy-MM-dd HH:mm:ss")
        )
      )
    .join(
        odometerDF.select($"asset_code"
          , $"odometer"
          , $"odometer_total"
          , $"odometer_miles"
          , $"odometer_total_miles")
        , Seq("asset_code")
        , "left"
      )
      .join(
        wheel_tmps_msg.select($"asset_code", $"location"
          , $"battery_status"
          )
        , Seq("asset_code","location")
        , "left"
      )
    //  .withColumn("battery_status", when($"battery_status" isNull, lit(0)).otherwise($"battery_status"))
      .where($"asset_code" isNotNull)
      .dropDuplicates("asset_code","resource","location")

    /*println("************************************wheeAlerts*****************************************")
    wheeAlerts.show(false)*/

    //This is the addition of two metric fields - ticket 2629
    val wheelWarningsMsg = wheeAlerts
      .join(
        analytic_msg
          .select(
            $"asset_code"
            , $"location"
            , $"temperature_f"
            , $"pressure_psi"
          )
        , Seq("asset_code", "location")
        , "left"
      )

    // current wheel2distance
    val wheel2distance = wheeAlerts.select(
      $"asset_id"
       , $"asset_code"
      , $"location"
      , $"resource"
      , when($"active" === 1, 1).otherwise(0) as "active"
      , $"category"
      , $"reported_time"
      , $"duration" as "device_duration"
      , lit(0) as "calc_duration"
      , lit(0)  as "est_duration"
      , $"odometer" cast "integer"
      , $"odometer_total" cast "integer"
      , $"odometer_miles" cast "double"
      , $"odometer_total_miles" cast "double"
      , lit(0) as "distance_travel"
      , lit(0) as "distance_travel_with_alert"
      , lit(null) as "old_active"
      , lit(null) as "old_category"
      , lit(null) as "old_reported_time"
      , lit(null) as "old_odometer_miles"
      , lit(null) as "old_odometer_total_miles"
      , lit(null) as "old_distance_travel"
      , lit(null) as "old_distance_travel_with_alert"
      , lit(0) as "old_calc_duration"
      , lit("false") as "state_changed"
      , current_timestamp() as "last_updated"
    )
      .join(
        analytic_msg
          .select(
            $"asset_id"
            , $"asset_code"
            , $"location"
            , $"resource"
            , $"pressure"
            , $"pressure_psi" as "anyl_pressure_psi"
            , $"temperature" as "anyl_temperature"
            , $"temperature_f" as "anyl_temperature_f"
            , $"temp_comp_pressure"
          )
        , Seq("asset_id", "asset_code", "location", "resource")
        , "left"
      )
      .join(
        wheel_tmps_msg
          .select(
            $"asset_code"
            , $"location"
            ,$"measured_temperature_c"
            ,$"measured_temperature_f"
            ,$"measured_pressure_psi"
            ,$"battery_status"
          )
        , Seq("asset_code", "location")
        , "left"
      )
     // .withColumn("battery_status", when($"battery_status" isNull, lit(0)).otherwise($"battery_status"))
      .withColumn("pressure_psi", coalesce($"measured_pressure_psi",$"anyl_pressure_psi"))
      .withColumn("temperature", coalesce($"anyl_temperature",$"measured_temperature_c"))
      .withColumn("temperature_f", coalesce($"anyl_temperature_f",$"measured_temperature_f"))
      .withColumn("checkpoint_timestamp",floor( lit( System.currentTimeMillis() / (3600 * 1000) ) ) * 3600)
      .drop(
        "measured_pressure_psi"
        ,"measured_temperature_c"
        ,"measured_temperature_f"
        ,"anyl_pressure_psi"
        ,"anyl_temperature"
        ,"anyl_temperature_f"
      )

    val wheel2disDf = wheel2distance.select(concat_ws("-", $"asset_code", $"location",$"resource") as "key"
        , to_json(
          struct(wheel2distance.columns.map(col(_)): _*)
        ) as "value"
      )
      .dropDuplicates("key")
      .coalesce(3)

   PipelineUtil.writeDataFrameToKafkaTopic(wheel2disDf, "append", PipelineUtil.kafkaConfig
      , pipelineConfig.getString("alerts_notification_topic")
    )

    val wheel_alerts = wheelWarningsMsg
      .drop("duration")  // use calculated duration.
      .join(
        prevActiveAlerts
          .select(
          $"asset_code"
          , $"location"
          , $"resource"
          , $"active" as "alert_active"
          , $"reported_time" cast "timestamp" as "alert_reported_time"
          , $"old_reported_time" cast "timestamp"
          , $"distance_travel_with_alert" cast "double"
          , $"distance_travel" cast "double" as "distance_travelled"
          , $"calc_duration" cast "long"
          , $"old_calc_duration" cast "long"
          , $"old_distance_travel_with_alert" cast "double"
          , $"est_duration" cast "long"
          , $"old_category"
          , $"event_start_time" cast "timestamp"
          , $"last_updated" cast "timestamp" as "alert_last_updated"
        )
      , Seq("asset_code","location","resource")
      , "left"
    )
      .withColumn("duration"
        , when(($"active" === 1)
          , when( ($"calc_duration" isNull) || ($"calc_duration" <= 0 )
            , when($"old_calc_duration" isNotNull
              ,$"old_calc_duration"
            ).otherwise( abs(($"alert_reported_time" cast "long") - ($"reported_time" cast "long")))
          ).otherwise($"calc_duration")
        ).otherwise(0)
      )
      .withColumn("distance_travel_with_alert"
        , when( ($"distance_travel_with_alert" isNull) || ($"distance_travel_with_alert" <= 0 )
          , $"old_distance_travel_with_alert"
        ).otherwise($"distance_travel_with_alert")
      )
      .withColumn("alert_start_time"
        , when($"active" === 1
          ,when(($"alert_reported_time" isNull)
            , when( ($"calc_duration" isNull) || ($"calc_duration" <= 0 )
              ,  (($"alert_last_updated" cast "long") - $"est_duration") cast "timestamp"
            ).otherwise(
            (($"alert_last_updated" cast "long") - $"calc_duration") cast "timestamp"
            )
          ).otherwise(
            when($"alert_active" === 1
            , $"alert_reported_time"
            ).otherwise($"reported_time")
          )
        ).otherwise(
          when($"active" isin (0,-1)
            , when((($"old_reported_time" isNotNull) && ($"alert_active" === 0))  // alert
              , $"old_reported_time" cast "timestamp"
            ).otherwise(
              when($"alert_reported_time" isNotNull
                , $"alert_reported_time" cast "timestamp"
              ).otherwise(
                (($"alert_last_updated" cast "long") - $"old_calc_duration") cast "timestamp"
              )
            )
          ).otherwise(null)
        )
      )
      .withColumn("alert_end_time"
        , when($"active" isin (0,-1)
          ,when(($"alert_reported_time" isNotNull) && ($"alert_active" === 0)
            , $"alert_reported_time" cast "timestamp"
          ).otherwise(
            when($"alert_active" === 1 // pre state is on so we are ahead. Use tour reported_time
              , $"reported_time" cast "timestamp"
            ).otherwise((($"alert_last_updated" cast "long") - $"est_duration") cast "timestamp")
          )
        ).otherwise(null)
      )
      .withColumn("category"  // last know cateogry before close of alert
        , when($"alert_end_time" isNotNull
          , $"old_category"
        ).otherwise($"category")
      )
      .drop("est_duration","old_calc_duration","old_distance_travel_with_alert","calc_duration","alert_last_updated","alert_reported_time","old_reported_time")
      .dropDuplicates("asset_code","resource","location")
      .as[ProcessedWheelWarningRecord]

    wheel_alerts
  }

  def processMessagesByBatch(batchMessage: DataFrame, batchId: Long): Unit = {

   /* val assetRoutesNOffset = PipelineUtil.updateCustomerDimCache()
    val customer_data  = try {
      PipelineUtil.updateCustomerDimCacheFromDatabase()
    } catch {
      case _=> assetRoutesNOffset._1
    }*/

    val device_new = try {
      PipelineUtil.updateCustomerDimCacheFromDatabase()
        .persist(StorageLevel.MEMORY_AND_DISK)
    } catch {
      case _ => PipelineUtil.FetchCustomerDeviceFromDatabase()
        .persist(StorageLevel.MEMORY_AND_DISK)
    }

    val list_fedx = device_new
      .select($"device_id")
      .where($"company_name" === "FedEx")
      .as[String]
      .collect
      .toList


    val AllMessage = batchMessage
      .repartition(10)
      .persist(StorageLevel.MEMORY_AND_DISK)

    val wheelWarningsMessage = AllMessage
       .where((
         ( get_json_object($"value" cast "string", "$.resource").contains(lit("events/warnings")) ) ||
           ( get_json_object($"value" cast "string", "$.resource").contains(lit("wheel/")) ))
          && (get_json_object($"value" cast "string", "$.service") =!= "analytics")
        )
     /* .where((
        (get_json_object($"value" cast "string", "$.resource") === "events/warnings.*") ||
        (get_json_object($"value" cast "string", "$.resource") === "wheel/temperature-warning") ||
        (get_json_object($"value" cast "string", "$.resource") === "wheel/pressure-warning") ||
        (get_json_object($"value" cast "string", "$.resource") === "wheel/battery-warning") ||
        (get_json_object($"value" cast "string", "$.resource") === "wheel/dynamic-pressure-warning") ||
        (get_json_object($"value" cast "string", "$.resource") === "wheel/tyre-lock-warning"))
          && (get_json_object($"value" cast "string", "$.service") =!= "analytics")
       //   && (get_json_object($"value" cast "string", "$.category") === "stream")
      )*/


    /*println("*********************wheelWarningsMessage***************")
    wheelWarningsMessage.show(false)*/

    val wheelWarningsMessageV2 = wheelWarningsMessage.select(
      from_json($"value" cast "string"
        , ScalaReflection.schemaFor[AllV2Message].dataType.asInstanceOf[StructType]
      ) as "events"
    )
      .select($"events.*")
      .filter($"version" >= "2.0")
      .withColumn("location", $"data.location")
      .withColumn("value", $"data.value")
      .withColumnRenamed("time", "reported_time")
      .withColumnRenamed("deviceId", "device_id")
      .withColumn("category", setCategoryValue)
      .drop("value")


    /*println("*********************wheelWarningsMessageV2***************")
    wheelWarningsMessageV2.show(false)*/

    //*************************This is only for FEDX******************************
    val device_list = List("1KqjV1xC2C12","1JXjSbXCWPF2","1KqjV1xC2H12","1JXjTVLCZCF2","55090041","54990065",
      "1JZGMSg1H112","54990142","1JZGMSg1Gg12","54990170","1JZGMSg1Hp12","54990211","50700238","1KqjV1xC2g12"
      ,"1JXjTVLCZ3F2","1KqjV1xC1j12","1JXjTVLCYtF2","1JXjTVLCYyF2","1KqjV1xC2r12","1JXjTVLCZHF2","1KqjV1xC1d12"
      ,"1JXjTVLCYPF2","1KqjV1xC1t12","1JXjpFXC6312","1JXjpFXC9F12","1JXk3nkC1t12","1KqjyYXC1d12","1JXjkgXC6g12"
      ,"1JXjpFXC8b12","1Kqjw1XC2b12","1JXjpFXCCP12","1JXjpFXC5d12","1JXjpFXC4w12","1JXjpVLC1Y12","1JXjpFXC7K12"
      ,"1JXjpVLC7j12","1JXjpFXC9112","1KqjyYXC1Y12","1JXjpVLC3F12","1JXjpVLC4712","1JXjpVLC4H12","1JXjpVLC7512"
      ,"1JXjpFXC8g12","1JXjpFXC8312","1JXjpVLC7P12","1JXjpVLC2H12","1JXjpVLC3Y12","1JXjpVLC6312","1JXjpFXCBC12"
      ,"1JXjpFXCBM12","1JXjpVLC7d12","24100026","24100006","24100035","24100058","1JXjpFXC5p12","1JXjpVLC3P12"
      ,"1JXjpFXC5t12","1JXjpVLC4W12","24100005","24100011","24100030","24100016","24100023","24100047","24100054"
      ,"24100020","24100021","24100019","24100008","24100060","24100038","23344444","24100055","1JXjpFXC8M12"
      ,"24100036","1JXjpFXC6C12","1Kqjw1XC3112","1JXjpFXC5Y12","1JXjpFXC7112","1JXjmr8C2R12","1JXjpFXC5912"
      ,"1JXjpVLC2R12","1JXjpFXC2C12","1JXjpFXC1t12","1JXjpVLC3d12","1KqjsqkC1912","1JXjpFXC6R12","1KqjYb8C2312"
      ,"1JXjpVLC3t12","1JXjpFXC3112","1JXjpVLC5112","1JXjpVLC5512","1JXjpVLC5K12","1JXjpVLC4r12","1JXjpVLC6H12"
      ,"1JXjpVLC3512","1JXjpFXC3512","1JXjpFXC1P12","1JXjpFXC3F12","1JXjpFXC3d12","1JXjpVLC2g12","1JXjpFXC3j12"
      ,"1JXjpVLC2w12","1JXjpFXC2w12","1JXjpFXC7t12"
      )

    val Fedx_Message = AllMessage
      .where(
        ( get_json_object($"value" cast "string", "$.resource").contains(lit("events/warnings"))
          || get_json_object($"value" cast "string", "$.resource").contains(lit("wheel/")))
          && (get_json_object($"value" cast "string", "$.service") === "tpms")
       )
      .filter(get_json_object($"value" cast "string", "$.deviceId").isin(list_fedx:_*))
      .select($"value")

    PipelineUtil.writeDataFrameToKafkaTopic(Fedx_Message, "append", PipelineUtil.kafkaConfig
      , pipelineConfig.getString("fedx_alerts_new_topic")
    )
    //*************************Above is only for FEDX for M2M******************************

    //this is for New Odometer total msg from Hub - ticket - 2635
    val OdoDistData = AllMessage
      .where(get_json_object($"value" cast "string", "$.resource") === MessageTypes.OdometerDist)
      .select(
        from_json($"value" cast "string"
          , ScalaReflection.schemaFor[VehicleOdoDist].dataType.asInstanceOf[StructType]
        ) as "events"
      ).select($"events.*")
      .as[VehicleOdoDist]
      .withColumn("odometer_total_in_KM", $"data.distance" cast "integer")



    //this is for New Odometer msg from Hub - ticket - 2635
    val OdoTripDistData = AllMessage
      .where(get_json_object($"value" cast "string", "$.resource") === MessageTypes.OdometerTripDist)
      .select(
        from_json($"value" cast "string"
          , ScalaReflection.schemaFor[VehicleOdoTripDist].dataType.asInstanceOf[StructType]
        ) as "events"
      ).select($"events.*")
      .as[VehicleOdoTripDist]
      .withColumn("odometer_in_KM", $"data.trip-distance" cast "integer")

    val OdoFinal = OdoDistData.alias("odisd").join(
      OdoTripDistData.alias("otdisd")
      , (
        ($"odisd.deviceId" === $"otdisd.deviceId")
        )
      , "outer"
    )
      .select(
        coalesce($"odisd.deviceId",$"otdisd.deviceId") as "deviceId",
        coalesce($"odisd.time",$"otdisd.time") as "reported_time",
        coalesce($"odisd.timestamp",$"otdisd.timestamp") as "timestamp",
        coalesce($"odisd.consumed_timestamp",$"otdisd.consumed_timestamp") as "consumed_timestamp",
        $"odometer_in_KM" * 1000 as "odometer",
        $"odometer_total_in_KM" * 1000 as "odometer_total"
      )
      .withColumn("device_id", $"deviceId")
      .withColumn("odometer_miles", $"odometer" * 0.000621371 cast "double")
      .withColumn("odometer_total_miles", $"odometer_total" * 0.000621371 cast "double")
      .join(
        device_new
          .select("device_id","v_asset_id","v_asset_code")
        , Seq("device_id")
        , "left"
      )
      .withColumn("asset_id", $"v_asset_id")
      .withColumn("asset_code", $"v_asset_code")
      .drop("device_id")

    val distanceData = AllMessage
      .where(get_json_object($"value" cast "string", "$.resource") === MessageTypes.GnssDistance)
      .select(
        from_json($"value" cast "string"
          , ScalaReflection.schemaFor[VehicleGnssDistance].dataType.asInstanceOf[StructType]
        ) as "events"
      ).select($"events.*")
      .withColumn("reported_time", $"time" cast "timestamp")
      .withColumn("device_id", $"deviceId")
      .withColumn("odometer", $"data.odometer" cast "integer")
      .withColumn("odometer_total", $"data.odometer_total" cast "integer")
      .withColumn("odometer_miles", $"odometer" * 0.000621371 cast "double")
      .withColumn("odometer_total_miles", $"odometer_total" * 0.000621371 cast "double")
      .join(
        device_new
          .select("device_id","v_asset_id","v_asset_code")
        , Seq("device_id")
        , "left"
      )
      .withColumn("asset_id", $"v_asset_id")
      .withColumn("asset_code", $"v_asset_code")
      .drop("device_id")
      .select(
        $"asset_code"
        , $"reported_time"
        , $"odometer"
        , $"odometer_total"
        , $"odometer_miles"
        , $"odometer_total_miles"
      )
      .union(
        OdoFinal.select(
          $"asset_code"
          , $"reported_time"
          , $"odometer"
          , $"odometer_total"
          , $"odometer_miles"
          , $"odometer_total_miles"
        )
      )

    val wheelWarningAnalyticsMessage = AllMessage
      .where(
        get_json_object($"value" cast "string", "$.service") === "analytics"
      )

    val wheel_tpms_messageNOffsets = PipelineUtil.loadWheelTPMSData()

    val wheel_tpms_message = dedupToLatest(
      wheel_tpms_messageNOffsets._1
    ).drop("resource").persist(StorageLevel.MEMORY_AND_DISK)

    val snapShotMsg = addTimeStampColumns(wheelWarningAnalyticsMessage
      .select(
        from_json($"value" cast "string"
          , ScalaReflection.schemaFor[AnalyticWarningEvent].dataType.asInstanceOf[StructType]
        ) as "events"
      ).select($"events.*")
      .withColumnRenamed("deviceId","device_id")
      .withColumnRenamed("version","schema_version")
      .withColumn("reported_time", $"time" cast "timestamp")
      .withColumn("pipeline_timestamp", $"timestamp" cast "timestamp")
    )
      .withColumn("last_updated"
        , to_timestamp(
          from_unixtime(unix_timestamp(), "yyyy-MM-dd HH:mm:ss")
        )
      )

    val anaytics_metric_msgs = flattenAnalyticalMessage(
      snapShotMsg
        .join(
          device_new
          , Seq("device_id")
          , "left"
        )
        .drop("reported_device_id")
        .withColumn("asset_id", when($"v_asset_id" isNull, "N/A").otherwise($"v_asset_id"))
        .withColumn("asset_code", when($"v_asset_code" isNull, "N/A").otherwise($"v_asset_code"))

    ).join(
      wheel_tpms_message.select("asset_code","location","battery_status")
      , Seq("asset_code","location")
      , "left"
    )
      .select(
         $"service"
        , $"reported_time"
        , $"resource"
        , $"location"
        , $"category"
        , $"asset_id"
        , $"asset_code"
        , $"pressure"
        , $"pressure_psi"
        , $"temperature"
        , $"temperature_f"
        , $"battery_status"
        , $"temp_comp_pressure"
      )

    /*println("*********************anaytics_metric_msgs***************")
    anaytics_metric_msgs.show(false)*/

    val alerts_analytics_v2 = wheelWarningsMessageV2.join(
      wheel_tpms_message.select("device_id", "location", "asset_code","measured_temperature_c","measured_temperature_f",
      "measured_pressure_psi","battery_status")
      , Seq("device_id","location")
      , "left"
    )
      .withColumn("temperature",  $"measured_temperature_f")
      .withColumn("pressure",  $"measured_pressure_psi")
      .withColumn("temperature_f",  $"measured_temperature_f")
      .withColumn("pressure_psi",  $"measured_pressure_psi")
      .withColumn("asset_id_in", split($"asset_code", "-" ))
      .withColumn("asset_name", $"asset_id_in"(0))
      .withColumn("asset_id", $"asset_id_in"(1))
      .withColumn("temp_comp_pressure", lit(null))
      .select(
        $"service"
        , $"reported_time"
        , $"resource"
        , $"location"
        , $"category"
        , $"asset_id"
        , $"asset_code"
        , $"pressure"
        , $"pressure_psi"
        , $"temperature"
        , $"temperature_f"
        , $"battery_status"
        , $"temp_comp_pressure"
      )
      .where($"asset_code".isNotNull)

    /*println("*******************alerts_analytics_v2*********************")
    alerts_analytics_v2.show(false)*/

    val alerts_metrics_final = anaytics_metric_msgs.union(alerts_analytics_v2)

    /*println("*******************alerts_metrics_final*********************")
    alerts_metrics_final.show(false)*/

    val wheeWarnings = processWheelBatch(wheelWarningsMessage,distanceData,alerts_metrics_final, wheel_tpms_message,device_new)

    /*println("*********************wheeWarnings final***************")
    wheeWarnings.show(false)*/


    // publish on kafka
    val wheelWarnDf = wheeWarnings
      .select(concat_ws("-", $"resource",$"location", $"device_id") as "key"
        , to_json(
          struct(wheeWarnings.columns.map(col(_)): _*)
        ) as "value"
      ).coalesce(6)

   PipelineUtil.writeDataFrameToKafkaTopic(wheelWarnDf, "append", PipelineUtil.kafkaConfig
      , pipelineConfig.getString("curated_alerts_topic")
    )

    // publish snapshot on kafka
    val snapShotDf = snapShotMsg
      .select(concat_ws("-", lit("alert-snapshot-"), $"device_id") as "key"
        , to_json(
          struct(snapShotMsg.columns.map(col(_)): _*)
        ) as "value"
      ).coalesce(6)

     PipelineUtil.writeDataFrameToKafkaTopic(snapShotDf, "append", PipelineUtil.kafkaConfig
      , pipelineConfig.getString("curated_analytics_topic")
    )


    AllMessage.unpersist()
  }

  def addTimeStampColumns(df: DataFrame): DataFrame = {
    df
      .withColumn("timestamp", $"timestamp" cast "timestamp")
      .withColumn("consumed_timestamp", $"consumed_timestamp" cast "long")
      .withColumn("time", $"time" cast "timestamp")

  }

  def doAlertEventsProcessing() {

    val AllMessage = PipelineUtil.spark.readStream
      .format("kafka")
      .options(PipelineUtil.kafkaConfig)
      //.option("groupIdPrefix", pipelineConfig.getString("alerts_consumer_group"))
      .option("subscribe", pipelineConfig.getString("source_alert_records_topic"))
      .load()
      .withColumn("timestamp",
        (get_json_object($"value" cast "string", "$.timestamp") cast "long") cast "timestamp"
      )
    //.withWatermark(watermark_column, watermark_delay_threashold)

    // persist wheel information
    AllMessage.writeStream
      .trigger(Trigger.ProcessingTime(PipelineUtil.processing_trigger_time))
      .outputMode("append")
      //.option("checkpointLocation", pipelineConfig.getString("alerts_checkpoint_location"))
      .foreachBatch(processMessagesByBatch _)
      .queryName("Process Alert Events")
      .start()


  }
}
