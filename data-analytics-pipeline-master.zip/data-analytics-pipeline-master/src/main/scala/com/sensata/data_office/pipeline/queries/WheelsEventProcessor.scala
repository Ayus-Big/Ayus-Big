package com.sensata.data_office.pipeline.queries

import com.sensata.data_office.data._
import com.sensata.data_office.utilities.Analytics.addTpmsGroupingColumns
import com.sensata.data_office.utilities.PipelineUtil
import com.typesafe.config.ConfigFactory
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.catalyst.ScalaReflection
import org.apache.spark.sql.functions._
import org.apache.spark.sql.streaming.Trigger
import org.apache.spark.sql.types.StructType
import org.apache.spark.storage.StorageLevel

object WheelsEventProcessor {


  val pipelineConfig = ConfigFactory
    .load(s"application.${PipelineUtil.getEnvVariable("ENVIRONMENT")}.conf")
    .getConfig("EventProcessors").getConfig("pipeline")

  val VERSION = pipelineConfig.getString("version")

  val watermark_column = ConfigFactory
    .load(s"application.${PipelineUtil.getEnvVariable("ENVIRONMENT")}.conf").getConfig("high_watermark").getString("watermark_column")
  val watermark_delay_threashold = ConfigFactory
    .load(s"application.${PipelineUtil.getEnvVariable("ENVIRONMENT")}.conf").getConfig("high_watermark").getString("watermark_delay_threashold")
  val late_record_threshold_sec = ConfigFactory
    .load(s"application.${PipelineUtil.getEnvVariable("ENVIRONMENT")}.conf").getConfig("high_watermark").getString("late_record_threshold_sec")


  import PipelineUtil.spark.implicits._

  def processMessagesByBatch(batchMessage: DataFrame, batchId: Long): Unit = {

    /*val assetRoutesNOffset = PipelineUtil.updateCustomerDimCache()
    val customer_data  = try {
      PipelineUtil.updateCustomerDimCacheFromDatabase()
    } catch {
      case _=> assetRoutesNOffset._1
    }*/

    val device_new = try {
      PipelineUtil.updateCustomerDimCacheFromDatabase()
        .persist(StorageLevel.MEMORY_AND_DISK)
    } catch {
      case _ => PipelineUtil.FetchCustomerDeviceFromDatabase()
        .persist(StorageLevel.MEMORY_AND_DISK)
    }

    val list_fedx = device_new
      .select($"device_id")
      .where($"company_name" === "FedEx")
      .as[String]
      .collect
      .toList


    val AllMessage = batchMessage
      .repartition(10)
      .persist(StorageLevel.MEMORY_AND_DISK)

    // get the Temp data
    val tempMessage = AllMessage
      .where(get_json_object($"value" cast "string", "$.resource") === MessageTypes.WheelInfoTemperature
        && get_json_object($"value" cast "string", "$.version") < 2.0)
      .select(
        from_json($"value" cast "string"
          , ScalaReflection.schemaFor[WheelInfoTemperature].dataType.asInstanceOf[StructType]
        ) as "events"
      ).select($"events.*")
      .as[WheelInfoTemperature]
      //.select()
      .withColumn("location", $"data.location")
      .withColumn("temperature", $"data.temperature")
      .select(
        "service","version","deviceId","customer","time","timestamp","location","temperature","consumed_timestamp")


    val tempMessageV2 = AllMessage
      .where(get_json_object($"value" cast "string", "$.resource") === MessageTypes.WheelInfoTemperatureV2
      && get_json_object($"value" cast "string", "$.version") >= 2.0)
      .select(
        from_json($"value" cast "string"
          , ScalaReflection.schemaFor[WheelInfoTemperatureV2].dataType.asInstanceOf[StructType]
        ) as "events"
      ).select($"events.*")
      .as[WheelInfoTemperatureV2]
      .withColumn("location", $"data.location")
      .withColumn("temperature", $"data.value")
      .select(
        "service","version","deviceId","customer","time","timestamp","location","temperature","consumed_timestamp")

    val tempMessageFin = tempMessage.union(tempMessageV2)

    //*****************************************This is for FEDX****************************************

    val device_list_fedx = List("1KqjV1xC2C12","1JXjSbXCWPF2","1KqjV1xC2H12","1JXjTVLCZCF2","55090041",
      "54990065","1JZGMSg1H112","54990142","1JZGMSg1Gg12","54990170","1JZGMSg1Hp12","54990211","50700238","1KqjV1xC2g12"
      ,"1JXjTVLCZ3F2","1KqjV1xC1j12","1JXjTVLCYtF2","1JXjTVLCYyF2","1KqjV1xC2r12","1JXjTVLCZHF2","1KqjV1xC1d12"
      ,"1JXjTVLCYPF2","1KqjV1xC1t12","1JXjpFXC6312","1JXjpFXC9F12","1JXk3nkC1t12","1KqjyYXC1d12","1JXjkgXC6g12"
      ,"1JXjpFXC8b12","1Kqjw1XC2b12","1JXjpFXCCP12","1JXjpFXC5d12","1JXjpFXC4w12","1JXjpVLC1Y12","1JXjpFXC7K12"
      ,"1JXjpVLC7j12","1JXjpFXC9112","1KqjyYXC1Y12","1JXjpVLC3F12","1JXjpVLC4712","1JXjpVLC4H12","1JXjpVLC7512"
      ,"1JXjpFXC8g12","1JXjpFXC8312","1JXjpVLC7P12","1JXjpVLC2H12","1JXjpVLC3Y12","1JXjpVLC6312","1JXjpFXCBC12"
      ,"1JXjpFXCBM12","1JXjpVLC7d12","24100026","24100006","24100035","24100058","1JXjpFXC5p12","1JXjpVLC3P12"
      ,"1JXjpFXC5t12","1JXjpVLC4W12","24100005","24100011","24100030","24100016","24100023","24100047","24100054"
      ,"24100020","24100021","24100019","24100008","24100060","24100038","23344444","24100055","1JXjpFXC8M12"
      ,"24100036","1JXjpFXC6C12","1Kqjw1XC3112","1JXjpFXC5Y12","1JXjpFXC7112","1JXjmr8C2R12","1JXjpFXC5912"
      ,"1JXjpVLC2R12","1JXjpFXC2C12","1JXjpFXC1t12","1JXjpVLC3d12","1KqjsqkC1912","1JXjpFXC6R12","1KqjYb8C2312"
      ,"1JXjpVLC3t12","1JXjpFXC3112","1JXjpVLC5112","1JXjpVLC5512","1JXjpVLC5K12","1JXjpVLC4r12","1JXjpVLC6H12"
      ,"1JXjpVLC3512","1JXjpFXC3512","1JXjpFXC1P12","1JXjpFXC3F12","1JXjpFXC3d12","1JXjpVLC2g12","1JXjpFXC3j12"
      ,"1JXjpVLC2w12","1JXjpFXC2w12","1JXjpFXC7t12"
    )
    val Fedx_Temp_Message = AllMessage
      .where((get_json_object($"value" cast "string", "$.resource") === MessageTypes.WheelInfoTemperature)
        || (get_json_object($"value" cast "string", "$.resource") === MessageTypes.WheelInfoPressure)
        || (get_json_object($"value" cast "string", "$.resource") === MessageTypes.WheelInfoBattery)
        || (get_json_object($"value" cast "string", "$.resource") === MessageTypes.WheelInfoTemperatureV2)
        || (get_json_object($"value" cast "string", "$.resource") === MessageTypes.WheelInfoPressureV2)
        || (get_json_object($"value" cast "string", "$.resource") === MessageTypes.WheelInfoBatteryV2))
    //  && get_json_object($"value" cast "string", "$.version") < 2.0)
      .filter(get_json_object($"value" cast "string", "$.deviceId").isin(list_fedx:_*))
      .select($"value")

    PipelineUtil.writeDataFrameToKafkaTopic(Fedx_Temp_Message, "append", PipelineUtil.kafkaConfig
      , pipelineConfig.getString("fedx_alerts_new_topic")
    )

    //**************************************This is for FEDX********************************************

    // get the Pressure data
    val pressureMessage = AllMessage
      .where(get_json_object($"value" cast "string", "$.resource") === MessageTypes.WheelInfoPressure
        && get_json_object($"value" cast "string", "$.version") < 2.0)
      .select(
        from_json($"value" cast "string"
          , ScalaReflection.schemaFor[WheelInfoPressure].dataType.asInstanceOf[StructType]
        ) as "events"
      ).select($"events.*")
      .as[WheelInfoPressure]
      .withColumn("location", $"data.location")
      .withColumn("measured", $"data.pressure.measured")
      .withColumn("temp_comp", $"data.pressure.temp_comp")
      .select(
        "service","version","deviceId","customer","time","timestamp","location","measured","temp_comp","consumed_timestamp")

    val pressureMessageV2 = AllMessage
      .where(get_json_object($"value" cast "string", "$.resource") === MessageTypes.WheelInfoPressureV2
        && get_json_object($"value" cast "string", "$.version") >= 2.0)
      .select(
        from_json($"value" cast "string"
          , ScalaReflection.schemaFor[WheelInfoPressureV2].dataType.asInstanceOf[StructType]
        ) as "events"
      ).select($"events.*")
      .as[WheelInfoPressureV2]
      .withColumn("location", $"data.location")
      .withColumn("measured", $"data.value")
      .withColumn("temp_comp", lit(0))
      .select(
        "service","version","deviceId","customer","time","timestamp","location","measured","temp_comp","consumed_timestamp")

    val pressureMessageFin = pressureMessage.union(pressureMessageV2)

     // get the Batt data
    val battMessage = AllMessage
      .where(get_json_object($"value" cast "string", "$.resource") === MessageTypes.WheelInfoBattery
        && get_json_object($"value" cast "string", "$.version") < 2.0)
      .select(
        from_json($"value" cast "string"
          , ScalaReflection.schemaFor[WheelInfoBattery].dataType.asInstanceOf[StructType]
        ) as "events"
      ).select($"events.*")
      .as[WheelInfoBattery]
     // .withColumn("location", $"data.location" cast "string")
    //  .withColumn("battery", $"data.battery")
      .select(
        "service","version","deviceId","customer","time","timestamp","data","consumed_timestamp")


    val battMessageV2 = AllMessage
      .where(get_json_object($"value" cast "string", "$.resource") === MessageTypes.WheelInfoBatteryV2
        && get_json_object($"value" cast "string", "$.version") >= 2.0)
      .select(
        from_json($"value" cast "string"
          , ScalaReflection.schemaFor[WheelInfoBatteryV2].dataType.asInstanceOf[StructType]
        ) as "events"
      ).select($"events.*")
      .as[WheelInfoBatteryV2]
      .withColumn("data1",
        struct(
          col("data.location").as("location"),col("data.value").as("battery"))
      )
      .drop("data")
      .withColumnRenamed("data1","data")
      .select(
        "service","version","deviceId","customer","time","timestamp", "data", "consumed_timestamp")

   val battMessageFin = battMessage.union(battMessageV2)


    // test if we have
    var pos_with_vel = PipelineUtil.spark.emptyDataFrame
    if (pressureMessageFin.count() > 0) {
      pos_with_vel = pressureMessageFin.as("pres").join(
        tempMessageFin.as("temp")
        , (
          ($"temp.deviceId" === $"pres.deviceId") &&
            ($"temp.location" === $"pres.location") &&
            (abs((($"temp.time" cast "long") - ($"pres.time" cast "long"))) < lit(late_record_threshold_sec))

          )
        , "left"
      ).select(
        concat_ws("-", $"pres.service", lit("curated")) as "service"
        , $"pres.deviceId" as "device_id"
        , $"pres.customer" as "device_name"
        , $"pres.time" cast "timestamp" as "reported_time"
        , $"pres.location" cast "string" as "location"
        , $"pres.version" as "schema_version"
        , $"pres.timestamp" cast "timestamp" as "pipeline_timestamp"
        , $"pres.consumed_timestamp" cast "long" as "consumed_timestamp"
        , $"temp.temperature" cast "double" as "measured_temperature"
        , $"pres.measured" cast "double" as "measured_pressure"
        , $"pres.temp_comp" cast "double" as "temp_comp"
      )
    } else {  // drive with temp
      pos_with_vel = pressureMessageFin.as("pres").join(
        tempMessageFin.as("temp")
        , (
          ($"temp.deviceId" === $"pres.deviceId") &&
            ($"temp.location" === $"pres.location") &&
            (abs((($"temp.time" cast "long") - ($"pres.time" cast "long"))) < lit(late_record_threshold_sec))

          )
        , "right"
      ).select(
        concat_ws("-", $"temp.service", lit("curated")) as "service"
        , $"temp.deviceId" as "device_id"
        , $"temp.customer" as "device_name"
        , $"temp.time" cast "timestamp" as "reported_time"
        , $"temp.location" cast "string" as "location"
        , $"temp.version" as "schema_version"
        , $"temp.timestamp" cast "timestamp" as "pipeline_timestamp"
        , $"temp.consumed_timestamp" cast "long" as "consumed_timestamp"
        , $"temp.temperature" cast "double" as "measured_temperature"
        , $"pres.measured" cast "double" as "measured_pressure"
        , $"pres.temp_comp" cast "double" as "temp_comp"
      )
    }

    // merge the wheel info streams to get a flat table
    val wheelInfo = addTpmsGroupingColumns(
      pos_with_vel.join(
        battMessageFin.select("deviceId","data","time").as("batt")
        , (
          ($"device_id" === $"batt.deviceId") &&
            ($"location" === $"batt.data.location") &&
            (abs((($"reported_time" cast "long") - ($"batt.time" cast "long"))) < lit(late_record_threshold_sec))

          )
        , "left"
      )
        .withColumn(
          "battery_status", $"batt.data.battery" cast "integer"
        )
        .join(
          device_new
          , Seq("device_id")
          , "left"
        )
      .withColumn("measured_temperature_c", $"measured_temperature" cast "float")
      .withColumn("measured_temperature_f", round(((($"measured_temperature_c" cast "double") * 1.8) + 32), 1))
      .withColumn("measured_pressure_psi", round((($"measured_pressure" cast "double") / 68.9476), 2))
      .withColumn("company", $"company_name")
      .withColumn("fleet", $"fleet_name")
      .withColumn("asset_name", $"company_asset_name")
      .withColumn("wheel_config", $"v_wheel_config")
      .withColumn("no_axles", $"v_no_axles")
      .withColumn("asset_id", $"v_asset_id")
      .withColumn("asset_code", $"v_asset_code")
      .withColumn("image_url", $"v_asset_id")
      .withColumn("location_name", $"location")
      .withColumn("wheel_key", concat($"device_id", $"asset_name", $"location"))
      .withColumn("vehicle_key", concat($"device_id", $"asset_name", lit("Last 24 Hours")))
      .withColumn("asset_wheel_config_key", concat($"asset_name", $"wheel_config"))
      .withColumn("topic_id", when(($"v_topic_id" isNull) || ($"v_topic_id" === "N/A")
        , lit("all")).otherwise($"v_topic_id")
      )
      .withColumn("topic", concat_ws("-", $"topic_id", lit("wheel-stream-current")))
      .withColumn("last_updated"
        , to_timestamp(
          from_unixtime(unix_timestamp(), "yyyy-MM-dd HH:mm:ss")
        )
      )
    )
      .where(
        ($"asset_code" isNotNull)
          )
      .dropDuplicates("asset_code","location","schema_version")

      .as[ProcessedWheelRecord]

    // publish on kafka
    val wheelDf = wheelInfo
      .select(concat_ws("-",$"device_id", $"service", $"location") as "key"
        , to_json(
          struct(wheelInfo.columns.map(col(_)): _*)
        ) as "value"
      ).coalesce(6)

    PipelineUtil.writeDataFrameToKafkaTopic(wheelDf, "append", PipelineUtil.kafkaConfig
      , pipelineConfig.getString("curated_wheel_records_topic")
    )

    // publish on alert topic
    val wheelDf1 = wheelInfo
      .select(
        $"device_id"
        , lit("wheel-tpms-data") as "service"
        , $"location"
        ,$"asset_code"
        ,$"measured_temperature_c"
        ,$"measured_temperature_f"
        ,$"measured_pressure_psi"
        ,$"battery_status"
        ,$"reported_time"
      )
      .withColumn("last_updated", current_timestamp())
      .select(concat_ws("-",$"asset_code", $"location") as "key"
        , to_json(
          struct(
            $"device_id"
            , $"service"
            , $"location"
            ,$"asset_code"
            ,$"measured_temperature_c"
            ,$"measured_temperature_f"
            ,$"measured_pressure_psi"
            ,$"battery_status"
            ,$"reported_time"
            ,$"last_updated"
          )
        ) as "value"
      ).coalesce(6)

    PipelineUtil.writeDataFrameToKafkaTopic(wheelDf1, "append", PipelineUtil.kafkaConfig
      , pipelineConfig.getString("compact_tpms_records_topic")
    )

    // publish to asset activity topic
    val wheelDf2 = wheelInfo
      .groupBy("asset_code","schema_version")
      .agg(
        max("reported_time") as "reported_time"
      )
      .withColumn("msg_type",lit("wheel"))
      .withColumn("last_updated", current_timestamp())
      .select(concat_ws("-",$"msg_type",$"asset_code") as "key"
        , to_json(
          struct($"msg_type"
            ,$"asset_code"
            ,$"reported_time"
            ,$"last_updated")
        ) as "value"
      ).coalesce(3)

    PipelineUtil.writeDataFrameToKafkaTopic(wheelDf2, "append", PipelineUtil.kafkaConfig
      , pipelineConfig.getString("asset_activity_topic")
    )

    AllMessage.unpersist()
  }

  def doWheelEventProcessing() {

    val tpmsMessage = PipelineUtil.spark.readStream
      .format("kafka")
      .options(PipelineUtil.kafkaConfig)
      .option("subscribe", pipelineConfig.getString("source_tpms_stream_records_topic"))
      .load()
      .withColumn("timestamp",
        ((get_json_object($"value" cast "string", "$.timestamp") cast "long") / 1000) cast "timestamp"
      )
      //.withWatermark(watermark_column, watermark_delay_threashold)

    // persist wheel information
    tpmsMessage
      .writeStream
      .trigger(Trigger.ProcessingTime(PipelineUtil.processing_trigger_time))
      //.option("checkpointLocation", pipelineConfig.getString("wheels_checkpoint_location"))
      .foreachBatch(processMessagesByBatch _)
      .queryName("Processed TPMS Data Stream")
      .start()
  }
}
