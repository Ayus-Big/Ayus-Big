package com.sensata.data_office.pipeline.queries

import com.sensata.data_office.data.CustomerRoutingRecord
import com.sensata.data_office.utilities.PipelineUtil
import com.typesafe.config.ConfigFactory
import org.apache.spark.sql.catalyst.ScalaReflection
import org.apache.spark.sql.functions._
import org.apache.spark.sql.streaming.Trigger
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.{DataFrame, Dataset, Row}
import org.apache.spark.storage.StorageLevel

import scala.collection.JavaConverters._

object CachedDataProcessor {

  val pipelineConfig = ConfigFactory
    .load(s"application.${PipelineUtil.getEnvVariable("ENVIRONMENT")}.conf")
    .getConfig("EventProcessors").getConfig("pipeline")
  val kafkaConfig = ConfigFactory
    .load(s"application.${PipelineUtil.getEnvVariable("ENVIRONMENT")}.conf")
    .getConfig("kafka_config").root.asScala.map(
    v => v._1 -> String.valueOf(v._2.unwrapped())
  )

  import PipelineUtil.spark.implicits._


  def processBatchDeviceDB(batchDF: Dataset[Row], batchId: Long): Unit = {

    val batch_records = batchDF.count()
    PipelineUtil.appLogger.info(s"Invalidating Cache. Run Batch: $batchId, Run Counter: $batch_records")
    try {
      val customer_data = PipelineUtil.updateCustomerDimCacheFromDatabase()
        .as[CustomerRoutingRecord]

      PipelineUtil.writeDataFrameToKafkaTopic(customer_data
        .select(concat_ws("-", $"v_asset_code",$"device_id") as "key"
          , to_json(
            struct(customer_data.columns.map(col(_)): _*)
          ) as "value"
        ).coalesce(3)
        , "append"
        , PipelineUtil.kafkaConfig
        , pipelineConfig.getString("device_customer_routing_topic")
      )


      PipelineUtil.appLogger.info(s"Cache invalidation complete. Row Count: ${customer_data.count()}")

      if (Seq("dev","stg").contains(PipelineUtil.getEnvVariable("ENVIRONMENT")) ) {
        PipelineUtil.appLogger.info(s"Device id to topic mapping : ${
          customer_data.select(concat_ws(" -> ",$"device_id", $"v_topic_id") as "device_2_topic")
            .limit(5).collect().map(r => r.getString(0)).mkString("\n")
        }")
      }
    } catch {
      case _=> batch_records
    }

  }

  def doCachedDataInvalidation() {

    // cache information regarding fleet and customers from DB
    val db_cache_stream =  PipelineUtil.spark
      .readStream
      .format("rate")
      .option("rowsPerSecond", 1)
      .option("numPartitions", 3)
      .load

    db_cache_stream
      .writeStream
      .trigger(Trigger.ProcessingTime(PipelineUtil.db_cache_invalidate_trigger_time))
      .foreachBatch(processBatchDeviceDB _)
      .queryName("Invalidate Device Routing Cache")
      .start()

  }
}
