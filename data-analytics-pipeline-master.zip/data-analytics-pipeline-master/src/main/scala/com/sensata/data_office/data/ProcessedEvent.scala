package com.sensata.data_office.data


case class CustomerRoutingRecord(
                                  device_id: String
                                 ,reported_device_id: String
                                 ,company_name: String
                                 ,fleet_name: String
                                 ,company_asset_name: String
                                 ,v_wheel_config: String
                                 ,v_no_axles: String
                                 , v_image_url: String
                                 ,v_asset_id: Int
                                 ,v_asset_code: String
                                 ,v_topic_id: String
                                )

case class GenericProcessedRecord(
                                 service: String
                                 , reported_time:  java.sql.Timestamp
                                 , schema_version: String
                                 , pipeline_timestamp:  java.sql.Timestamp
                                 , consumed_timestamp:  Long
                               )

case class ProcessedAlertSnapshot(
                                   service: String
                                   , resource: String
                                   , schema_version: String
                                   , device_id: String
                                   , customer: String
                                   , reported_time: java.sql.Timestamp
                                   , pipeline_timestamp:  java.sql.Timestamp
                                   , consumed_timestamp:  Long
                                   , data: AnalyticWarningEventData
                                   , topic: String
                                   , topic_id: String
                                   , last_updated: java.sql.Timestamp
                                 )

case class ArchivedProcessedAlertSnapshot(
                                           service: String
                                           , resource: String
                                           , schema_version: String
                                           , device_id: String
                                           , customer: String
                                           , reported_time: java.sql.Timestamp
                                           , pipeline_timestamp:  java.sql.Timestamp
                                           , consumed_timestamp:  Long
                                           , data: AnalyticWarningEventData
                                           , topic: String
                                           , topic_id: String
                                           , last_updated: java.sql.Timestamp
                                           , run_date: Long
                                         )

case class ProcessedWheelWarningRecord(
                                        service: String
                                        , reported_time:  java.sql.Timestamp
                                        , alert_start_time:  java.sql.Timestamp
                                        , alert_end_time:  java.sql.Timestamp
                                        , event_start_time: java.sql.Timestamp
                                        , schema_version: String
                                        , resource: String
                                        , location: String
                                        , location_name: String
                                        , device_id: String
                                        , asset_id: String
                                        , asset_code: String
                                        , device_name: String
                                        , company: String
                                        , fleet: String
                                        , wheel_config: String
                                        , image_url: String
                                        , no_axles: String
                                        , asset_name: String
                                        , pipeline_timestamp:  java.sql.Timestamp
                                        , consumed_timestamp:  Long
                                        , active:Int
                                        , alert_name:String
                                        , alert_id: Long
                                        , duration: Long
                                        , previous_active_duration: Long
                                        , category: Long
                                        , wheel_key: String
                                        , vehicle_key: String
                                        , odometer: Integer
                                        , odometer_total: Integer
                                        , odometer_miles: Double
                                        , odometer_total_miles: Double
                                        , distance_travel_with_alert: Double
                                        , distance_travelled: Double
                                        , asset_wheel_config_key: String
                                        , topic: String
                                        , topic_id: String
                                        , temperature_f: Double
                                        , pressure_psi: Double
                                        , battery_status: Double
                                        , last_updated: java.sql.Timestamp
                                      )

case class ArchivedProcessedWheelWarningRecord(
                                        service: String
                                        , reported_time:  java.sql.Timestamp
                                        , alert_start_time:  java.sql.Timestamp
                                        , alert_end_time:  java.sql.Timestamp
                                        , event_start_time: java.sql.Timestamp
                                        , schema_version: String
                                        , resource: String
                                        , location: String
                                        , location_name: String
                                        , device_id: String
                                        , asset_id: String
                                        , asset_code: String
                                        , device_name: String
                                        , company: String
                                        , fleet: String
                                        , wheel_config: String
                                        , image_url: String
                                        , no_axles: String
                                        , asset_name: String
                                        , pipeline_timestamp:  java.sql.Timestamp
                                        , consumed_timestamp:  Long
                                        , active:Int
                                        , alert_name:String
                                        , alert_id:Long
                                        , duration:  Long
                                        , previous_active_duration: Long
                                        , category: Long
                                        , wheel_key: String
                                        , vehicle_key: String
                                        , odometer: Integer
                                        , odometer_total: Integer
                                        , odometer_miles: Double
                                        , odometer_total_miles: Double
                                        , distance_travel_with_alert: Double
                                        , distance_travelled: Double
                                        , asset_wheel_config_key: String
                                        , topic: String
                                        , topic_id: String
                                        , temperature_f: Double
                                        , pressure_psi: Double
                                        , battery_status: Double
                                        , last_updated: java.sql.Timestamp
                                        , run_date: Long
                                      )

case class ProcessedWheelRecord(
                                 service: String
                                 , reported_time:  java.sql.Timestamp
                                 , schema_version: String
                                 , location: String
                                 , location_name: String
                                 , device_id: String
                                 , asset_id: String
                                 , asset_code: String
                                 , device_name: String
                                 , company: String
                                 , fleet: String
                                 , wheel_config: String
                                 , image_url: String
                                 , no_axles: String
                                 , asset_name: String
                                 , pipeline_timestamp:  java.sql.Timestamp
                                 , consumed_timestamp:  Long
                                 , measured_temperature_c:  Double
                                 , measured_temperature_f:  Double
                                 , measured_temperature:  Double
                                 , low_temperature_value: Double
                                 , extra_low_temperature_value: Double
                                 , normal_temperature_value: Double
                                 , battery_status: Int
                                 , measured_pressure: Double
                                 , measured_pressure_psi: Double
                                 , low_pressure_value: Double
                                 , extra_low_pressure_value: Double
                                 , normal_pressure_value: Double
                                 , temp_comp:  Double
                                 , wheel_key: String
                                 , vehicle_key: String
                                 , asset_wheel_config_key: String
                                 , topic: String
                                 , topic_id: String
                                 , last_updated: java.sql.Timestamp
                               )

case class ArchivedProcessedWheelRecord(
                                 service: String
                                 , reported_time:  java.sql.Timestamp
                                 , schema_version: String
                                 , location: String
                                 , location_name: String
                                 , device_id: String
                                 , asset_id: String
                                 , asset_code: String
                                 , device_name: String
                                 , company: String
                                 , fleet: String
                                 , wheel_config: String
                                 , image_url: String
                                 , no_axles: String
                                 , asset_name: String
                                 , pipeline_timestamp:  java.sql.Timestamp
                                 , consumed_timestamp:  Long
                                 , measured_temperature_c:  Double
                                 , measured_temperature_f:  Double
                                 , measured_temperature:  Double
                                 , low_temperature_value: Double
                                 , extra_low_temperature_value: Double
                                 , normal_temperature_value: Double
                                 , battery_status: Int
                                 , measured_pressure: Double
                                 , measured_pressure_psi: Double
                                 , low_pressure_value: Double
                                 , extra_low_pressure_value: Double
                                 , normal_pressure_value: Double
                                 , temp_comp:  Double
                                 , wheel_key: String
                                 , vehicle_key: String
                                 , asset_wheel_config_key: String
                                 , topic: String
                                 , topic_id: String
                                 , last_updated: java.sql.Timestamp
                                 , run_date: Long
                               )

case class ProcessedWheelWarningAggRecord(
                                           service: String
                                           , resource: String
                                           , reported_time:  java.sql.Timestamp
                                           , location: String
                                           , location_name: String
                                           , device_id: String
                                           , asset_id: String
                                           , asset_code: String
                                           , device_name: String
                                           , company: String
                                           , fleet: String
                                           , wheel_config: String
                                           , image_url: String
                                           , no_axles: String
                                           , asset_name: String
                                           , pipeline_timestamp:  java.sql.Timestamp
                                           , consumed_timestamp:  Long
                                           , max_alert_datetime: java.sql.Timestamp
                                           , min_alert_datetime: java.sql.Timestamp
                                           , active_alerts:Int
                                           , total_alerts:Int
                                           , alert_name:String
                                           , wheel_key: String
                                           , asset_wheel_config_key: String
                                           , no_of_datapoints: Int
                                           , topic: String
                                           , topic_id: String
                                           , last_updated: java.sql.Timestamp
                                         )

case class ProcessedGPSRecord (
                               service: String
                               , device_id: String
                               , asset_id: String
                               , asset_code: String
                               , device_name: String
                               , company: String
                               , fleet: String
                               , asset_name: String
                               , wheel_config: String
                               , image_url: String
                               , no_axles: String
                               , reported_time:  java.sql.Timestamp
                               , schema_version: String
                               , pipeline_timestamp:  java.sql.Timestamp
                               , consumed_timestamp:  Long
                               , latitude: Double
                               , longitude: Double
                               , altitude: Int
                               , gps_timestamp:  java.sql.Timestamp
                               , measured_speed: Int
                               , measured_heading: Int
                               , odometer: Int
                               , odometer_total: Int
                               , odometer_in_miles: Double
                               , odometer_total_in_miles: Double
                               , atis_state: String
                               , ttl_active: String
                               , kl15_pin_state: Int
                               , atis_reported_time: java.sql.Timestamp
                               , device_has_alerts: Int
                               , alerts_duration_hrs: Double
                               , active_trip: Int
                               , distance_travelled: Double
                               , active_duration: Double
                               , total_duration: Double
                               , total_distance_travelled: Double
                               , moving: String
                               , vehicle_key: String
                               , topic: String
                               , topic_id: String
                               , last_updated: java.sql.Timestamp
                             )

case class ArchivedProcessedGPSRecord(
                               service: String
                               , device_id: String
                               , asset_id: String
                               , asset_code: String
                               , device_name: String
                               , company: String
                               , fleet: String
                               , asset_name: String
                               , wheel_config: String
                               , image_url: String
                               , no_axles: String
                               , reported_time:  java.sql.Timestamp
                               , schema_version: String
                               , pipeline_timestamp:  java.sql.Timestamp
                               , consumed_timestamp:  Long
                               , latitude: Double
                               , longitude: Double
                               , altitude: Int
                               , gps_timestamp:  java.sql.Timestamp
                               , measured_speed: Int
                               , measured_heading: Int
                               , odometer: Int
                               , odometer_total: Int
                               , odometer_in_miles: Double
                               , odometer_total_in_miles: Double
                               , atis_state: String
                               , ttl_active: String
                               , kl15_pin_state: Int
                               , atis_reported_time: java.sql.Timestamp
                               , device_has_alerts: Int
                               , alerts_duration_hrs: Double
                               , active_trip: Int
                               , distance_travelled: Double
                               , active_duration: Double
                               , total_duration: Double
                               , total_distance_travelled: Double
                               , moving: String
                               , vehicle_key: String
                               , topic: String
                               , topic_id: String
                               , last_updated: java.sql.Timestamp
                               , run_date: Long
                             )

case class DashBoardWheelAlertRecordCurrent(
                                             service: String
                                             , resource: String
                                             , reported_time:  java.sql.Timestamp
                                             , location: String
                                             , location_name: String
                                             , device_id: String
                                             , asset_id: Long
                                             , asset_code: String
                                             , device_name: String
                                             , company: String
                                             , fleet: String
                                             , wheel_config: String
                                             , image_url: String
                                             , no_axles: String
                                             , asset_name: String
                                             , pipeline_timestamp:  java.sql.Timestamp
                                             , consumed_timestamp:  Long
                                             , max_alert_datetime: java.sql.Timestamp
                                             , min_alert_datetime: java.sql.Timestamp
                                             , active_alerts:Int
                                             , total_alerts:Int
                                             , alert_name:String
                                             , wheel_key: String
                                             , vehicle_key: String
                                             , asset_wheel_config_key: String
                                             , pressure_psi: Double         // disable until DB ready
                                             , temperature_f: Double        // disable until DB ready
                                             , no_of_datapoints: Int
                                             , last_updated: java.sql.Timestamp
                                           )
case class DashBoardWheelAlertRecord (
                                       service: String
                                       , reported_time:  java.sql.Timestamp
                                       , schema_version: String
                                       , resource: String
                                       , location: String
                                       , location_name: String
                                       , device_id: String
                                       , asset_id: Long
                                       , asset_code: String
                                       , device_name: String
                                       , company: String
                                       , fleet: String
                                       , wheel_config: String
                                       , image_url: String
                                       , no_axles: String
                                       , asset_name: String
                                       , pipeline_timestamp:  java.sql.Timestamp
                                       , consumed_timestamp:  Long
                                       , active:Int
                                       , alert_name:String
                                       , alert_id: Long
                                       , duration:  Long
                                       , previous_active_duration: Long
                                       , category: Long
                                       , wheel_key: String
                                       , vehicle_key: String
                                       , asset_wheel_config_key: String
                                       , pressure_psi: Double
                                       , temperature_f: Double
                                       , battery_status: Double
                                       , last_updated: java.sql.Timestamp
                                     )

case class DashBoardWheelRecord(
                                 service: String
                                 , reported_time:  java.sql.Timestamp
                                 , schema_version: String
                                 , location: String
                                 , location_name: String
                                 , device_id: String
                                 , asset_id: Long
                                 , asset_code: String
                                 , device_name: String
                                 , company: String
                                 , fleet: String
                                 , wheel_config: String
                                 , image_url: String
                                 , no_axles: String
                                 , asset_name: String
                                 , pipeline_timestamp:  java.sql.Timestamp
                                 , consumed_timestamp:  Long
                                 , measured_temperature_c:  Double
                                 , measured_temperature_f:  Double
                                 , measured_temperature:  Double
                                 , low_temperature_value: Double
                                 , extra_low_temperature_value: Double
                                 , normal_temperature_value: Double
                                 , battery_status: Int
                                 , measured_pressure: Double
                                 , measured_pressure_psi: Double
                                 , low_pressure_value: Double
                                 , extra_low_pressure_value: Double
                                 , normal_pressure_value: Double
                                 , temp_comp:  Double
                                 , wheel_key: String
                                 , vehicle_key: String
                                 , asset_wheel_config_key: String
                                 , last_updated: java.sql.Timestamp
                               )

case class DashBoardWheelRecordCurrent(
                                    service: String
                                    , location: String
                                    , location_name: String
                                    , device_id: String
                                    , asset_id: Long
                                    , asset_code: String
                                    , device_name: String
                                    , company: String
                                    , fleet: String
                                    , asset_name: String
                                    , wheel_config: String
                                    , image_url: String
                                    , no_axles: String
                                    , reported_time:  java.sql.Timestamp
                                    , pipeline_timestamp:  java.sql.Timestamp
                                    , consumed_timestamp:  Long
                                    , max_measured_temperature:  Double
                                    , min_measured_temperature:  Double
                                    , avg_measured_temperature:  Double
                                    , low_temperature_value: Double
                                    , extra_low_temperature_value: Double
                                    , normal_temperature_value: Double
                                    , max_battery_status: Int
                                    , min_battery_status: Int
                                    , avg_battery_status: Double
                                    , max_measured_pressure: Double
                                    , min_measured_pressure: Double
                                    , avg_measured_pressure: Double
                                    , low_pressure_value: Double
                                    , extra_low_pressure_value: Double
                                    , normal_pressure_value: Double
                                    , max_temp_comp:  Double
                                    , min_temp_comp:  Double
                                    , avg_temp_comp:  Double
                                    , wheel_key: String
                                    , vehicle_key: String
                                    , asset_wheel_config_key: String
                                    , no_of_datapoints: Int
                                    , last_updated: java.sql.Timestamp
                                  )

case class DashBoardVehicleRecordCurrent(
                               service: String
                               , device_id: String
                               , asset_id: Long
                               , asset_code: String
                               , device_name: String
                               , company: String
                               , fleet: String
                               , asset_name: String
                               , wheel_config: String
                               , image_url: String
                               , no_axles: String
                               , reported_time:  java.sql.Timestamp
                               , schema_version: String
                               , pipeline_timestamp:  java.sql.Timestamp
                               , consumed_timestamp:  Long
                               , latitude: Double
                               , longitude: Double
                               , altitude: Int
                               , gps_timestamp:  java.sql.Timestamp
                               , measured_speed: Int
                               , measured_heading: Int
                               , odometer: Int
                               , odometer_total: Int
                               , odometer_in_miles: Double
                               , odometer_total_in_miles: Double
                               , atis_state: String                     // disable until DB ready
                               , ttl_active: String                     // disable until DB ready
                               , kl15_pin_state: Int                    // disable until DB ready
                               , atis_reported_time: java.sql.Timestamp // disable until DB ready
                               , device_has_alerts: Int
                               , alerts_duration_hrs: Double
                               , vehicle_key: String
                               , last_updated: java.sql.Timestamp
                             )

case class DashBoardVehicleRecordHistory(
                            service: String
                            ,device_id: String
                            , asset_id: Long
                            , asset_code: String
                            , device_name: String
                            , company: String
                            , fleet: String
                            , asset_name: String
                            , wheel_config: String
                            , image_url: String
                            , no_axles: String
                            , reported_time:  java.sql.Timestamp
                            , last_active_reported_time: java.sql.Timestamp
                            , last_known_latitude: Double
                            , last_known_longitude: Double
                            , last_known_altitude: Double
                            , last_known_speed: Int
                            , last_known_heading: Int
                            , first_active_reported_time: java.sql.Timestamp
                            , first_known_latitude: Double
                            , first_known_longitude: Double
                            , first_known_altitude: Double
                            , first_known_speed: Int
                            , first_known_heading: Int
                            , no_of_trips: Int
                            , distance_travelled: Double
                            , hrs_active: Double
                            , no_of_datapoints: Int
                            , vehicle_key: String
                            , asset_wheel_config_key: String
                            , reported_time_dashboard_format: String
                            , reported_time_dashboard_group: String
                            , is_last_device_record: Int
                            , device_has_alerts: Int
                            , last_updated: java.sql.Timestamp
                            , frequency: String
                            , run_period:String
                          )

case class DashBoardVehicleRecordHistoryNew(
                                          service: String
                                          ,device_id: String
                                          , asset_id: Long
                                          , asset_code: String
                                          , device_name: String
                                          , company: String
                                          , fleet: String
                                          , asset_name: String
                                          , wheel_config: String
                                          , image_url: String
                                          , no_axles: String
                                          , reported_time:  java.sql.Timestamp
                                          , last_active_reported_time: java.sql.Timestamp
                                          , last_known_latitude: Double
                                          , last_known_longitude: Double
                                          , last_known_altitude: Double
                                          , last_known_speed: Long
                                          , last_known_heading: Long
                                          , first_active_reported_time: java.sql.Timestamp
                                          , first_known_latitude: Double
                                          , first_known_longitude: Double
                                          , first_known_altitude: Double
                                          , first_known_speed: Long
                                          , first_known_heading: Long
                                          , no_of_trips: Long
                                          , distance_travelled: Double
                                          , hrs_active: Double
                                          , no_of_datapoints: Long
                                          , vehicle_key: String
                                          , asset_wheel_config_key: String
                                          , reported_time_dashboard_format: String
                                          , reported_time_dashboard_group: String
                                          , is_last_device_record: Long
                                          , device_has_alerts: Long
                                          , last_updated: java.sql.Timestamp
                                          , frequency: String
                                          , run_period:String
                                        )

case class DashBoardWheelRecordHistory(
                                    service: String
                                    , location: String
                                    , location_name: String
                                    , device_id: String
                                    , asset_id: Long
                                    , asset_code: String
                                    , device_name: String
                                    , company: String
                                    , fleet: String
                                    , asset_name: String
                                    , wheel_config: String
                                    , image_url: String
                                    , no_axles: String
                                    , reported_time:  java.sql.Timestamp
                                    , max_measured_temperature: Double
                                    , min_measured_temperature: Double
                                    , avg_measured_temperature: Double
                                    , low_temperature_value: Double
                                    , extra_low_temperature_value: Double
                                    , normal_temperature_value: Double
                                    , max_battery_status: Int
                                    , min_battery_status: Int
                                    , avg_battery_status: Double
                                    , max_measured_pressure: Double
                                    , min_measured_pressure: Double
                                    , avg_measured_pressure: Double
                                    , low_pressure_value: Double
                                    , extra_low_pressure_value: Double
                                    , normal_pressure_value: Double
                                    , max_temp_comp:  Double
                                    , min_temp_comp:  Double
                                    , avg_temp_comp:  Double
                                    , wheel_key: String
                                    , vehicle_key: String
                                    , asset_wheel_config_key: String
                                    , no_of_datapoints: Int
                                    , reported_time_dashboard_format: String
                                    , reported_time_dashboard_group: String
                                    , is_last_device_record: Int
                                    , last_updated: java.sql.Timestamp
                                    , frequency: String
                                    , run_period:String
                                  )

case class DashBoardWheelRecordHistoryNew(
                                           service: String
                                           , location: String
                                           , location_name: String
                                           , device_id: String
                                           , device_name: String
                                           , company: String
                                           , fleet: String
                                           , asset_name: String
                                           , wheel_config: String
                                           , image_url: String
                                           , no_axles: String
                                           , reported_time:  java.sql.Timestamp
                                           , max_measured_temperature: Double
                                           , min_measured_temperature: Double
                                           , avg_measured_temperature: Double
                                           , max_battery_status: Long
                                           , min_battery_status: Long
                                           , avg_battery_status: Double
                                           , max_measured_pressure: Double
                                           , min_measured_pressure: Double
                                           , avg_measured_pressure: Double
                                           , max_temp_comp:  Double
                                           , min_temp_comp:  Double
                                           , avg_temp_comp:  Double
                                           , low_pressure_value: Double
                                           , extra_low_pressure_value: Double
                                           , normal_pressure_value: Double
                                           , high_pressure_value: Double
                                           , low_temperature_value: Double
                                           , extra_low_temperature_value: Double
                                           , normal_temperature_value: Double
                                           , high_temperature_value: Double
                                           , is_last_device_record: Int
                                           , reported_time_dashboard_format: String
                                           , reported_time_dashboard_group: String
                                           , no_of_datapoints: Int
                                           , wheel_key: String
                                           , vehicle_key: String
                                           , asset_wheel_config_key: String
                                           , last_updated: java.sql.Timestamp
                                           , run_period:String
                                           , frequency: String
                                           , asset_id: Long
                                           , asset_code: String

                                         )

case class DashBoardVehicleFactRecordHistory (
                                               service:String
                                               ,device_id:String
                                               ,date_id: Long
                                               ,time_id: String
                                               ,asset_id:Long
                                               ,asset_code:String
                                               ,device_name:String
                                               ,company:String
                                               ,fleet:String
                                               ,asset_name:String
                                               ,wheel_config:String
                                               ,image_url:String
                                               ,no_axles:String
                                               ,reported_time:java.sql.Timestamp
                                               ,schema_version:String
                                               ,pipeline_timestamp:java.sql.Timestamp
                                               ,latitude:Double
                                               ,longitude:Double
                                               ,altitude:Int
                                               ,gps_timestamp:java.sql.Timestamp
                                               ,measured_speed:Int
                                               ,measured_heading:Int
                                               ,odometer:Int
                                               ,odometer_total:Int
                                               ,odometer_in_miles:Double
                                               ,odometer_total_in_miles:Double
                                               ,device_has_alerts:Int
                                               ,alerts_duration_hrs:Double
                                               ,active_trip:Int
                                               ,distance_travelled:Double
                                               ,active_duration:Double
                                               ,total_duration:Double
                                               ,total_distance_travelled:Double
                                               ,moving:String
                                               ,vehicle_key:String
                                               ,consumed_timestamp:java.sql.Timestamp
                                               ,created_at: java.sql.Timestamp
                                             )

case class DashBoardVehicleFactRecordHistoryNew (
                                               service:String
                                               ,device_id:String
                                               ,date_id: Long
                                               ,time_id: String
                                               ,asset_id:Long
                                               ,asset_code:String
                                               ,device_name:String
                                               ,company:String
                                               ,fleet:String
                                               ,asset_name:String
                                               ,wheel_config:String
                                               ,image_url:String
                                               ,no_axles:String
                                               ,reported_time:java.sql.Timestamp
                                               ,schema_version:String
                                               ,pipeline_timestamp:java.sql.Timestamp
                                               ,latitude:Double
                                               ,longitude:Double
                                               ,altitude:Double
                                               ,gps_timestamp:java.sql.Timestamp
                                               ,measured_speed:Long
                                               ,measured_heading:Long
                                               ,odometer:Long
                                               ,odometer_total:Long
                                               ,odometer_in_miles:Double
                                               ,odometer_total_in_miles:Double
                                               ,device_has_alerts:Long
                                               ,alerts_duration_hrs:Double
                                               ,active_trip:Long
                                               ,distance_travelled:Double
                                               ,active_duration:Double
                                               ,total_duration:Double
                                               ,total_distance_travelled:Double
                                               ,moving:String
                                               ,vehicle_key:String
                                               ,consumed_timestamp:java.sql.Timestamp
                                               ,created_at: java.sql.Timestamp
                                             )

case class DashBoardWheelFactRecordHistory(
                                            service: String
                                            ,date_id: Long
                                            ,time_id: String
                                            ,device_id: String
                                            ,device_name: String
                                            ,wheel_id: String
                                            ,asset_id: Long
                                            ,asset_code: String
                                            ,asset_name: String
                                            ,reported_time: java.sql.Timestamp
                                            ,asset_wheel_config_key: String
                                            ,battery_status: Double
                                            ,company: String
                                            ,consumed_timestamp: java.sql.Timestamp
                                            ,extra_low_pressure_value: Double
                                            ,extra_low_temperature_value: Double
                                            ,fleet: String
                                            ,image_url: String
                                            ,wheel_location: String
                                            ,low_pressure_value: Double
                                            ,low_temperature_value: Double
                                            ,measured_pressure: Double
                                            ,measured_pressure_psi: Double
                                            ,measured_temperature: Double
                                            ,measured_temperature_c: Double
                                            ,measured_temperature_f: Double
                                            ,no_axles: String
                                            ,normal_pressure_value: Double
                                            ,normal_temperature_value: Double
                                            ,pipeline_timestamp: java.sql.Timestamp
                                            , temp_comp: Double
                                            , created_at: java.sql.Timestamp
                                      )
case class DashBoardWheelAlertFactRecordHistory(
                                                 alert_id: Long
                                                 , wheel_id: String
                                                 , date_id: Long
                                                 , time_id: String
                                                 , asset_id: Long
                                                 , alert_status: Int
                                                 , event_status: Int
                                                 , reported_time: java.sql.Timestamp
                                                 , alert_start_time: java.sql.Timestamp
                                                 , alert_end_time: java.sql.Timestamp
                                                 , event_start_time: java.sql.Timestamp
                                                 , event_stop_time: java.sql.Timestamp
                                                 , trip_start_time: java.sql.Timestamp
                                                 , trip_stop_time: java.sql.Timestamp
                                                 , first_active_reported_time: java.sql.Timestamp
                                                 , last_active_reported_time: java.sql.Timestamp
                                                 , alert_duration: Double
                                                 , event_duration: Double
                                                 , trip_duration: Double
                                                 , active_duration: Double
                                                 , alert_distance: Double
                                                 , trip_distance: Double
                                                 , alert_at_trip_start: Int
                                                 , measured_temperature: Double
                                                 , measured_pressure: Double
                                                 , asset_code: String
                                                 , resource: String
                                                 , wheel_location: String
                                                 , category: Int
                                                 , created_at: java.sql.Timestamp
                                                  )

case class DashBoardWheelAlertFactRecordHistoryNew(
                                                 alert_id: Long
                                                 , wheel_id: String
                                                 , date_id: Long
                                                 , time_id: String
                                                 , asset_id: Long
                                                 , alert_status: Long
                                                 , event_status: Int
                                                 , reported_time: java.sql.Timestamp
                                                 , alert_start_time: java.sql.Timestamp
                                                 , alert_end_time: java.sql.Timestamp
                                                 , event_start_time: java.sql.Timestamp
                                                 , event_stop_time: java.sql.Timestamp
                                                 , trip_start_time: java.sql.Timestamp
                                                 , trip_stop_time: java.sql.Timestamp
                                                 , first_active_reported_time: java.sql.Timestamp
                                                 , last_active_reported_time: java.sql.Timestamp
                                                 , alert_duration: Double
                                                 , event_duration: Double
                                                 , trip_duration: Double
                                                 , active_duration: Double
                                                 , alert_distance: Double
                                                 , trip_distance: Double
                                                 , alert_at_trip_start: Int
                                                 , measured_temperature: Double
                                                 , measured_pressure: Double
                                                 , asset_code: String
                                                 , resource: String
                                                 , wheel_location: String
                                                 , category: Long
                                                 , created_at: java.sql.Timestamp
                                                 , battery_status: Long
                                               )

case class DashBoardWheelWarningRecordHistory(
                                 service: String
                                 , resource: String
                                 , location: String
                                 , location_name: String
                                 , alert_name: String
                                 , alert_id: Long
                                 , device_id: String
                                 , asset_id: Long
                                 , asset_code: String
                                 , device_name: String
                                 , company: String
                                 , fleet: String
                                 , asset_name: String
                                 , wheel_config: String
                                 , image_url: String
                                 , no_axles: String
                                 , reported_time:  java.sql.Timestamp
                                 , total_alerts: Int
                                 , alert_duration_hrs: Double
                                 , battery_status: Double
                                 , alert_distance: Double
                                 , max_alert_type_duration_hrs: Double
                                 , max_alert_type_distance_miles: Double
                                 , no_of_active_alerts_msg: Int
                                 , no_of_inactive_alerts_msg: Int
                                 , on_alert_duration: Long
                                 , on_alert_previous_active_duration: Long
                                 , off_alert_duration: Long
                                 , off_alert_previous_active_duration: Long
                                 , on_alerts_first_reported_time: java.sql.Timestamp
                                 , on_alerts_last_reported_time: java.sql.Timestamp
                                 , off_alerts_first_reported_time: java.sql.Timestamp
                                 , off_alerts_last_reported_time: java.sql.Timestamp
                                 , wheel_key: String
                                 , vehicle_key: String
                                 , asset_wheel_config_key: String
                                 , no_of_datapoints: Int
                                 , reported_time_dashboard_format: String
                                 , reported_time_dashboard_group: String
                                 , is_last_device_record: Int
                                 , last_updated: java.sql.Timestamp
                                 , frequency: String
                                 , run_period:String
                               )

case class DashBoardWheelWarningRecordHistoryNew(
                                               service: String
                                               , resource: String
                                               , location: String
                                               , location_name: String
                                               , alert_name: String
                                               , alert_id: Long
                                               , device_id: String
                                               , asset_id: Long
                                               , asset_code: String
                                               , device_name: String
                                               , company: String
                                               , fleet: String
                                               , asset_name: String
                                               , wheel_config: String
                                               , image_url: String
                                               , no_axles: String
                                               , reported_time:  java.sql.Timestamp
                                               , total_alerts: Long
                                               , alert_duration_hrs: Double
                                               , battery_status: Double
                                               , alert_distance: Double
                                               , max_alert_type_duration_hrs: Double
                                               , max_alert_type_distance_miles: Double
                                               , no_of_active_alerts_msg: Int
                                               , no_of_inactive_alerts_msg: Int
                                               , on_alert_duration: Long
                                               , on_alert_previous_active_duration: Long
                                               , off_alert_duration: Long
                                               , off_alert_previous_active_duration: Long
                                               , on_alerts_first_reported_time: java.sql.Timestamp
                                               , on_alerts_last_reported_time: java.sql.Timestamp
                                               , off_alerts_first_reported_time: java.sql.Timestamp
                                               , off_alerts_last_reported_time: java.sql.Timestamp
                                               , wheel_key: String
                                               , vehicle_key: String
                                               , asset_wheel_config_key: String
                                               , no_of_datapoints: Int
                                               , reported_time_dashboard_format: String
                                               , reported_time_dashboard_group: String
                                               , is_last_device_record: Int
                                               , last_updated: java.sql.Timestamp
                                               , frequency: String
                                               , run_period:String
                                             )

case class LeakDetectionRecord(
                                     reported_time:  java.sql.Timestamp
                                   , asset_code: String
                                   , location_name: String
                                   , asset_id: String
                                   , device_id: String
                                   , time_to_failure_summed30: Double
                                   , alerttrigger: Int
                                   , last_updated: java.sql.Timestamp

                               )

case class LeakDetectionFactRecordHistory(
                                service: String
                                , reported_time:  java.sql.Timestamp
                                , date_id: Long
                                , time_id: String
                                , wheel_id: String
                                , device_id: String
                                , asset_id: Long
                                , asset_code: String
                                , time_to_failure_summed30: Double
                                , alerttrigger: Long
                                , created_at: java.sql.Timestamp
                                , wheel_location: String
                              )

case class WheelKeyMapping(
                           wheel_key: String
                         )

case class VehicleKeyMapping(
                              vehicle_key: String
                          )

case class AssetActivityNotification(
                                      asset_code: String
                                      , reported_time: java.sql.Timestamp
                                      , measured_speed: Int
                                      , measured_heading: Int
                                      , odometer: Double
                                      , odometer_total: Double
                                      , odometer_miles: Double
                                      , odometer_total_miles: Double
                                      , atis_state: String
                                      , atis_reported_time: java.sql.Timestamp
                                      , prev_reported_time: java.sql.Timestamp
                                      , prev_odometer: Double
                                      , prev_odometer_total: Double
                                      , prev_odometer_miles: Double
                                      , prev_odometer_total_miles: Double
                                      , prev_atis_reported_time: java.sql.Timestamp
                                      , prev_atis_state: String
                                      , active_trip: Int
                                      , distance_travelled: Double
                                      , active_duration: Double
                                      , total_duration: Double
                                      , total_distance_travelled: Double
                                      , ttl_active: String
                                      , kl15_pin_state: Int
                                      , moving: String
                                      , last_updated: java.sql.Timestamp
                                      , checkpoint_timestamp: Long
                                  )

case class ActiveAlertNotification(
                                    asset_code: String
                                    , asset_id: String
                                    , location: String
                                    , resource: String
                                    , active: Int
                                    , category: Int
                                    , reported_time:  java.sql.Timestamp
                                    , device_duration: Long
                                    , calc_duration: Long
                                    , est_duration: Long
                                    , odometer_miles: Double
                                    , odometer_total_miles: Double
                                    , distance_travel: Double
                                    , distance_travel_with_alert: Double
                                    , old_active: Int
                                    , old_category: Int
                                    , old_reported_time:  java.sql.Timestamp
                                    , old_odometer_miles: Double
                                    , old_odometer_total_miles: Double
                                    , old_distance_travel: Double
                                    , old_distance_travel_with_alert: Double
                                    , old_calc_duration: Long
                                    , event_start_time: java.sql.Timestamp
                                    , state_changed: String
                                    , last_updated:   java.sql.Timestamp
                                    , pressure: Double
                                    , pressure_psi: Double
                                    , temperature: Double
                                    , temperature_f: Double
                                    , battery_status: Double
                                    , temp_comp_pressure:Double
                                    , checkpoint_timestamp: Long
                                  )

case class ActiveAlertNotificationCache(
                                         spark_key: String
                                         , alert_state: String
                                         , asset_code: String
                                         , wheel_location: String
                                         , resource: String
                                         , last_updated: java.sql.Timestamp
                                       )

case class AssetActivityNotificationCache(
                                         spark_key: String
                                         , activity_state: String
                                         , asset_code: String
                                         , last_updated: java.sql.Timestamp
                                       )
