package com.sensata.data_office.batch.jobs

import com.sensata.data_office.data._
import com.typesafe.config.ConfigFactory
import com.typesafe.scalalogging.Logger
import org.apache.spark.sql.catalyst.ScalaReflection
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.slf4j.LoggerFactory

object BatchEventProcessor {


  val pipelineConfig = ConfigFactory
    .load(s"application.${sys.env("ENVIRONMENT")}.conf")
    .getConfig("EventProcessors").getConfig("pipeline")

  val dimentionalCfg = ConfigFactory
    .load(s"application.${sys.env("ENVIRONMENT")}.conf")
    .getConfig("dimensional_data")

  val batchCfg = ConfigFactory
    .load(s"application.${sys.env("ENVIRONMENT")}.conf")
    .getConfig("batch_pipeline")

  val VERSION = pipelineConfig.getString("version")

  val spark = SparkSession.builder.appName(pipelineConfig.getString("application_name")).getOrCreate()

  import spark.implicits._


  def processWheelBatch(WheelbatchDF: DataFrame, customer_dim: DataFrame, wheel_info: DataFrame): Dataset[ProcessedWheelRecord] = {

    val wheelMessage = WheelbatchDF

    val tempMessage = addTimeStampColumns(wheelMessage
      .where(get_json_object($"body" cast "string", "$.resource") === MessageTypes.WheelInfoTemperature)
      .select(
        from_json($"body" cast "string"
          , ScalaReflection.schemaFor[WheelInfoTemperature].dataType.asInstanceOf[StructType]
        ) as "events"
      ).select($"events.*")
    ).as[WheelInfoTemperature]

    val pressureMessage = addTimeStampColumns(wheelMessage
      .where(get_json_object($"body" cast "string", "$.resource") === MessageTypes.WheelInfoPressure)
      .select(
        from_json($"body" cast "string"
          , ScalaReflection.schemaFor[WheelInfoPressure].dataType.asInstanceOf[StructType]
        ) as "events"
      ).select($"events.*")
    ).as[WheelInfoPressure]

    val battMessage = addTimeStampColumns(wheelMessage
      .where(get_json_object($"body" cast "string", "$.resource") === MessageTypes.WheelInfoBattery)
      .select(
        from_json($"body" cast "string"
          , ScalaReflection.schemaFor[WheelInfoBattery].dataType.asInstanceOf[StructType]
        ) as "events"
      ).select($"events.*")
    ).as[WheelInfoBattery]


    // merge the wheel info streams to get a flat table
    // ToDo:: replace with full out join
    val wheelInfo = tempMessage.as("temp").join(
      pressureMessage.as("pres")
      , (
        ($"temp.device_id" === $"pres.device_id") &&
          ($"temp.data.location" === $"pres.data.location") &&
          (abs((($"temp.time" cast "long") - ($"pres.time" cast "long"))) < lit(300))

        )
    ).join(
      battMessage.as("batt")
      , (
        ($"temp.device_id" === $"batt.device_id") &&
          ($"temp.data.location" === $"batt.data.location") &&
          (abs((($"temp.time" cast "long") - ($"batt.time" cast "long"))) < lit(300))

        )
    ).select(
      concat_ws("-", $"temp.service", lit("curated")) as "service"
      , $"temp.device_id"
      , $"temp.device_name"
      , $"temp.time" cast "timestamp" as "reported_time"
      , $"temp.data.location" cast "string" as "location"
      , $"temp.version" as "schema_version"
      , $"temp.timestamp" cast "timestamp" as "pipeline_timestamp"
      , $"temp.consumed_timestamp" cast "long" as "consumed_timestamp"
      , $"temp.data.temperature" cast "double" as "measured_temperature"
      , $"batt.data.battery" cast "integer" as "battery_status"
      , $"pres.data.pressure.measured" cast "double" as "measured_pressure"
      , $"pres.data.pressure.temp_comp" cast "double" as "temp_comp"
    ).join(
      customer_dim
      , Seq("device_id")
      , "left"
    ).join(
      wheel_info
      , Seq("company_asset_name", "location")
      , "left"
    )
      .withColumn("company", $"company_name")
      .withColumn("fleet", $"fleet_name")
      .withColumn("asset_name", $"company_asset_name")
      .withColumn("wheel_config", $"v_wheel_config")
      .withColumn("no_axles", $"v_no_axles")
      .withColumn("location_name", $"wheel_location_name")
      .withColumn("last_updated"
        , to_timestamp(
          from_unixtime(unix_timestamp(), "yyyy-MM-dd HH:mm:ss")
        )
      )
      .as[ProcessedWheelRecord]

    wheelInfo
  }

  def processGnssBatch(GpsbatchDF: DataFrame, customer_dim: DataFrame): Dataset[ProcessedGPSRecord] = {

    val gnssMessage = GpsbatchDF


    // get the GPS data
    val posData = addTimeStampColumns(gnssMessage
      .where(get_json_object($"body" cast "string", "$.resource") === MessageTypes.GnssPos)
      .select(
        from_json($"body" cast "string"
          , ScalaReflection.schemaFor[VehicleGnssPos].dataType.asInstanceOf[StructType]
        ) as "events"
      ).select($"events.*")
    )
      .as[VehicleGnssPos]
      .withColumn("latitude", $"data.latitude" cast "double")
      .withColumn("longitude", $"data.longitude" cast "double")
      .withColumn("altitude", $"data.altitude" cast "double")

    val timeData = addTimeStampColumns(gnssMessage
      .where(get_json_object($"body" cast "string", "$.resource") === MessageTypes.GnssTime)
      .select(
        from_json($"body" cast "string"
          , ScalaReflection.schemaFor[VehicleGnssTime].dataType.asInstanceOf[StructType]
        ) as "events"
      ).select($"events.*")
    ).as[VehicleGnssTime]
      .withColumn("gps_time", ($"data.time" / 1000) cast "timestamp")

    val velData = addTimeStampColumns(gnssMessage
      .where(get_json_object($"body" cast "string", "$.resource") === MessageTypes.GnssVelocity)
      .select(
        from_json($"body" cast "string"
          , ScalaReflection.schemaFor[VehicleGnssVelocity].dataType.asInstanceOf[StructType]
        ) as "events"
      ).select($"events.*")
    ).as[VehicleGnssVelocity]
      .withColumn("speed", $"data.speed" cast "integer")
      .withColumn("heading", $"data.heading" cast "integer")

    // merge the GPS data
    // ToDo:: replace with full out join
    val GpsDf = posData.alias("apos").join(
      velData.alias("avel")
      , (
        ($"apos.device_id" === $"avel.device_id")
          && (abs((($"apos.time" cast "long") - ($"avel.time" cast "long"))) < lit(300))

        )
      , "left"
    ).join(
      timeData.alias("atime")
      , (
        ($"apos.device_id" === $"atime.device_id")
          && (abs((($"apos.time" cast "long") - ($"atime.time" cast "long"))) < lit(300))
        )
      , "left"
    ).select(
      concat_ws("-", $"apos.service", lit("curated")) as "service"
      , $"apos.device_id"
      , $"apos.device_name"
      , $"apos.time" cast "timestamp" as "reported_time"
      , $"apos.version" as "schema_version"
      , $"apos.timestamp" cast "timestamp" as "pipeline_timestamp"
      , $"apos.consumed_timestamp" cast "long" as "consumed_timestamp"
      , $"apos.latitude" cast "double" as "latitude"
      , $"apos.longitude" cast "double" as "longitude"
      , $"apos.altitude" cast "integer" as "altitude"
      , when($"atime.device_id" isNotNull
        , $"atime.gps_time").otherwise(unix_timestamp() cast "timestamp") cast "timestamp" as "gps_timestamp"
      , when($"avel.device_id" isNotNull
        , $"avel.speed").otherwise(lit(0)) cast "integer" as "measured_speed"
      , when($"avel.device_id" isNotNull
        , $"avel.heading").otherwise(lit(0)) cast "integer" as "measured_heading"
    ).join(
      customer_dim
      , Seq("device_id")
      , "left"
    ).withColumn("company", $"company_name")
      .withColumn("fleet", $"fleet_name")
      .withColumn("asset_name", $"company_asset_name")
      .withColumn("wheel_config", $"v_wheel_config")
      .withColumn("no_axles", $"v_no_axles")
      .withColumn("last_updated"
        , to_timestamp(
          from_unixtime(unix_timestamp(), "yyyy-MM-dd HH:mm:ss")
        )
      ).as[ProcessedGPSRecord]

    GpsDf

  }

  def processWheelAlertsBatch(WheelbatchDF: DataFrame, customer_dim: DataFrame, wheel_info: DataFrame): Dataset[ProcessedWheelWarningRecord] = {

    val wheelMessage = WheelbatchDF

    val slowPressureAlert = addTimeStampColumns(wheelMessage
      .where(get_json_object($"body" cast "string", "$.resource") === MessageTypes.WarningEventPressure)
      .select(
        from_json($"body" cast "string"
          , ScalaReflection.schemaFor[WarningEventPressure].dataType.asInstanceOf[StructType]
        ) as "events"
      ).select($"events.*")
    )

    val fastPressureAlert = addTimeStampColumns(wheelMessage
      .where(get_json_object($"body" cast "string", "$.resource") === MessageTypes.WarningEventFastPressureLoss)
      .select(
        from_json($"body" cast "string"
          , ScalaReflection.schemaFor[WarningEventFastPressureLoss].dataType.asInstanceOf[StructType]
        ) as "events"
      ).select($"events.*")
    )

    val typeBurstAlert = addTimeStampColumns(wheelMessage
      .where(get_json_object($"body" cast "string", "$.resource") === MessageTypes.WarningEventTyreBurst)
      .select(
        from_json($"body" cast "string"
          , ScalaReflection.schemaFor[WarningEventTyreBurst].dataType.asInstanceOf[StructType]
        ) as "events"
      ).select($"events.*")
    )

    val temperatureAlert = addTimeStampColumns(wheelMessage
      .where(get_json_object($"body" cast "string", "$.resource") === MessageTypes.WheelWarningTemperature)
      .select(
        from_json($"body" cast "string"
          , ScalaReflection.schemaFor[WheelWarningTemperature].dataType.asInstanceOf[StructType]
        ) as "events"
      ).select($"events.*")
    )

    // merge the wheel alert streams to get a flat table
    val wheeAlerts = slowPressureAlert
      .union(fastPressureAlert)
      .union(typeBurstAlert)
      .union(temperatureAlert)
      .select(
        concat_ws("-", lit("alerts"), lit("curated")) as "service"
        , $"device_id"
        , $"device_name"
        , $"time" cast "timestamp" as "reported_time"
        , $"data.location" cast "string" as "location"
        , $"version" as "schema_version"
        , $"resource" as "alert_name"
        , $"timestamp" cast "timestamp" as "pipeline_timestamp"
        , $"consumed_timestamp" cast "long" as "consumed_timestamp"
        , when(lower($"data.event.active") isin("1", "true")
          , lit(1)).otherwise(lit(0)) cast "int" as "active"
        , $"data.event.duration" cast "int" as "duration"
        , $"data.event.previous_active_duration" cast "int" as "previous_active_duration"
        , $"data.event.category" cast "int" as "category"
      ).join(
      customer_dim
      , Seq("device_id")
      , "left"
    ).join(
      wheel_info
      , Seq("company_asset_name", "location")
      , "left"
    )
      .withColumn("company", $"company_name")
      .withColumn("fleet", $"fleet_name")
      .withColumn("asset_name", $"company_asset_name")
      .withColumn("wheel_config", $"v_wheel_config")
      .withColumn("no_axles", $"v_no_axles")
      .withColumn("location_name", $"wheel_location_name")
      .withColumn("last_updated"
        , to_timestamp(
          from_unixtime(unix_timestamp(), "yyyy-MM-dd HH:mm:ss")
        )
      )
      .as[ProcessedWheelWarningRecord]

    wheeAlerts
  }

  def addTimeStampColumns(df: DataFrame): DataFrame = {
    df
      .withColumn("timestamp", (($"timestamp" cast "long") / 1000) cast "timestamp")
      .withColumn("consumed_timestamp", $"consumed_timestamp" cast "long")
      .withColumn("time", (($"time" cast "long") / 1000) cast "timestamp")

  }

  def main(args: Array[String]) {

    val appLogger = Logger(LoggerFactory.getLogger("spark"))

    // Wheel name information
    val wheel_names_data = spark.read
      .format("delta")
      .load(dimentionalCfg.getString("wheel_naming_data"))
      .select($"Type" as "company_asset_name"
        , $"WheelPos" as "location"
        , $"WheelLocation" as "wheel_location_name"
      ).persist(StorageLevel.MEMORY_AND_DISK)

    // cache information regarding fleet and customers from DB
    val customer_data = spark.read
      .format("delta")
      .load(dimentionalCfg.getString("devices_to_customer_data"))
      .select($"device_id"
        , $"company_name"
        , $"fleet_name"
        , $"company_asset_name"
        , $"wheel_config" as "v_wheel_config"
        , $"no_axles" as "v_no_axles"
      )
      .persist(StorageLevel.MEMORY_AND_DISK)

    val AllMessage = spark
      .read
      .format("delta")
      .load(batchCfg.getString("src_data_path") + "processed_message")
      .persist(StorageLevel.MEMORY_AND_DISK)


    val wheelMessage = AllMessage
      .where(get_json_object($"body" cast "string", "$.service") === lit("tpms"))
      .select($"body", $"time")
    val gpsMessage = AllMessage
      .where(get_json_object($"body" cast "string", "$.service") === lit("gnss"))
      .select($"body", $"time")
    val alertMessage = AllMessage
      .where(get_json_object($"body" cast "string", "$.resource").contains(lit("events/warnings")))
      .select($"body", $"time")

    val wheelInfo = processWheelBatch(wheelMessage, customer_data, wheel_names_data)
    val gpsInfo = processGnssBatch(gpsMessage, customer_data)
    val warnInfo = processWheelAlertsBatch(alertMessage, customer_data, wheel_names_data)

    wheelInfo
      .withColumn("time"
        , from_unixtime($"reported_time" cast "long", "yyyy-MM-dd") as "time"
      )
      .repartition(50)
      .write
      .partitionBy("time")
      .format("delta")
      .mode("overwrite")
      .option("mergeSchema", "true")
      .save(batchCfg.getString("src_data_path") + "wheels_processed")
    gpsInfo
      .withColumn("time"
        , from_unixtime($"reported_time" cast "long", "yyyy-MM-dd") as "time"
      )
      .repartition(50)
      .write
      .partitionBy("time")
      .format("delta")
      .mode("overwrite")
      .option("mergeSchema", "true")
      .save(batchCfg.getString("src_data_path") + "gps_processed")
    warnInfo
      .withColumn("time"
        , from_unixtime($"reported_time" cast "long", "yyyy-MM-dd") as "time"
      )
      .repartition(50)
      .write
      .partitionBy("time")
      .format("delta")
      .mode("overwrite")
      .option("mergeSchema", "true")
      .save(batchCfg.getString("src_data_path") + "alerts_processed")
  }
}
