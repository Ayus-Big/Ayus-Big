package com.sensata.data_office.pipeline

import com.sensata.data_office.data.{ActiveAlertNotification, AssetActivityNotification, CustomerRoutingRecord}
import com.sensata.data_office.pipeline.queries.CachedDataProcessor.pipelineConfig
import com.sensata.data_office.pipeline.queries.{AssetActivityNotificationProcessor, CachedDataProcessor, CustomerDataPublisher, GnssEventProcessor, LakeDataLoader, RawEventsProcessor, WarningEventProcessor, WarningNotificationProcessor, WheelsEventProcessor, XirgoEventsProcessor}
import com.sensata.data_office.utilities.PipelineUtil
import com.sensata.data_office.utilities.PipelineUtil.{readDataFrameFromBlobStore, spark}
import org.apache.spark.sql.catalyst.ScalaReflection
import org.apache.spark.sql.functions.{col, concat_ws, lit, struct, to_json}
import org.apache.spark.sql.types.StructType
object StreamingPipeline {

  PipelineUtil.setKafkaSecrets(PipelineUtil.getEnvVariable("ENVIRONMENT") == "prod")
  PipelineUtil.setDBConnectString(PipelineUtil.getEnvVariable("ENVIRONMENT") == "prod")

  var alerts_kafka_offset = "earliest"
  var fedex_alerts_cache = PipelineUtil.spark.emptyDataFrame

  import PipelineUtil.spark.implicits._

  def main(args: Array[String]): Unit = {

    val customer_data = PipelineUtil.updateCustomerDimCacheFromDatabase()
      .as[CustomerRoutingRecord]

      PipelineUtil.writeDataFrameToKafkaTopic(customer_data
      .select(concat_ws("-", $"v_asset_code",$"device_id") as "key"
        , to_json(
          struct(customer_data.columns.map(col(_)): _*)
        ) as "value"
      ).coalesce(3)
      , "append"
      , PipelineUtil.kafkaConfig
      , pipelineConfig.getString("device_customer_routing_topic")
    )

    // Start Data processing Queries
    RawEventsProcessor.doRawEventProcessing();
    CachedDataProcessor.doCachedDataInvalidation();
    WheelsEventProcessor.doWheelEventProcessing();
    GnssEventProcessor.doGnssEventsProcessing();
    WarningEventProcessor.doAlertEventsProcessing();
    WarningNotificationProcessor.doNotificationEventsProcessing();
    AssetActivityNotificationProcessor.doNotificationEventsProcessing()
    XirgoEventsProcessor.doRawEventProcessing();


    // Start Data Loading Queries
    CustomerDataPublisher.doCustomerDatabasePush()
    LakeDataLoader.doDataLakeLoader()

  }
}
