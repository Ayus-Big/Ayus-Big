package com.sensata.data_office.batch.jobs

import com.sensata.data_office.batch.DashBoardDataPipeline._
import com.sensata.data_office.data._
import com.sensata.data_office.pipeline.queries.CustomerDataPublisher.asKafkaConnectJsonMessage
import com.sensata.data_office.utilities.Analytics._
import com.sensata.data_office.utilities.PipelineUtil
import com.sensata.data_office.utilities.PipelineUtil.{AlertHistory, VehicleHistory, WheelHistory}
import org.apache.spark.sql.catalyst.ScalaReflection
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{DateType, StructType}
import org.apache.spark.sql.{Column, DataFrame, Dataset, Row}
import org.apache.spark.storage.StorageLevel

import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

object DashBoardDataLoader {

  val current_snapshot_folder = LocalDateTime.now().format(
    DateTimeFormatter.ofPattern("yyyyMMddHH0000")
  )

  import PipelineUtil.spark.implicits._

  def loadWheelAlertEventsData(abatchDF: DataFrame, run_level: String): Unit = {

    abatchDF
      .repartition(20)
      .persist(StorageLevel.MEMORY_AND_DISK)

    val alert_event_schema = ScalaReflection.schemaFor[DashBoardWheelAlertFactRecordHistory].dataType.asInstanceOf[StructType]

    // store to datalake
    if (pipelineConfig.getBoolean("persist_local_copy")) {
      abatchDF
        /*.withColumn("run_date"
          , date_format(current_timestamp(), "yyyyMMddHH0000")
        )*/
        .write
        .partitionBy("asset_code")
        .format("parquet")
        .mode("overwrite")
        .option("mergeSchema", "true")
        .save(pipelineConfig.getString("dest_data_path") + s"wheel_alert_events/run_date=$current_snapshot_folder")
    }

     asKafkaConnectJsonMessage(selectNCastDataFrameAsSchema(abatchDF,alert_event_schema)
      , alert_event_schema
      , Seq( "location","resource","asset_code", "schema", "payload", "topic", "topic_id").toList
    )
      .select(concat_ws("-", $"resource",$"location",$"asset_code") as "key"
        , to_json(struct($"schema", $"payload")) as "value"
        , $"topic"
      )
      .coalesce(3)
      .write
      .format("kafka")
      .mode("append")
      .options(PipelineUtil.kafkaConfig)
      //.option("groupIdPrefix", pipelineConfig.getString("consumer_group"))
      .save()

    abatchDF.unpersist()

  }

  def loadWheelAlertData(abatchDF: DataFrame, run_level: String): Unit = {

    abatchDF.repartition(20).
    persist(StorageLevel.MEMORY_AND_DISK)

    val alert_schema = ScalaReflection.schemaFor[DashBoardWheelWarningRecordHistory].dataType.asInstanceOf[StructType]
    val alert_schema_new = ScalaReflection.schemaFor[DashBoardWheelWarningRecordHistoryNew].dataType.asInstanceOf[StructType]

    val dbatchDF = allocateAllRequiredRecords1(
      abatchDF
      , Seq("asset_code", "location", "alert_name", "reported_time_dashboard_format","reported_time","frequency", "topic", "topic_id")
      , alert_schema.filter(v => v.name != "is_last_device_record").map(v => {
        v.name -> v.dataType.simpleString
      }).toMap
      , run_level.split(" ")(1) == "Days"
      , run_level.split(" ")(0).toInt
      , run_level
      , Window.partitionBy("asset_code", "location", "alert_name")
      , spark
    )

    // set the last record flag for the row with the max reported_time by table key and reported_time_group
    val batchDF = flagLastDeviceHistoryRecord(
      dbatchDF.drop("rec_rank")
      , Option(Window.partitionBy("asset_code","location", "alert_name", "reported_time_dashboard_group"))
    )
    .persist(StorageLevel.MEMORY_AND_DISK)

    val cols_list = alert_schema_new.fields.toList.map(_.name)

   /* val sensdev_alert_df = AlertHistory(batchDF).filter($"asset_code".contains("SENSDEV"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[DashBoardWheelWarningRecordHistoryNew]
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_sensdev.getProperty("jdbcuri")
        ,s"data.wheel_alert_data_history_direct"
        , PipelineUtil.postgresdb_prop_sensdev
      )

    val staging_alert_df = AlertHistory(batchDF).filter($"asset_code".contains("STAGING"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[DashBoardWheelWarningRecordHistoryNew]
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_staging.getProperty("jdbcuri")
        ,s"data.wheel_alert_history_direct"
        , PipelineUtil.postgresdb_prop_staging
      )*/

    val sensprod_alert_df = AlertHistory(batchDF).filter($"asset_code".contains("SENSPROD"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[DashBoardWheelWarningRecordHistoryNew]
     // .repartition(10)
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_sensprod.getProperty("jdbcuri")
        ,s"data.wheel_alert_data_history_direct"
        , PipelineUtil.postgresdb_prop_sensprod
      )

    val fedx_alert_df = AlertHistory(batchDF).filter($"asset_code".contains("FEDX"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[DashBoardWheelWarningRecordHistoryNew]
     // .repartition(10)
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_fedx.getProperty("jdbcuri")
        ,s"data.wheel_alert_data_history_direct"
        , PipelineUtil.postgresdb_prop_fedx
      )

    val pnke_alert_df = AlertHistory(batchDF).filter($"asset_code".contains("PNKE"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[DashBoardWheelWarningRecordHistoryNew]
    // .repartition(10)
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_pnke.getProperty("jdbcuri")
        ,s"data.wheel_alert_data_history_direct"
        , PipelineUtil.postgresdb_prop_pnke
      )

    val wrnr_alert_df = AlertHistory(batchDF).filter($"asset_code".contains("WRNR"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[DashBoardWheelWarningRecordHistoryNew]
     // .repartition(10)
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_wrnr.getProperty("jdbcuri")
        ,s"data.wheel_alert_data_history_direct"
        , PipelineUtil.postgresdb_prop_wrnr
      )

    val ppsi_alert_df = AlertHistory(batchDF).filter($"asset_code".contains("PPSI"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[DashBoardWheelWarningRecordHistoryNew]
    //  .repartition(10)
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_ppsi.getProperty("jdbcuri")
        ,s"data.wheel_alert_data_history_direct"
        , PipelineUtil.postgresdb_prop_ppsi
      )

    val dske_alert_df = AlertHistory(batchDF).filter($"asset_code".contains("DSKE"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[DashBoardWheelWarningRecordHistoryNew]
     // .repartition(10)
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_dske.getProperty("jdbcuri")
        ,s"data.wheel_alert_data_history_direct"
        , PipelineUtil.postgresdb_prop_dske
      )

    val ryes_alert_df = AlertHistory(batchDF).filter($"asset_code".contains("RYES"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[DashBoardWheelWarningRecordHistoryNew]
    //  .repartition(10)
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_ryes.getProperty("jdbcuri")
        ,s"data.wheel_alert_data_history_direct"
        , PipelineUtil.postgresdb_prop_ryes
      )  

    // store to datalake
   if (pipelineConfig.getBoolean("persist_local_copy")) {
      batchDF
        .repartition(20)
        /*.withColumn("run_date"
          , date_format(current_timestamp(), "yyyyMMddHH0000")
        )*/
        .write
        .partitionBy("run_period")
        .format("parquet")
        .mode("overwrite")
        .option("mergeSchema", "true")
        .save(pipelineConfig.getString("dest_data_path") + s"wheel_alerts/run_date=$current_snapshot_folder")
    }

   /*   asKafkaConnectJsonMessage(selectNCastDataFrameAsSchema(batchDF,alert_schema)
      , alert_schema
      , Seq("run_period", "location","alert_name","reported_time_dashboard_format","asset_code", "schema", "payload", "topic", "topic_id").toList
    )
      .select(concat_ws("-", $"run_period",$"reported_time_dashboard_format",$"alert_name",$"location",$"asset_code") as "key"
        , to_json(struct($"schema", $"payload")) as "value"
        , $"topic"
      )
      .coalesce(3)
      .write
      .format("kafka")
      .mode("append")
      .options(PipelineUtil.kafkaConfig)
      //.option("groupIdPrefix", pipelineConfig.getString("consumer_group"))
      .save() */

    batchDF.unpersist()

  }

  def loadWheelData(abatchDF: DataFrame, run_level: String): Unit = {

    abatchDF.persist(StorageLevel.MEMORY_AND_DISK)

    val wheel_schema = ScalaReflection.schemaFor[DashBoardWheelRecordHistory].dataType.asInstanceOf[StructType]
    val wheel_schema_new = ScalaReflection.schemaFor[DashBoardWheelRecordHistoryNew].dataType.asInstanceOf[StructType]

    val dbatchDF = allocateAllRequiredRecords2(
      abatchDF
      , Seq("asset_code", "location", "reported_time_dashboard_format","reported_time", "frequency", "topic", "topic_id")
      , wheel_schema.filter(v => v.name != "is_last_device_record").map(v => {
        v.name -> v.dataType.simpleString
      }).toMap
      , run_level.split(" ")(1) == "Days"
      , run_level.split(" ")(0).toInt
      , run_level
      , Window.partitionBy("asset_code", "location")
      , spark
    )

    // set the last record flag for the row with the max reported_time by table key and reported_time_group
    val batchDF = flagLastDeviceHistoryRecord(
      dbatchDF.drop("rec_rank")
      , Option(Window.partitionBy("asset_code","location", "reported_time_dashboard_group"))
    )
    .persist(StorageLevel.MEMORY_AND_DISK)

    val cols_list = wheel_schema_new.fields.toList.map(_.name)

   /* val sensdev_wheel_df = WheelHistory(batchDF).filter($"asset_code".contains("SENSDEV"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[DashBoardWheelRecordHistoryNew]
      .dropDuplicates("location","asset_code","reported_time_dashboard_format","frequency")
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_sensdev.getProperty("jdbcuri")
        ,s"data.wheel_data_history_direct"
        , PipelineUtil.postgresdb_prop_sensdev
      )

    val staging_wheel_df = WheelHistory(batchDF).filter($"asset_code".contains("STAGING"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[DashBoardWheelRecordHistoryNew]
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_staging.getProperty("jdbcuri")
        ,s"data.wheel_data_history_direct"
        , PipelineUtil.postgresdb_prop_staging
      )*/

    val sensprod_wheel_df = WheelHistory(batchDF).filter($"asset_code".contains("SENSPROD"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[DashBoardWheelRecordHistoryNew]
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_sensprod.getProperty("jdbcuri")
        ,s"data.wheel_data_history_direct"
        , PipelineUtil.postgresdb_prop_sensprod
      )

    val fedx_wheel_df = WheelHistory(batchDF).filter($"asset_code".contains("FEDX"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[DashBoardWheelRecordHistoryNew]
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_fedx.getProperty("jdbcuri")
        ,s"data.wheel_data_history_direct"
        , PipelineUtil.postgresdb_prop_fedx
      )

    val pnke_wheel_df = WheelHistory(batchDF).filter($"asset_code".contains("PNKE"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[DashBoardWheelRecordHistoryNew]
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_pnke.getProperty("jdbcuri")
        ,s"data.wheel_data_history_direct"
        , PipelineUtil.postgresdb_prop_pnke
      )

    val dske_wheel_df = WheelHistory(batchDF).filter($"asset_code".contains("DSKE"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[DashBoardWheelRecordHistoryNew]
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_dske.getProperty("jdbcuri")
        ,s"data.wheel_data_history_direct"
        , PipelineUtil.postgresdb_prop_dske
      )

    val ryes_wheel_df = WheelHistory(batchDF).filter($"asset_code".contains("RYES"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[DashBoardWheelRecordHistoryNew]
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_ryes.getProperty("jdbcuri")
        ,s"data.wheel_data_history_direct"
        , PipelineUtil.postgresdb_prop_ryes
      )

    val ppsi_wheel_df = WheelHistory(batchDF).filter($"asset_code".contains("PPSI"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[DashBoardWheelRecordHistoryNew]
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_ppsi.getProperty("jdbcuri")
        ,s"data.wheel_data_history_direct"
        , PipelineUtil.postgresdb_prop_ppsi
      )

    val wrnr_wheel_df = WheelHistory(batchDF).filter($"asset_code".contains("WRNR"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[DashBoardWheelRecordHistoryNew]
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_wrnr.getProperty("jdbcuri")
        ,s"data.wheel_data_history_direct"
        , PipelineUtil.postgresdb_prop_wrnr
      )

    // store to datalake
    if (pipelineConfig.getBoolean("persist_local_copy")) {
      batchDF
        .repartition(20)
        .write
        .partitionBy( "run_period")
        .format("parquet")
        .mode("overwrite")
        .option("mergeSchema", "true")
        .save(pipelineConfig.getString("dest_data_path") + s"wheel/run_date=$current_snapshot_folder")
    }

   /*   asKafkaConnectJsonMessage(selectNCastDataFrameAsSchema(batchDF.toDF(),wheel_schema)
      , wheel_schema
      , Seq("run_period", "asset_code","location","run_period","reported_time_dashboard_format","schema", "payload", "topic", "topic_id").toList
    )
      .select(concat_ws("-", $"run_period",$"reported_time_dashboard_format",$"location",$"asset_code") as "key"
        , to_json(struct($"schema", $"payload")) as "value"
        , $"topic"
      )
      .coalesce(3)*/
   /*   .write
      .format("kafka")
      .mode("append")
      .options(PipelineUtil.kafkaConfig)
      //.option("groupIdPrefix", pipelineConfig.getString("consumer_group"))
      .save()*/

    batchDF.unpersist()

  }

  def loadVehicleData(abatchDF: DataFrame, run_level: String): Unit = {

    abatchDF.persist(StorageLevel.MEMORY_AND_DISK)

    val gps_schema = ScalaReflection.schemaFor[DashBoardVehicleRecordHistory].dataType.asInstanceOf[StructType]
    val gps_schema_new = ScalaReflection.schemaFor[DashBoardVehicleRecordHistoryNew].dataType.asInstanceOf[StructType]

    val dbatchDF = allocateAllRequiredRecords2(
      abatchDF
      , Seq("asset_code", "reported_time_dashboard_format","reported_time", "frequency", "topic", "topic_id")
      , gps_schema.filter(v => v.name != "is_last_device_record").map(v => {
        v.name -> v.dataType.simpleString
      }).toMap
      , run_level.split(" ")(1) == "Days"
      , run_level.split(" ")(0).toInt
      , run_level
      , Window.partitionBy("asset_code").orderBy(asc("agg_date"))
      , spark
    )

    // set the last record flag for the row with the max reported_time by table key and reported_time_group
    val batchDF = flagLastDeviceHistoryRecord(
      dbatchDF.drop("rec_rank")
      , Option(Window.partitionBy("asset_code", "reported_time_dashboard_group"))
    )
      .withColumn( "device_has_alerts"
        , when($"is_last_device_record" === lit(1)
          , when($"active_alerts" isNotNull, lit(1)).otherwise(lit(0))
        ).otherwise(lit(0))
      )
      .persist(StorageLevel.MEMORY_AND_DISK)
       
    val cols_list = gps_schema_new.fields.toList.map(_.name)

   /* val sensdev_vehicle_df = VehicleHistory(batchDF).filter($"asset_code".contains("SENSDEV"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[DashBoardVehicleRecordHistoryNew]
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_sensdev.getProperty("jdbcuri")
        ,s"data.vehicle_data_history_direct"
        , PipelineUtil.postgresdb_prop_sensdev
      )

    val staging_vehicle_df = VehicleHistory(batchDF).filter($"asset_code".contains("STAGING"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[DashBoardVehicleRecordHistoryNew]
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_staging.getProperty("jdbcuri")
        ,s"data.vehicle_data_history_direct"
        , PipelineUtil.postgresdb_prop_staging
      )*/

    val sensprod_vehicle_df = VehicleHistory(batchDF).filter($"asset_code".contains("SENSPROD"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[DashBoardVehicleRecordHistoryNew]
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_sensprod.getProperty("jdbcuri")
        ,s"data.vehicle_data_history_direct"
        , PipelineUtil.postgresdb_prop_sensprod
      )

    val fedx_vehicle_df = VehicleHistory(batchDF).filter($"asset_code".contains("FEDX"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[DashBoardVehicleRecordHistoryNew]
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_fedx.getProperty("jdbcuri")
        ,s"data.vehicle_data_history_direct"
        , PipelineUtil.postgresdb_prop_fedx
      )

    val pnke_vehicle_df = VehicleHistory(batchDF).filter($"asset_code".contains("PNKE"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[DashBoardVehicleRecordHistoryNew]
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_pnke.getProperty("jdbcuri")
        ,s"data.vehicle_data_history_direct"
        , PipelineUtil.postgresdb_prop_pnke
      )

    val dske_vehicle_df = VehicleHistory(batchDF).filter($"asset_code".contains("DSKE"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[DashBoardVehicleRecordHistoryNew]
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_dske.getProperty("jdbcuri")
        ,s"data.vehicle_data_history_direct"
        , PipelineUtil.postgresdb_prop_dske
      )

    val ryes_vehicle_df = VehicleHistory(batchDF).filter($"asset_code".contains("RYES"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[DashBoardVehicleRecordHistoryNew]
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_ryes.getProperty("jdbcuri")
        ,s"data.vehicle_data_history_direct"
        , PipelineUtil.postgresdb_prop_ryes
      )

    val ppsi_vehicle_df = VehicleHistory(batchDF).filter($"asset_code".contains("PPSI"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[DashBoardVehicleRecordHistoryNew]
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_ppsi.getProperty("jdbcuri")
        ,s"data.vehicle_data_history_direct"
        , PipelineUtil.postgresdb_prop_ppsi
      )

    val wrnr_vehicle_df = VehicleHistory(batchDF).filter($"asset_code".contains("WRNR"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[DashBoardVehicleRecordHistoryNew]
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_wrnr.getProperty("jdbcuri")
        ,s"data.vehicle_data_history_direct"
        , PipelineUtil.postgresdb_prop_wrnr
      )



    // store to datalake
    if (pipelineConfig.getBoolean("persist_local_copy")) {
      batchDF
        .repartition(20)
        /*.withColumn("run_date"
          , date_format(current_timestamp(), "yyyyMMddHH0000")
        )*/
        .write
        .partitionBy( "run_period")
        .format("parquet")
        .mode("overwrite")
        .option("mergeSchema", "true")
        .save(pipelineConfig.getString("dest_data_path") + s"vehicle/run_date=$current_snapshot_folder")
    }

   /*    asKafkaConnectJsonMessage(selectNCastDataFrameAsSchema(batchDF,gps_schema)
      , gps_schema
      , Seq("run_period", "asset_code", "schema", "reported_time_dashboard_format", "payload", "topic", "topic_id").toList
    )
      .select(concat_ws("-", $"run_period",$"reported_time_dashboard_format", $"asset_code") as "key"
        , to_json(struct($"schema", $"payload")) as "value"
        , $"topic"
      )
      .coalesce(3) */
     /* .write
      .format("kafka")
      .mode("append")
      .options(PipelineUtil.kafkaConfig)
      //.option("groupIdPrefix", pipelineConfig.getString("consumer_group"))
      .save()*/

    batchDF.unpersist()
  }

  def runDashBoardDataLoader(start_time_range: Column, end_time_range: Column, wheel_records: Dataset[Row], gps_records: Dataset[Row]
                             , alerts_records: Dataset[Row], alerts_snapshot_records: Dataset[Row], unit_of_run: String): Unit = {

    val lastupdated_timestamp = System.currentTimeMillis() / 1000

    val WheelsMessage = wheel_records
      .where(
        ($"reported_time" between(start_time_range, end_time_range))
      )
      .join(
        customer_data
        , Seq("device_id")
        , "left"
      )
      .drop("reported_device_id")
      .withColumn("asset_id", when($"v_asset_id" isNull, 0).otherwise($"v_asset_id"))
      .withColumn("asset_code", when($"v_asset_code" isNull, "N/A").otherwise($"v_asset_code"))
      .withColumn("company", when($"company_name" isNull, "N/A").otherwise($"company_name"))
      .withColumn("fleet", when($"fleet_name" isNull, "N/A").otherwise($"fleet_name"))
      .withColumn("asset_name", when($"company_asset_name" isNull, "N/A").otherwise($"company_asset_name"))
      .withColumn("wheel_config", when($"v_wheel_config" isNull, "N/A").otherwise($"v_wheel_config"))
      .withColumn("image_url", when($"v_image_url" isNull, "N/A").otherwise($"v_image_url"))
      .withColumn("topic_id", when($"v_topic_id" isNull, "all").otherwise($"v_topic_id"))
      .withColumn("topic", concat_ws("-", lit("all"), lit("wheel-dashboard")))
      .withColumn("no_axles", when($"v_no_axles" isNull, "0").otherwise($"v_no_axles"))
      .withColumn("location",upper($"location"))
      .withColumn("location_name", $"location")
      .withColumn("wheel_key", concat($"device_id", $"asset_name", $"location"))
      .withColumn("asset_wheel_config_key", concat($"asset_name", $"wheel_config"))
      .withColumn("image_url", when($"v_image_url" isNull, "N/A").otherwise($"v_image_url"))
      /*.withColumn("agg_date"
        , to_timestamp(
          from_unixtime($"reported_time" cast "long", run_config.getOrElse("unit_of_run", default_run_config)._6)
        )
      )*/
      .withColumn("agg_date", col("reported_time").cast(DateType))
      .persist(StorageLevel.MEMORY_AND_DISK)


    val alertsMessage = alerts_records
      .where(
        ($"reported_time" between(start_time_range, end_time_range))
      )
      .join(
        customer_data
        , Seq("device_id")
        , "left"
      )
      .drop("reported_device_id")
      .withColumn("asset_id", when($"v_asset_id" isNull, 0).otherwise($"v_asset_id"))
      .withColumn("asset_code", when($"v_asset_code" isNull, "N/A").otherwise($"v_asset_code"))
      .withColumn("company", when($"company_name" isNull, "N/A").otherwise($"company_name"))
      .withColumn("fleet", when($"fleet_name" isNull, "N/A").otherwise($"fleet_name"))
      .withColumn("asset_name", when($"company_asset_name" isNull, "N/A").otherwise($"company_asset_name"))
      .withColumn("wheel_config", when($"v_wheel_config" isNull, "N/A").otherwise($"v_wheel_config"))
      .withColumn("image_url", when($"v_image_url" isNull, "N/A").otherwise($"v_image_url"))
      .withColumn("topic_id", when($"v_topic_id" isNull, "all").otherwise($"v_topic_id"))
      .withColumn("topic", concat_ws("-", lit("all"), lit("alert-dashboard")))
      .withColumn("no_axles", when($"v_no_axles" isNull, "0").otherwise($"v_no_axles"))
      .withColumn("location",upper($"location"))
      .withColumn("location_name", $"location")
      .withColumn("wheel_key", concat($"device_id", $"asset_name", $"location"))
      .withColumn("asset_wheel_config_key", concat($"asset_name", $"wheel_config"))
        /*.withColumn("agg_date"
        , to_timestamp(
          from_unixtime($"reported_time" cast "long", run_config.getOrElse(unit_of_run, default_run_config)._6)
        )
      )*/
      .withColumn("agg_date", col("reported_time").cast(DateType))
      .withColumn("alert_name", setAlertNameValue())
      .persist(StorageLevel.MEMORY_AND_DISK)

    val GpsMessage = gps_records
     .where(
        ($"reported_time" between(start_time_range, end_time_range))
      )
      .join(
        customer_data
        , Seq("device_id")
        , "left"
      )
      .drop("reported_device_id")
      .withColumn("asset_id", when($"v_asset_id" isNull, 0).otherwise($"v_asset_id"))
      .withColumn("asset_code", when($"v_asset_code" isNull, "N/A").otherwise($"v_asset_code"))
      .withColumn("company", when($"company_name" isNull, "N/A").otherwise($"company_name"))
      .withColumn("fleet", when($"fleet_name" isNull, "N/A").otherwise($"fleet_name"))
      .withColumn("asset_name", when($"company_asset_name" isNull, "N/A").otherwise($"company_asset_name"))
      .withColumn("wheel_config", when($"v_wheel_config" isNull, "N/A").otherwise($"v_wheel_config"))
      .withColumn("image_url", when($"v_image_url" isNull, "N/A").otherwise($"v_image_url"))
      .withColumn("topic_id", when($"v_topic_id" isNull, "all").otherwise($"v_topic_id"))
      .withColumn("topic", concat_ws("-", lit("all"), lit("vehicle-dashboard")))
      .withColumn("no_axles", when($"v_no_axles" isNull, "0").otherwise($"v_no_axles"))
      /*.withColumn("agg_date"
        , to_timestamp(
          from_unixtime($"reported_time" cast "long", run_config.getOrElse(unit_of_run, default_run_config)._6)
        )
      )*/
      .withColumn("agg_date", col("reported_time").cast(DateType))
      .persist(StorageLevel.MEMORY_AND_DISK)


    // get list of customers to be processed
    val cust_list = WheelsMessage.select($"topic_id").dropDuplicates("topic_id")
      .union(
        GpsMessage.select($"topic_id").dropDuplicates("topic_id")
      ).union(
      alertsMessage.select($"topic_id").dropDuplicates("topic_id")
    )
      .withColumnRenamed("topic_id","customer")
      .dropDuplicates("customer")
      .persist(StorageLevel.MEMORY_AND_DISK)

   /* // get list of customers to be processed when confirmed then release
    val cust_list = WheelsMessage.select($"asset_code").dropDuplicates("asset_code")
      .union(
        GpsMessage.select($"asset_code").dropDuplicates("asset_code")
      ).union(
      alertsMessage.select($"asset_code").dropDuplicates("asset_code")
    )
      .filter(($"asset_code".isNotNull) && ($"asset_code" =!= "N/A"))
      .withColumn("customer", regexp_replace($"asset_code","[^A-Z]",""))
      .dropDuplicates("customer")
      .persist(StorageLevel.MEMORY_AND_DISK)*/

    /*println("***********************************cust_list******************************************")
    cust_list.show(false)*/



    // send starting message
    cust_list
    .withColumn("notification",lit("history-started"))
      .withColumn("datetime"
        ,to_timestamp(
          from_unixtime(lit(lastupdated_timestamp), "yyyy-MM-dd HH:mm:ss")
        )
      )
      .groupBy("notification").agg(
      collect_list("customer").as("customers")
      , first($"datetime", ignoreNulls = true) as "datetime"
    ).select($"notification" as "key"
      , to_json(
        struct(
          $"notification"
          , $"customers"
          , $"datetime"
        )
      ) as "value"
    )
      .write
      .format("kafka")
      .mode("append")
      .options(PipelineUtil.kafkaConfig)
      .option("topic", pipelineConfig.getString("batch-run-notifications"))
      .save()

    // process vehicle data
    val dfProcessed = addHoursActive(
      calculateMilesTravelled(
        addLastKnowLocationAndTime(addRecordRank(GpsMessage))
          .persist(StorageLevel.MEMORY_AND_DISK)

      )
    )
      .groupBy("asset_code", "agg_date").agg(
      first($"device_name", ignoreNulls = true) as "device_name"
      , first($"asset_id", ignoreNulls = true) as "asset_id"
      , first($"device_id", ignoreNulls = true) as "device_id"
      , first($"wheel_config", ignoreNulls = true) as "wheel_config"
      , first($"no_axles", ignoreNulls = true) as "no_axles"
      , first($"company", ignoreNulls = true) as "company"
      , first($"image_url", ignoreNulls = true) as "image_url"
      , first($"fleet", ignoreNulls = true) as "fleet"
      , first($"asset_name", ignoreNulls = true) as "asset_name"
      , first($"last_active_reported_time", ignoreNulls = true) as "last_active_reported_time"
      , first($"last_known_latitude", ignoreNulls = true) as "last_known_latitude"
      , first($"last_known_longitude", ignoreNulls = true) as "last_known_longitude"
      , first($"last_known_altitude", ignoreNulls = true) as "last_known_altitude"
      , first($"last_known_speed", ignoreNulls = true) as "last_known_speed"
      , first($"last_known_heading", ignoreNulls = true) as "last_known_heading"
      , first($"first_active_reported_time", ignoreNulls = true) as "first_active_reported_time"
      , first($"first_known_latitude", ignoreNulls = true) as "first_known_latitude"
      , first($"first_known_longitude", ignoreNulls = true) as "first_known_longitude"
      , first($"first_known_altitude", ignoreNulls = true) as "first_known_altitude"
      , first($"first_known_speed", ignoreNulls = true) as "first_known_speed"
      , first($"first_known_heading", ignoreNulls = true) as "first_known_heading"
      , first($"topic", ignoreNulls = true) as "topic"
      , first($"topic_id", ignoreNulls = true) as "topic_id"
      , sum($"distance_travelled") as "distance_travelled"
      , when(
        sum($"trip_started") === 0
        , lit(1)
      ).otherwise(sum($"trip_started")) as "no_of_trips"
      , sum($"Hrs_Active") as "hrs_active"
      , count($"device_name") cast "int" as "no_of_datapoints"
    )
      .withColumn("asset_wheel_config_key", concat($"asset_name", $"wheel_config"))
      .withColumn("service", lit("analytics-dashboard"))
      .withColumn("reported_time", $"agg_date")
      .withColumn("last_updated"
        , to_timestamp(
          from_unixtime(lit(lastupdated_timestamp), "yyyy-MM-dd HH:mm:ss")
        )
      )
      .withColumn("run_period", lit(unit_of_run.replace("  ", " ").replace(" ", "_")))
      .withColumn("reported_time_format"
        , when($"run_period" === "24_Hours"
          , hour(to_timestamp($"agg_date", run_config.getOrElse(unit_of_run, default_run_config)._6))
        ).otherwise(
          concat_ws("/",
            dayofmonth(to_timestamp($"agg_date", run_config.getOrElse(unit_of_run, default_run_config)._6))
            , month(to_timestamp($"agg_date", run_config.getOrElse(unit_of_run, default_run_config)._6))
          )
        )
      )
      .withColumn("rec_rank"
        , rank over Window.partitionBy("device_id").orderBy(asc("agg_date"))
      )
      .withColumn("frequency", lit(run_config.getOrElse(unit_of_run, default_run_config)._7))
      .withColumn("vehicle_key", concat($"device_id", $"asset_name", $"frequency"))
      .persist(StorageLevel.MEMORY_AND_DISK)

    val dashGpsDf = dfProcessed

    // process wheel data
    val dfProcessedWheel = addTpmsGroupingColumns(
      WheelsMessage
        .withColumn("measured_pressure_psi",
          when($"measured_pressure_psi" === -99
            , lit(null)
          ).otherwise($"measured_pressure_psi")
        )
        .withColumn("measured_temperature_f",
          when($"measured_temperature_f" === -99
            , lit(null)
          ).otherwise($"measured_temperature_f")
        )
      .groupBy("asset_code", "location", "agg_date").agg(
      first($"device_name", ignoreNulls = true) as "device_name"
      , first($"asset_id", ignoreNulls = true) as "asset_id"
      , first($"device_id", ignoreNulls = true) as "device_id"
      , first($"wheel_config", ignoreNulls = true) as "wheel_config"
      , first($"image_url", ignoreNulls = true) as "image_url"
      , first($"no_axles", ignoreNulls = true) as "no_axles"
      , first($"company", ignoreNulls = true) as "company"
      , first($"fleet", ignoreNulls = true) as "fleet"
      , first($"asset_name", ignoreNulls = true) as "asset_name"
      , first($"location_name", ignoreNulls = true) as "location_name"
      , max($"measured_temperature_f") cast "double" as "max_measured_temperature"
      , min($"measured_temperature_f") cast "double" as "min_measured_temperature"
      , avg($"measured_temperature_f") cast "double" as "avg_measured_temperature"
      , avg($"measured_temperature_f") cast "double" as "measured_temperature_f"
      , max($"battery_status") as "max_battery_status"
      , min($"battery_status") as "min_battery_status"
      , avg($"battery_status") cast "double" as "avg_battery_status"
      , max($"measured_pressure_psi") cast "double" as "max_measured_pressure"
      , min($"measured_pressure_psi") cast "double" as "min_measured_pressure"
      , avg($"measured_pressure_psi") cast "double" as "avg_measured_pressure"
      , avg($"measured_pressure_psi") cast "double" as "measured_pressure_psi"
      , max($"temp_comp") cast "double" as "max_temp_comp"
      , min($"temp_comp") cast "double" as "min_temp_comp"
      , avg($"temp_comp") cast "double" as "avg_temp_comp"
      , first($"topic", ignoreNulls = true) as "topic"
      , first($"topic_id", ignoreNulls = true) as "topic_id"
      , count($"device_name") cast "int" as "no_of_datapoints"
    ).withColumn("reported_time", $"agg_date")
      .withColumn("last_updated"
        , to_timestamp(
          from_unixtime(lit(lastupdated_timestamp), "yyyy-MM-dd HH:mm:ss")
        )
      )
      .withColumn("wheel_key", concat($"device_id", $"asset_name", $"location"))
      .withColumn("asset_wheel_config_key", concat($"asset_name", $"wheel_config"))
      .withColumn("service", lit("analytics-dashboard"))
      .withColumn("run_period", lit(unit_of_run.replace("  ", " ").replace(" ", "_")))
      .withColumn("reported_time_format"
        , when($"run_period" === "24_Hours"
          , hour(to_timestamp($"agg_date", run_config.getOrElse(unit_of_run, default_run_config)._6))
        ).otherwise(
          concat_ws("/",
            dayofmonth(to_timestamp($"agg_date", run_config.getOrElse(unit_of_run, default_run_config)._6))
            , month(to_timestamp($"agg_date", run_config.getOrElse(unit_of_run, default_run_config)._6))
          )
        )
      )
      .withColumn("rec_rank"
        , rank over Window.partitionBy("device_id", "location").orderBy(asc("agg_date"))
      )
      .withColumn("frequency", lit(run_config.getOrElse(unit_of_run, default_run_config)._7))
      .withColumn("vehicle_key", concat($"device_id", $"asset_name", $"frequency"))
      .withColumn("low_pressure_warning_active", lit(0))
      .withColumn("low_pressure_warning_total", lit(0))
      .withColumn("high_pressure_warning_active", lit(0))
      .withColumn("high_pressure_warning_total", lit(0))
      .withColumn("low_pressure_alert_active", lit(0))
      .withColumn("low_pressure_alert_total", lit(0))
      .withColumn("high_temperature_warning_active", lit(0))
      .withColumn("high_temperature_warning_total", lit(0))
      .withColumn("total_active_alerts", lit(0))
      .withColumn("total_alerts", lit(0))
    )

    val dashTpmsDf = dfProcessedWheel.drop("reported_time_format", "measured_temperature_f", "measured_pressure_psi")

    // process alerts
    val alertDf = addAlertFeatures_new( alertsMessage )
      .groupBy("asset_code", "location", "agg_date", "alert_name").agg(
      first($"resource", ignoreNulls = true) as "resource"
      , first($"asset_id", ignoreNulls = true) as "asset_id"
      , first($"device_id", ignoreNulls = true) as "device_id"
      , first($"device_name", ignoreNulls = true) as "device_name"
      , first($"wheel_config", ignoreNulls = true) as "wheel_config"
      , first($"image_url", ignoreNulls = true) as "image_url"
      , first($"no_axles", ignoreNulls = true) as "no_axles"
      , first($"company", ignoreNulls = true) as "company"
      , first($"fleet", ignoreNulls = true) as "fleet"
      , first($"asset_name", ignoreNulls = true) as "asset_name"
      , first($"location_name", ignoreNulls = true) as "location_name"
      , first($"battery_status", ignoreNulls = true) as "battery_status"
      , first($"total_on_alerts") as "total_alerts"
      , first($"total_on_alert_duration") / 3600 cast "int" as "alert_duration_hrs"
      , sum($"distance_travel_with_alert") as "alert_distance"
      , first("on_alerts_max_rank") as "no_of_active_alerts_msg"
      , first("off_alerts_max_rank") as "no_of_inactive_alerts_msg"
      , first("off_alerts_max_duration") as "off_alert_duration"
      , first("off_alerts_max_previous_active_duration") as "off_alert_previous_active_duration"
      , first("on_alerts_max_duration") as "on_alert_duration"
      , first("on_alerts_max_previous_active_duration") as "on_alert_previous_active_duration"
      , first("on_alerts_first_reported_time") as "on_alerts_first_reported_time"
      , first("on_alerts_last_reported_time") as "on_alerts_last_reported_time"
      , first("off_alerts_first_reported_time") as "off_alerts_first_reported_time"
      , first("off_alerts_last_reported_time") as "off_alerts_last_reported_time"
      , first($"topic", ignoreNulls = true) as "topic"
      , first($"topic_id", ignoreNulls = true) as "topic_id"
      , first($"alert_id") as "alert_id"
      , count($"device_name") cast "int" as "no_of_datapoints"
    ).withColumn("reported_time", $"agg_date")
      .withColumn("last_updated"
        , to_timestamp(
          from_unixtime(lit(lastupdated_timestamp), "yyyy-MM-dd HH:mm:ss")
        )
      )
      .withColumn("wheel_key", concat($"device_id", $"asset_name", $"location"))
      .withColumn("asset_wheel_config_key", concat($"asset_name", $"wheel_config"))
      .withColumn("service", lit("analytics-dashboard"))
      .withColumn("run_period", lit(unit_of_run.replace("  ", " ").replace(" ", "_")))
      .withColumn("alert_duration_hrs"
        ,when($"run_period" === "24_Hours"
          , when($"alert_duration_hrs" > 1,1 ).otherwise($"alert_duration_hrs") // for hourly attribute whole hour if over
        ).otherwise(
          when($"alert_duration_hrs" > 24,24 ).otherwise($"alert_duration_hrs") // for daily attribute whole day
        )
      )
      .withColumn("reported_time_format"
        , when($"run_period" === "24_Hours"
          , hour(to_timestamp($"agg_date", run_config.getOrElse(unit_of_run, default_run_config)._6))
        ).otherwise(
          concat_ws("/",
            lpad(dayofmonth(to_timestamp($"agg_date", run_config.getOrElse(unit_of_run, default_run_config)._6)), 2, "0")
            , lpad(month(to_timestamp($"agg_date", run_config.getOrElse(unit_of_run, default_run_config)._6)), 2, "0")
          )
        )
      )
      .withColumn("rec_rank"
        , rank over Window.partitionBy("device_id", "location", "alert_name").orderBy(asc("agg_date"))
      )
      .withColumn("frequency", lit(run_config.getOrElse(unit_of_run, default_run_config)._7))
      .withColumn("vehicle_key", concat($"device_id", $"asset_name", $"frequency"))
      .persist(StorageLevel.MEMORY_AND_DISK)


    // calculate alert distances
    val dfProcessedAlerts = alertDf.join(
  //    dfProcessed
      dashGpsDf
        .select($"device_id", $"reported_time", $"distance_travelled", $"hrs_active")
      , Seq("device_id", "reported_time")
      , "left"
    ).na.fill(0)
      .withColumn(
        "alert_distance"
        , when($"alert_distance" > $"distance_travelled"
          , $"distance_travelled"
        ).otherwise($"alert_distance")
      )
      .drop("distance_travelled", "hrs_active")

    val dashTpmsAlertDf = calcAlertDurationAndDistanceByAlertType(dfProcessedAlerts).drop("reported_time_format")


    // added alert summary to vehicle data
    val finalGpsData = dashGpsDf.join(
      dfProcessedAlerts.select($"device_id", $"total_alerts").groupBy("device_id").agg(
        sum($"total_alerts").as("active_alerts")
      )
      , Seq("device_id")
      , "left"
    )
      .withColumn("device_has_alerts"
        , when($"active_alerts" > 0, lit(1)
        ).otherwise(lit(0))
    )

    // push to Dasboard kafka topic
    loadWheelData(dashTpmsDf.toDF(), unit_of_run)
    loadVehicleData(finalGpsData, unit_of_run)
    loadWheelAlertData(
      dashTpmsAlertDf
       .where(!($"alert_name" rlike (".* Off$")))
     , unit_of_run
    )

     Thread.sleep(5000) // wait 5 sec and send 'completed' notification

    // send end message
     cust_list
      .withColumn("notification",lit("history-completed"))
      .withColumn("datetime"
        ,to_timestamp(
          from_unixtime(lit(System.currentTimeMillis() / 1000), "yyyy-MM-dd HH:mm:ss")
        )
      )
      .groupBy("notification").agg(
      collect_list("customer").as("customers")
      , first($"datetime", ignoreNulls = true) as "datetime"
    ).select($"notification" as "key"
      , to_json(
        struct(
          $"notification"
          , $"customers"
          , $"datetime"
        )
      ) as "value"
    )
      .write
      .format("kafka")
      .mode("append")
      .options(PipelineUtil.kafkaConfig)
      .option("topic", pipelineConfig.getString("batch-run-notifications"))
      .save()


  }
}
