package com.sensata.data_office.batch

import com.sensata.data_office.batch.jobs.DashBoardDataLoader.runDashBoardDataLoader
import com.sensata.data_office.data._
import com.sensata.data_office.utilities.PipelineUtil
import com.typesafe.config.ConfigFactory
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.catalyst.ScalaReflection
import org.apache.spark.sql.functions.{expr, _}
import org.apache.spark.sql.types.StructType
import org.apache.spark.storage.StorageLevel
import org.slf4j.LoggerFactory

import java.sql.Timestamp
import java.time.{LocalDateTime, LocalTime}
import scala.collection.JavaConverters._

object DashBoardDataPipeline {

  val appConfig = ConfigFactory.load(s"application.${PipelineUtil.getEnvVariable("ENVIRONMENT")}.conf").getConfig("DashBoardDataLoader")
  val pipelineConfig = appConfig.getConfig("pipeline")

  val num_partitions = pipelineConfig.getInt("num_partitions")

  val default_assumed_speed_mph = pipelineConfig.getInt("default_assumed_speed_mph")

  val late_record_threshold_sec = ConfigFactory
    .load(s"application.${PipelineUtil.getEnvVariable("ENVIRONMENT")}.conf").getConfig("high_watermark").getInt("late_record_threshold_sec")

  val sparkCfgObj = new SparkConf()

  val sparkCfg = ConfigFactory.load(s"application.${PipelineUtil.getEnvVariable("ENVIRONMENT")}.conf").getConfig("spark")
  sparkCfg.getConfig("config").root().asScala.map(
    v => sparkCfgObj.set( String.valueOf(v._1),String.valueOf(v._2.unwrapped()) )
  )

  val spark = SparkSession
    .builder
    .appName(pipelineConfig.getString("application_name"))
    .config(sparkCfgObj)
    .getOrCreate()

  import PipelineUtil.spark.implicits._

  val appLogger = LoggerFactory.getLogger("spark")

  val run_config = Map(
    "24 Hours" -> (pipelineConfig.getString("consumer_group")
      , pipelineConfig.getString("consumer_group")
      , 50
      , pipelineConfig.getString("consumer_group")
      , pipelineConfig.getString("consumer_group")
      , "yyyy-MM-dd HH:00:00"
      , "Last 24 Hours"
      , pipelineConfig.getString("consumer_group")
      , pipelineConfig.getString("consumer_group")    )
    ,"7 Days" -> (pipelineConfig.getString("consumer_group")
      , pipelineConfig.getString("consumer_group")
      , 50
      , pipelineConfig.getString("consumer_group")
      , pipelineConfig.getString("consumer_group")
      , "yyyy-MM-dd"
      , "Last 7 Days"
      , pipelineConfig.getString("consumer_group")
      , pipelineConfig.getString("consumer_group")    )
    ,"30 Days" -> (pipelineConfig.getString("consumer_group")
      , pipelineConfig.getString("consumer_group")
      , 100
      , pipelineConfig.getString("consumer_group")
      , pipelineConfig.getString("consumer_group")
      , "yyyy-MM-dd"
      , "Last 30 Days"
      , pipelineConfig.getString("consumer_group")
      , pipelineConfig.getString("consumer_group")    )  )


  val customer_data = PipelineUtil.updateCustomerDimCacheFromDatabase().cache()


  val archive_base_path = pipelineConfig.getString("src_archive_data_path")
  val wheel_records_src = pipelineConfig.getString("src_optimised_data_path") + "wheels" //src_data_path
  val gps_records_src = pipelineConfig.getString("src_optimised_data_path") + "gps"
  val alerts_records_src = pipelineConfig.getString("src_optimised_data_path") + "wheel_alerts"
  val alerts_analytics_records_src = pipelineConfig.getString("src_optimised_data_path") + "wheel_alert_snapshots"


  val default_run_config = ("None", "None", 50, "None", "None", "yyyy-MM-dd", "Last 5 days","None","None")

  def main(args: Array[String]): Unit = {

    PipelineUtil.setKafkaSecrets(PipelineUtil.getEnvVariable("ENVIRONMENT") == "prod")
    PipelineUtil.setDBConnectString(PipelineUtil.getEnvVariable("ENVIRONMENT") == "prod")
    PipelineUtil.setCustomerConnectString(PipelineUtil.getEnvVariable("ENVIRONMENT") == "prod")

    // run batch job
    appLogger.info(s"Arguments are : ${args.map(_.toString).mkString(",")}")
    val use_max_reported_timestamp = args(0) // Hour, 7 Day, 30 Days
    var cur_timestamp: Timestamp =  Timestamp.valueOf(
      LocalDateTime.of(LocalDateTime.now().toLocalDate(), LocalTime.MIDNIGHT )
    )

    if (use_max_reported_timestamp.toInt == 1) {
      cur_timestamp = spark
        .read
        .format("parquet")
        .option("inferSchema", "true")
        .load(wheel_records_src)
        .select(max($"reported_time") as "reported_time").collectAsList().get(0).getTimestamp(0)
    }

    val cur_timestamp_millis = ( System.currentTimeMillis() / (3600 * 1000) ).floor.toInt * 3600


    // cache 30 days of data
    val consumed_timestamp_delta = cur_timestamp_millis - (30 * (24*3600))
    val gps_data_schema = ScalaReflection.schemaFor[ProcessedGPSRecord].dataType.asInstanceOf[StructType]
    val wheel_data_schema = ScalaReflection.schemaFor[ProcessedWheelRecord].dataType.asInstanceOf[StructType]
    val alert_data_schema = ScalaReflection.schemaFor[ProcessedWheelWarningRecord].dataType.asInstanceOf[StructType]
    val alert_snapshot_data_schema = ScalaReflection.schemaFor[ProcessedAlertSnapshot].dataType.asInstanceOf[StructType]
    val arc_gps_data_schema = ScalaReflection.schemaFor[ArchivedProcessedGPSRecord].dataType.asInstanceOf[StructType]
    val arc_wheel_data_schema = ScalaReflection.schemaFor[ArchivedProcessedWheelRecord].dataType.asInstanceOf[StructType]
    val arc_alert_data_schema = ScalaReflection.schemaFor[ArchivedProcessedWheelWarningRecord].dataType.asInstanceOf[StructType]

    val WheelsMessage = spark
      .read
      .format("parquet")
      .schema(wheel_data_schema)
      .load(wheel_records_src)
      .where(
        ($"consumed_timestamp" >= lit(consumed_timestamp_delta))
      )
      .select(wheel_data_schema.fields.map(_.name).map(col(_)):_*)
      .union(
        spark
          .read
          .format("parquet")
          .schema(arc_wheel_data_schema)
          .load(archive_base_path + "wheels")
          .where(
            ($"run_date" >= (date_format(lit(consumed_timestamp_delta) cast "timestamp", "yyyyMMdd") cast "long"))
          )
          .select(wheel_data_schema.fields.map(_.name).map(col(_)):_*)
      )

      .dropDuplicates(Seq("service", "device_id", "device_name", "reported_time", "location"))
      .persist(StorageLevel.MEMORY_AND_DISK)

    val GPSMessage = spark
      .read
      .format("parquet")
      .schema(gps_data_schema)
      .load(gps_records_src)
      .where(
        ($"consumed_timestamp" >= lit(consumed_timestamp_delta))
      )
      .select(gps_data_schema.fields.map(_.name).map(col(_)):_*)
      .union(
        spark
          .read
          .format("parquet")
          .schema(arc_gps_data_schema)
          .load(archive_base_path + "gps")
          .where(
            ($"run_date" >= (date_format(lit(consumed_timestamp_delta) cast "timestamp", "yyyyMMdd") cast "long"))
          )
          .select(gps_data_schema.fields.map(_.name).map(col(_)):_*)
      )
      .dropDuplicates(Seq("service", "device_id", "device_name", "reported_time"))
      .persist(StorageLevel.MEMORY_AND_DISK)

    val AlertMessage = spark
      .read
      .format("parquet")
      .schema(alert_data_schema)
      .load(alerts_records_src)
      .where(
        ($"consumed_timestamp" >= lit(consumed_timestamp_delta))
      )
      .select(alert_data_schema.fields.map(_.name).map(col(_)):_*)
      .union(
        spark
          .read
          .format("parquet")
          .schema(arc_alert_data_schema)
          .load(archive_base_path + "wheel_alerts")
          .where(
            ($"run_date" >= (date_format(lit(consumed_timestamp_delta) cast "timestamp", "yyyyMMdd") cast "long"))
          )
          .select(alert_data_schema.fields.map(_.name).map(col(_)):_*)
      )
      .dropDuplicates(Seq("service", "device_id", "device_name", "reported_time", "location","alert_name","active"))
      .persist(StorageLevel.MEMORY_AND_DISK)

    val AlertSnapShotMessage = spark
      .read
      .format("parquet")
      .schema(alert_snapshot_data_schema)
      .load(alerts_analytics_records_src)
      .where(
        ($"consumed_timestamp" >= lit(consumed_timestamp_delta))
      )
      .select(alert_snapshot_data_schema.fields.map(_.name).map(col(_)):_*)
      .union(
        spark
          .read
          .format("parquet")
          .schema(alert_snapshot_data_schema)
          .load(archive_base_path + "wheel_alert_snapshots")
          .where(
            ($"run_date" >= (date_format(lit(consumed_timestamp_delta) cast "timestamp", "yyyyMMdd") cast "long"))
          )
          .select(alert_snapshot_data_schema.fields.map(_.name).map(col(_)):_*)
      )
      .dropDuplicates(Seq("service", "device_id", "reported_time"))
      .persist(StorageLevel.MEMORY_AND_DISK)



    // run the job for all run configs
    run_config.keys.foreach( unit_of_run => {

      val start_time_range = lit(cur_timestamp) - expr(s"INTERVAL ${unit_of_run}")
      val end_time_range = lit(cur_timestamp) - expr(s"INTERVAL 1 ${unit_of_run.split(" ")(1)}")

      appLogger.info(s"Using Timestamp: ${cur_timestamp.toString}")
      appLogger.info(s"Using Consumed Timestamp: ${consumed_timestamp_delta.toString}")
      appLogger.info(s"Using Start Timestamp: ${cur_timestamp.toString} - INTERVAL $unit_of_run")
      appLogger.info(s"Using End Timestamp: ${cur_timestamp.toString}")
      appLogger.info(s"Using Run Parameter: ${unit_of_run}")
      appLogger.info(s"Using Wheel Path: ${wheel_records_src}")
      appLogger.info(s"Using GPS Path: ${gps_records_src}")
      appLogger.info(s"Using Alerts Path: ${alerts_records_src}")


        runDashBoardDataLoader(start_time_range,end_time_range,WheelsMessage,GPSMessage,AlertMessage,AlertSnapShotMessage,unit_of_run)
    })

  }

}
