package com.sensata.data_office.batch.jobs

import com.databricks.dbutils_v1.DBUtilsHolder.dbutils
import com.sensata.data_office.batch.DashBoardDataPipeline.spark
import com.sensata.data_office.batch.StorageRetensionPipeline._
import com.sensata.data_office.data._
import com.typesafe.config.ConfigFactory
import org.apache.spark.sql.catalyst.ScalaReflection
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StructType
import org.joda.time.format.DateTimeFormat

import java.io.FileNotFoundException
import java.sql.Timestamp
import java.time.format.DateTimeFormatter
import java.time.{LocalDate, LocalDateTime, ZoneOffset}
import scala.collection.JavaConverters._

object OptimiseBlobStorage {

  import spark.implicits._

  val gps_data_schema = ScalaReflection.schemaFor[ProcessedGPSRecord].dataType.asInstanceOf[StructType]
  val wheel_data_schema = ScalaReflection.schemaFor[ProcessedWheelRecord].dataType.asInstanceOf[StructType]
  val alert_data_schema = ScalaReflection.schemaFor[ProcessedWheelWarningRecord].dataType.asInstanceOf[StructType]
  val alert_analytic_data_schema = ScalaReflection.schemaFor[ProcessedAlertSnapshot].dataType.asInstanceOf[StructType]
  val active_alert_data_schema = ScalaReflection.schemaFor[ActiveAlertNotification].dataType.asInstanceOf[StructType]
  val asset_actvty_data_schema = ScalaReflection.schemaFor[AssetActivityNotification].dataType.asInstanceOf[StructType]
  val arc_gps_data_schema = ScalaReflection.schemaFor[ArchivedProcessedGPSRecord].dataType.asInstanceOf[StructType]
  val arc_wheel_data_schema = ScalaReflection.schemaFor[ArchivedProcessedWheelRecord].dataType.asInstanceOf[StructType]
  val arc_alert_data_schema = ScalaReflection.schemaFor[ArchivedProcessedWheelWarningRecord].dataType.asInstanceOf[StructType]
  val arc_alert_analytic_data_schema = ScalaReflection.schemaFor[ArchivedProcessedAlertSnapshot].dataType.asInstanceOf[StructType]
  val min_no_partitions = 3
  val min_partition_size = 50000000 // 50M
  val checkpoint_folder_path = ConfigFactory
    .load(s"application.${sys.env("ENVIRONMENT")}.conf")
    .getConfig("CustomerDataPublisher").getConfig("pipeline").getString("checkpoint_path")


  def deletePartitionsByList(aListofPartitions: List[String], basePath: String, topPartitionName: String, do_delete: Boolean = false) = {
    aListofPartitions.foreach(
      apartition => {
        var delete_path = s"${basePath}/$topPartitionName=$apartition"
        appLogger.info(s"${if (do_delete) "Actually" else "Would"} Removing : $delete_path")
        if (do_delete) {
          try {
            dbutils.fs.rm(delete_path, true)
          } catch {
            case _: FileNotFoundException =>  appLogger.info(s"FileNotFoundException Path: $delete_path not found")
          }
        }
      })
  }

  def doSmallFilesOptimisation(num_of_hrs_process: Int = 10, do_delete: Boolean = false) {

    val cur_hour_timestamp_millis = DateTimeFormat.forPattern("YYYY-MM-dd HH:00:00").parseMillis(
      new java.sql.Timestamp(System.currentTimeMillis()
      )
        .toLocalDateTime.format(
        DateTimeFormatter.ofPattern("YYYY-MM-dd HH:00:00")
      )
    ) / 1000

    val last_hour_timestamp_millis = cur_hour_timestamp_millis - (3600*2) // give steaming job time to persist data from current hour and past hour
    val data_paths = Seq(
      (
        pipelineConfig.getString("src_data_path") + "wheels"
        , pipelineConfig.getString("src_optimised_data_path") + "wheels"
        , wheel_data_schema
      )
      , (
        pipelineConfig.getString("src_data_path") + "gps"
        , pipelineConfig.getString("src_optimised_data_path") + "gps"
        , gps_data_schema
      )
      , (
        pipelineConfig.getString("src_data_path") + "wheel_alerts"
        , pipelineConfig.getString("src_optimised_data_path") + "wheel_alerts"
        , alert_data_schema
      )
      , (
        pipelineConfig.getString("src_data_path") + "wheel_alert_snapshots"
        , pipelineConfig.getString("src_optimised_data_path") + "wheel_alert_snapshots"
        , alert_analytic_data_schema
      )
    ).foreach(paths => {

      val consumed_time_list = last_hour_timestamp_millis - (3600 * num_of_hrs_process) to last_hour_timestamp_millis by 3600

      spark
        .read
        .format("parquet")
        .schema(paths._3)
        .load(paths._1)
        .where($"consumed_timestamp"
          between(last_hour_timestamp_millis - (3600 * 24 * num_of_hrs_process), last_hour_timestamp_millis )
        )
        .withColumn("consumed_timestamp", floor($"consumed_timestamp" / 3600) * 3600)
        .repartition(min_no_partitions)
        .write
        .format("parquet")
        .mode("append")
        .option("mergeSchema", "true")
        .partitionBy("consumed_timestamp")
        .save(paths._2)

      // delete data in old location
      consumed_time_list.toList.foreach(
        arow => {
          try {
            appLogger.info(s"${if (do_delete) "Actually Removing" else "Would Remove"} : ${paths._1}/consumed_timestamp=${arow.toString}")

            if (do_delete) {
              dbutils.fs.rm(s"${paths._1}/consumed_timestamp=${arow.toString}", true)
            }
          } catch {
            case _: FileNotFoundException =>  appLogger.info(s"FileNotFoundException Path: ${paths._1}/consumed_timestamp=${arow.toString} not found")
          }

        })
    })

  }

  /**
   * Manage how long data is kept in the blob store.
   */
  def doTruncateBlobStoreDataHistory(num_of_hrs_process: Int = 10, do_delete: Boolean = false, is_daily_run: Boolean = false) {

    val last_snapshot_partition = LocalDateTime.now().minusDays(data_retension_period_days).format(
      DateTimeFormatter.ofPattern("yyyyMMddHH0000")
    )

    val last_checkpoint_hour_timestamp = ( ( System.currentTimeMillis() / (3600*1000) ).floor.toLong * 3600 ) - (5 * 3600)

    Seq(
      (
        "wheels"
        , (wheel_data_schema,snapshot_base_path + "wheel")
        , (wheel_data_schema,curated_base_path + "wheels")
        , (arc_wheel_data_schema,archive_base_path + "wheels")
      )
      , (
        "gps"
        , (gps_data_schema,snapshot_base_path + "vehicle")
        , (gps_data_schema,curated_base_path + "gps")
        , (arc_gps_data_schema,archive_base_path + "gps")
      )
      , (
        "wheel_alerts"
        , (alert_data_schema,snapshot_base_path + "wheel_alerts")
        , (alert_data_schema,curated_base_path + "wheel_alerts")
        , (arc_alert_data_schema,archive_base_path + "wheel_alerts")
      )
      , (
        "wheel_alert_events"
        , (alert_data_schema,snapshot_base_path + "wheel_alert_events")
        , (alert_data_schema,curated_base_path + "wheel_alert_events")
        , (arc_alert_data_schema,archive_base_path + "wheel_alert_events")
      )
      , (
        "wheel_alert_snapshots"
        , (alert_analytic_data_schema,curated_base_path + "wheel_alert_snapshots")
        , (alert_analytic_data_schema,curated_base_path + "wheel_alert_snapshots")
        , (arc_alert_analytic_data_schema,archive_base_path + "wheel_alert_snapshots")
      )
      , (
        "active_alerts"
        , (active_alert_data_schema,cache_base_path + "active_alerts")
        , (active_alert_data_schema,cache_base_path + "active_alerts")
        , (active_alert_data_schema,cache_base_path + "active_alerts")
      )
      , (
        "asset_activity"
        , (asset_actvty_data_schema,cache_base_path + "asset_activity")
        , (asset_actvty_data_schema,cache_base_path + "asset_activity")
        , (active_alert_data_schema,cache_base_path + "asset_activity")
      )
      , (
        "json_dump"
        , (asset_actvty_data_schema,s"${cleanupCfg.getString("raw_json_path")}")
        , (asset_actvty_data_schema,s"${cleanupCfg.getString("raw_json_archive_path")}")
        , (active_alert_data_schema,s"${cleanupCfg.getString("raw_json_archive_path")}")
      )
      , (
        "xirgo_json_dump"
        , (asset_actvty_data_schema,s"${cleanupCfg.getString("xirgo_raw_json_path")}")
        , (asset_actvty_data_schema,s"${cleanupCfg.getString("xirgo_raw_json_archive_path")}")
        , (active_alert_data_schema,s"${cleanupCfg.getString("xirgo_raw_json_archive_path")}")
      )
    ).foreach(paths => {

      if ((!Seq("asset_activity", "active_alerts","wheel_alert_events").contains(paths._1)) && is_daily_run) {

        if (Seq("json_dump","xirgo_json_dump").contains(paths._1)) {
          // process the raw json files for yesterday
          doOptimiseRawJsonStorage(paths)
        } else {
          // get the max and min checkpoint dates
          val dataRange = spark
            .read
            .format("parquet")
            .schema(paths._3._1)
            .load(paths._3._2)
            .select(min("consumed_timestamp"), max("consumed_timestamp"))
            .collectAsList()

          // move data to archive store and partition by day
          if (dataRange.size() > 0) {
            spark
              .read
              .format("parquet")
              .schema(paths._3._1)
              .load(paths._3._2)
              .where($"consumed_timestamp" between(dataRange.get(0).getLong(0), dataRange.get(0).getLong(1)))
              .withColumn("consumed_timestamp", floor($"consumed_timestamp" / 3600) * 3600)
              .withColumn("run_date", date_format($"consumed_timestamp" cast "timestamp", "yyyyMMdd"))
              .repartition(5)
              .write
              .format("parquet")
              .mode("append")
              .option("mergeSchema", "true")
              .partitionBy("run_date")
              .save(paths._4._2)

            // delete all optimised curated data except last 3 hours
            val aconsumed_time_list = dataRange.get(0).getLong(0) to ((System.currentTimeMillis() / (3600 * 1000)).floor.toLong * 3600) - (3600 * 3) by 3600
            deletePartitionsByList(aconsumed_time_list.map(_.toString).toList
              , paths._3._2
              , "consumed_timestamp"
              , do_delete
            )


            val last_rundate = LocalDateTime.now().minusDays(data_retension_period_days).format(
              DateTimeFormatter.ofPattern("yyyyMMdd")
            )
            val rundates = spark
              .read
              .format("parquet")
              .schema(paths._4._1)
              .load(paths._4._2)
              .select(min("run_date"))
              .collectAsList()
              .asScala.map(r => {
              Map(
                "min" -> LocalDate.parse(r.getLong(0).toString, DateTimeFormatter.ofPattern("yyyyMMdd"))
                  .toEpochDay() * (24 * 3600)
                , "max" -> LocalDate.parse(last_rundate, DateTimeFormatter.ofPattern("yyyyMMdd"))
                  .toEpochDay() * (24 * 3600)
              )
            }).toList(0)
            val min_rundate: Long = rundates.getOrElse("min", 0)
            val max_rundate: Long = rundates.getOrElse("max", 0)
            val rundate_list = min_rundate to max_rundate by (3600 * 24)

            // delete all run days outside the retension period
            deletePartitionsByList(rundate_list
              .map(
                LocalDateTime.ofEpochSecond(_, 0, ZoneOffset.UTC).format(
                  DateTimeFormatter.ofPattern("yyyyMMdd")
                ).toString
              ).toList
              , paths._4._2
              , "run_date"
              , do_delete
            )
          }
        }
      } else {

        val checkpoint_list = last_checkpoint_hour_timestamp - (3600 * num_of_hrs_process) to last_checkpoint_hour_timestamp by 3600

        // delete old activity and alert tracking data
        checkpoint_list.foreach(
          arow => {

            var delete_path = ""
            if (Seq("asset_activity", "active_alerts").contains(paths._1)) {
              delete_path = s"${paths._2._2}/checkpoint_timestamp=${arow.toString}"
              appLogger.info(s"${if (do_delete) "Actually" else "Would"} Removing : $delete_path")
              if (do_delete) {
                try {
                  dbutils.fs.rm(delete_path, true)
                } catch {
                  case _: FileNotFoundException => appLogger.info(s"FileNotFoundException Path: $delete_path not found")
                }
              }
            }
          })

        if (!Seq("wheel_alert_snapshots", "active_alerts", "asset_activity").contains(paths._1)) {
          val snapshot_dates =  if (Seq("xirgo_json_dump","json_dump").contains(paths._1)) {
            spark
              .read
              .format("json")
              //.schema(paths._2._1)
              .load(paths._2._2)
              .where(
                ($"run_date" < last_snapshot_partition)
              )
              .select($"run_date")
              .dropDuplicates("run_date")
              .orderBy(desc("run_date"))
              .limit(num_of_hrs_process)
              .collectAsList()
          } else {
            spark
              .read
              .format("parquet")
              //.schema(paths._2._1)
              .load(paths._2._2)
              .where(
                ($"run_date" < last_snapshot_partition)
              )
              .select($"run_date")
              .dropDuplicates("run_date")
              .orderBy(desc("run_date"))
              .limit(num_of_hrs_process)
              .collectAsList()
          }


          val snapshot_dates_list = snapshot_dates.asScala.map(_.getLong(0)).toList
          snapshot_dates_list.foreach(
            arow => {
              appLogger.info(s"${if (do_delete) "Actually" else "Would"} Removing : ${paths._2._2}/run_date=${arow.toString}")
              if (do_delete)
                dbutils.fs.rm(s"${paths._2._2}/run_date=${arow.toString}", true)
            })
        }
      }
    })
  }

  def doOptimiseRawJsonStorage(paths:(String,(StructType,String),(StructType,String),(StructType,String)), do_delete:Boolean = false ) = {

    // yesterdays files
    val start_land_date = new Timestamp((System.currentTimeMillis())).toLocalDateTime.minusDays(1).format(DateTimeFormatter.ofPattern("YYYYMMdd00"))
    val end_land_date = new Timestamp((System.currentTimeMillis())).toLocalDateTime.minusDays(1).format(DateTimeFormatter.ofPattern("YYYYMMdd23"))
    spark
      .read
      .text(paths._2._2)
      .where($"land_date" between (start_land_date,end_land_date))
      //.groupBy($"land_date").count()
      .withColumn("land_date", substring($"land_date",1,8))
      .repartition(3)
      .write
      .partitionBy("land_date")
      .mode("append")
      .format("text")
      .option("compression","snappy")
      .save(paths._3._2)

    // delete yesterdays small files
    (start_land_date.toLong to end_land_date.toLong)
      .foreach(
        adir => {
          appLogger.info(s"${if (do_delete) "Actually Removing" else "Would Remove"} Old json : ${paths._2._2}/land_date=${adir.toString}")
          if (do_delete)
            dbutils.fs.rm(s"${paths._2._2}/land_date=${adir.toString}", true)
        }
      )

    // delete 5 days of old json files
    spark
      .read
      .text(paths._2._2)
      .select($"land_date")
      .where($"land_date" < end_land_date.toLong)
      .orderBy(desc("land_date"))
      .dropDuplicates()
      .limit(120)
      .collectAsList()
      .asScala
      .map(_.getInt(0))
      .foreach(adir => {
        appLogger.info(s"${if (do_delete) "Actually Removing" else "Would Remove"} Old json : ${paths._2._2}/land_date=${adir.toString}")
        if (do_delete)
          dbutils.fs.rm(s"${paths._2._2}/land_date=${adir.toString}", true)
      })
  }
}
