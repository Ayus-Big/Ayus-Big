package com.sensata.data_office.utilities

import com.sensata.data_office.utilities.PipelineUtil.appLogger
import org.apache.spark.sql.SparkSession
import org.joda.time.DateTime
import org.joda.time.format.DateTimeFormat

object sparkQueryMonitor {

  def getCurrentQueryProgress(sparkSess: SparkSession ) = {
    val active_queries = sparkSess.streams.active
    val last_batch = active_queries
      .toList
      .filter(_.name.contains("Stream"))
      .foreach(r => {
        if (r.lastProgress.numInputRows <= 0) {

          //2016-12-14T18:45:24.873Z
          val lastbatchT = DateTime.parse(r.lastProgress.timestamp
            ,DateTimeFormat.forPattern("yyyy-MM-ddTHH:mm:ss.sssZ")
          )
          if (
            (r.lastProgress.numInputRows <= 0) && (
              r.recentProgress
                .toList
                .slice(0,4)
                .map(_.numInputRows)
                .sum <= 0
            )
          ) {
            throw new RuntimeException(s"Streaming Query ${r.name} is Behind. Check source. ")
          } else {
            appLogger.info(s"Last InputRowCount for query ${r.name} id ${r.lastProgress.numInputRows} ")
          }
        }

      })
  }

}
