package com.sensata.data_office.batch

import java.util.Properties

import com.sensata.data_office.batch.jobs.OptimiseBlobStorage
import com.typesafe.config.ConfigFactory
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.slf4j.LoggerFactory

import scala.collection.JavaConverters._

object StorageRetensionPipeline {

  val appConfig = ConfigFactory.load(s"application.${sys.env("ENVIRONMENT")}.conf").getConfig("DashBoardDataLoader")
  val cleanupCfg = ConfigFactory.load(s"application.${sys.env("ENVIRONMENT")}.conf").getConfig("data_cleanup")
  val cacheCfg = ConfigFactory.load(s"application.${sys.env("ENVIRONMENT")}.conf").getConfig("EventProcessors")

  val pipelineConfig = appConfig.getConfig("pipeline")

  val data_retension_period_days = cleanupCfg.getInt("data_retension_period_days")
  val snapshot_base_path = pipelineConfig.getString("dest_data_path")
  val curated_base_path = pipelineConfig.getString("src_optimised_data_path")
  val archive_base_path = pipelineConfig.getString("src_archive_data_path")
  val cache_base_path = s"${cacheCfg.getConfig("pipeline").getString("active_cache_path")}/"

  val sparkCfgObj = new SparkConf()

  val sparkCfg = ConfigFactory.load(s"application.${sys.env("ENVIRONMENT")}.conf").getConfig("spark")
  sparkCfg.getConfig("config").root().asScala.map(
    v => sparkCfgObj.set( String.valueOf(v._1),String.valueOf(v._2.unwrapped()) )
  )

  val spark = SparkSession
    .builder
    .appName(pipelineConfig.getString("application_name"))
    .config(sparkCfgObj)
    .getOrCreate()


  val appLogger = LoggerFactory.getLogger("spark")



  def main(args: Array[String]): Unit = {

    val do_delete = if (args.length > 0 && args(0).toInt == 1) true else false
    val num_of_folders = if (args.length > 1 && args(1).toInt > 0) args(1).toInt else 50
    val is_daily_run = if (args.length > 2 && args(2).toInt == 1) true else false
    // run batch job
    appLogger.info(s"Arguments are : ${args.map(_.toString).mkString(",")}")

    // run optimisation job for processed streaming files
    OptimiseBlobStorage.doTruncateBlobStoreDataHistory(num_of_folders,do_delete,is_daily_run)



  }

}
