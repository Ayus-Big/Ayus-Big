package com.sensata.data_office.pipeline.queries

import com.sensata.data_office.data.{XirgoEventData, XirgoMapping}
import com.sensata.data_office.utilities.PipelineUtil
import com.sensata.data_office.pipeline.StreamingPipeline.fedex_alerts_cache
import com.typesafe.config.ConfigFactory
import org.apache.spark.sql.catalyst.ScalaReflection
import org.apache.spark.sql.functions._
import org.apache.spark.sql.streaming.Trigger
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.{DataFrame, Dataset, Row}
import org.apache.spark.storage.StorageLevel

import scala.collection.JavaConverters._

object XirgoEventsProcessor {

  val pipelineConfig = ConfigFactory
    .load(s"application.${sys.env("ENVIRONMENT")}.conf")
    .getConfig("RawEventsProcessor").getConfig("pipeline")

  val VERSION = pipelineConfig.getString("version")

  import PipelineUtil.spark.implicits._

  def getPartitonTimeStamp(date_format: String) = {

    to_timestamp(
      from_unixtime(unix_timestamp(), date_format)
    ).cast("long")
  }


  def udf_mapTypePressureStatus = udf((pressure_status:Int) => {
    XirgoMapping.xirgo_tyre_pressure_state.getOrElse(pressure_status,0)
  })

  // PressureThresholdPSI
  def SetAlertFlags(data: DataFrame
                    , PressureThresholdPSI: Double
                    , TempThresholdF: Double
                    ,	PressAlertLow1: Double
                    ,	PressAlertLow2: Double
                    ,	PressAlertHigh1: Double
                    ,	TempCompDowntoC: Double
                    ,	TempCompActive: Int = 1
                   ): DataFrame = {
    data //FedexEventData
      .withColumn("tyre_temperatureC"
        ,round( (($"tyreTemperature" cast "float") - 32) * (5 / 9)
          , 1
        )
      )
      .withColumn("tyre_temperatureF", $"tyreTemperature")
      .withColumn("tyre_pressurePSI", $"tyrePressure")
      .withColumn("TempCompPressThresholdPSI"
        ,round(
          ((lit(PressureThresholdPSI)+ 14.696) * (($"tyre_temperatureC" + 273) /293)- 14.696),2)
      )
      .withColumn("PressureAlertThresholdPSI"
        , when($"tyre_temperatureC" >= lit(TempCompDowntoC)
          ,$"TempCompPressThresholdPSI"
        ).otherwise(lit("PressureThresholdPSI"))
      )
      .withColumn("TemperatureAlertActive"
        , when(col("tyre_temperatureF") >= lit(TempThresholdF),1).otherwise(0)
      )
      .withColumn("PressAlertLow1Active"
        , when(
          ( ($"tyre_pressurePSI") <= ($"PressureAlertThresholdPSI" * lit(PressAlertLow1)) )
            && ( ($"tyre_pressurePSI") > $"PressureAlertThresholdPSI" * lit(PressAlertLow2) )
          ,1
        ).otherwise(0)
      )
      .withColumn("PressAlertLow2Active"
        , when(
          $"tyre_pressurePSI" <= $"PressureAlertThresholdPSI" * lit(PressAlertLow2)
          ,1
        ).otherwise(0)
      )
      .withColumn("PressAlertHigh1Active"
        , when( $"tyre_pressurePSI" >= $"PressureAlertThresholdPSI" * lit(PressAlertHigh1)
          ,1
        ).otherwise(0)
      )
  }

  def generateAnalyticsMsg(df: DataFrame): DataFrame = {
    df.selectExpr(
        "'analytics' as service"
        ,"'events/warnings' as resource"
        , "deviceEsn as device_id"
        ,"cast(eventTimestamp as long) * 1000 as time"
        , "cast(eventTimestamp as long) as tstamp"
        , "1.2 as version"
        , "ucase(wheelLocation) as location"
        , "(tyreTemperature - 32) * 0.55555 as measured_temperature"
        , "targetNomPressure as temp_comp"
        , "(tyrePressure * 68.9476) as measured_pressure"
        , "batteryStatus as battery"
        , "evt"
      )
      .select($"service",$"resource",$"device_id",$"version",$"time",$"tstamp"
        , struct(
           $"evt" as "trigger"
          , array(
            struct(
              $"service"
              ,lit("wheel/pressure") as "resource"
              ,$"version"
              ,$"time"
              ,to_json(struct($"location",struct($"measured_pressure" as "measured",$"temp_comp") as "pressure")) as "data"
            )
            , struct(
              $"service"
              ,lit("wheel/temperature") as "resource"
              ,$"version"
              ,$"time"
              ,to_json(struct($"location",$"measured_temperature" as "temperature")) as "data"
            )
            , struct(
              $"service"
              ,lit("wheel/battery") as "resource"
              ,$"version"
              ,$"time"
              ,to_json(struct($"location",$"battery")) as "data"
            )
          ) as "additional_data"
        ) as "data"
      )
      .select($"device_id",$"time",$"tstamp",struct($"service",$"resource",$"version",$"time",$"data") as "event")
      .withColumnRenamed("event","evt")
      .select($"device_id" as "deviceId",lit("partner_device") as "device_name",lit("FedEx") as "customer",$"time",$"tstamp",$"evt")
      .select(concat_ws("-",$"deviceId",$"time") as "key",to_json( struct($"deviceId",$"tstamp",$"customer",$"evt")) as "value")

  }

  def generatePressureAlertHubA(decode_mesg: DataFrame): DataFrame = {
    decode_mesg.selectExpr(
      "'tpms' as service"
      , "deviceEsn as device_id"
      ,"cast(eventTimestamp as long) * 1000 as time"
      , "cast(eventTimestamp as long) as tstamp"
      , "1.2 as version"
      , "ucase(wheelLocation) as location"
      , "0 as duration"
      , "0 as previous_active_duration"
      , "tyrepressureStatus"
      , "tyreOverTempStatus"
      , "batteryStatus"
      , "tyreFastPressureLossStatus"
    )
      .withColumn("resource",
        when($"tyrepressureStatus" between(0,6)
          , "events/warnings/pressure"
        ).otherwise(
          when($"tyreOverTempStatus" isin (0,1)
            , "events/warnings/temperature"
          ).otherwise(
            when($"batteryStatus" >= 0
              , "events/warnings/battery"
            ).otherwise(
              when($"tyreFastPressureLossStatus" isin (0,1)
                , "events/warnings/fast-pressure-loss"
              )
            )
          )
        )
      )
      .withColumn("active"
        , when(
          ($"tyrepressureStatus" between(1,6)) || ($"tyreOverTempStatus" === 1) || ($"tyreFastPressureLossStatus" === 1) || ($"batteryStatus" === 0)
          , 1
        ).otherwise(0)
      )
      .withColumn("category"
        , when($"resource" === "events/warnings/pressure"
          , udf_mapTypePressureStatus($"tyrepressureStatus")
        ).otherwise(
          when($"resource" === "events/warnings/temperature"
            , 1
          ).otherwise(
            when($"resource" === "events/warnings/fast-pressure-loss"
              , 0
            ).otherwise(0)
          )
        )
      )
  }

  def generatePressureAlertHub1_1(decode_mesg: DataFrame): DataFrame = {
    decode_mesg.selectExpr(
      "'tpms' as service"
      , "deviceEsn as device_id"
      ,"cast(eventTimestamp as long) * 1000 as time"
      , "cast(eventTimestamp as long) as tstamp"
      , "1.2 as version"
      , "ucase(wheelLocation) as location"
      , "0 as duration"
      , "0 as previous_active_duration"
      , "PressAlertLow1Active"
      , "PressAlertLow2Active"
      , "PressAlertHigh1Active"
      , "TemperatureAlertActive"
    )
      .withColumn("resource",
        when(
          ($"PressAlertLow1Active" === 1)
          || ($"PressAlertLow2Active" === 1)
          || ($"PressAlertHigh1Active" === 1)
          , "events/warnings/pressure"
        ).otherwise(
          when($"TemperatureAlertActive" === 1
            , "events/warnings/temperature"
          )
        )
      )
      .withColumn("active"
        , when(
          ($"PressAlertLow1Active" === 1)
            || ($"PressAlertLow2Active" === 1)
            || ($"PressAlertHigh1Active" === 1)
          || ($"TemperatureAlertActive" === 1)
          , 1
        ).otherwise(0)
      )
      .withColumn("category"
        , when( $"resource" === "events/warnings/pressure"
          , when(
          ($"PressAlertLow1Active" === 1) && ($"PressAlertLow2Active" === 0),2
          ).otherwise(
            when($"PressAlertLow2Active" === 1,3).otherwise(
              when($"PressAlertHigh1Active" === 1,1).otherwise(
              0
              )
            )
          )
        ).otherwise(
          when( $"resource" === "events/warnings/temperature"
            , when(
              ($"TemperatureAlertActive" === 1) ,1
            ).otherwise(0)
          )
        )
      )
  }

  def XirgoAlert2TPMSStandard(df: DataFrame): DataFrame = {
    df.select($"service"
      ,$"resource"
      ,$"device_id"
      ,$"version"
      ,$"time"
      ,$"location"
      ,struct(
        $"location"
        ,struct(
          $"active"
          ,$"duration"
          ,$"previous_active_duration"
        ) as "event"
        ,$"category"
      ) as "data"
      ,$"tstamp"
    )
      .select($"device_id",$"time",$"tstamp",struct($"service",$"resource",$"version",$"time",$"data") as "evt",$"location")
      .select($"device_id" as "deviceId",lit("partner_device") as "device_name",lit("FedEx") as "customer",$"time",$"tstamp",$"evt",$"location")
  }

  def filterOutInvalidMessage(df: DataFrame, version: String): DataFrame = {
    df.where($"body" cast "string" rlike (".*\"service\":\"[a-zA-z/]+\".*"))
      .where($"body" cast "string" rlike (".*\"resource\":\"[a-zA-z/]+\".*"))
      .where($"body" cast "string" rlike (".*\"data\":.*"))
      .where($"body" cast "string" rlike (".*\"version\":\"" + version + "\".*"))
  }

  def processBatch(batchDF: Dataset[Row], batchId: Long): Unit = {
    batchDF.persist()

    if (pipelineConfig.getBoolean("persist_local_copy") || pipelineConfig.getBoolean("in_fedex_debug")) {
      // persist raw data as received from the message bus
      batchDF.write
        .partitionBy("consumed_timestamp")
        .format("parquet")
        .mode("append")
        .option("mergeSchema", "true")
        .save(pipelineConfig.getString("data_path") + "/fedex_raw")
    }

    val event_schema = ScalaReflection.schemaFor[XirgoEventData].dataType.asInstanceOf[StructType]

    val decoded_data = batchDF
      .select(
        from_json($"value" cast "string"
          , event_schema
        ) as "events"
      ).select($"events.*")
      .where( // filter out invalid pressure and temperature values
        ($"tyreTemperature" =!= -99) && ($"tyrePressure" =!= -99)
      )

    // decode TPMS 1.0 Temp
    val temp = decoded_data.selectExpr(
      "'tpms' as service"
      ,"'wheel/temperature' as resource"
      , "deviceEsn as device_id"
      ,"cast(eventTimestamp as long) * 1000 as time"
      , "cast(eventTimestamp as long) as tstamp"
      , "1.2 as version"
      , "ucase(wheelLocation) as location"
      , "tyreTemperature"
    )
      .withColumn("temperature"
        , round( (($"tyreTemperature" cast "double") - 32) * (0.55555)
          , 1
        )
      )
      .select($"service",$"resource",$"device_id",$"location",$"version",$"time",$"tstamp",struct($"location",$"temperature") as "data")
      .select($"device_id",$"time",$"tstamp",struct($"service",$"resource",$"version",$"time",$"data") as "event")
      .withColumnRenamed("event","evt")
      .select($"device_id" as "deviceId",lit("partner_device") as "device_name",lit("FedEx") as "customer",$"time",$"tstamp",$"evt")
      .select(concat_ws("-",$"deviceId",$"time") as "key",to_json( struct($"deviceId",$"tstamp",$"customer",$"evt")) as "value")

    // decode TPMS 1.0 Pressure
    val pressr = decoded_data.selectExpr(
      "'tpms' as service"
      ,"'wheel/pressure' as resource"
      , "deviceEsn as device_id"
      ,"cast(eventTimestamp as long) * 1000 as time"
      , "cast(eventTimestamp as long) as tstamp"
      , "1.2 as version"
      , "ucase(wheelLocation) as location"
      , "targetNomPressure as temp_comp"
      , "(tyrePressure * 68.9476) as measured"
    )
      .select($"service",$"resource",$"device_id",$"location",$"version",$"time",$"tstamp",struct($"location",struct($"measured",$"temp_comp") as "pressure") as "data")
      .select($"device_id",$"time",$"tstamp",struct($"service",$"resource",$"version",$"time",$"data") as "event")
      .withColumnRenamed("event","evt")
      .select($"device_id" as "deviceId",lit("partner_device") as "device_name",lit("FedEx") as "customer",$"time",$"tstamp",$"evt")
      .select(concat_ws("-",$"deviceId",$"time") as "key",to_json( struct($"deviceId",$"tstamp",$"customer",$"evt")) as "value")

    // create battery mesage
    val batt = decoded_data.selectExpr(
      "'tpms' as service"
      ,"'wheel/battery' as resource"
      , "deviceEsn as device_id"
      ,"cast(eventTimestamp as long) * 1000 as time"
      , "cast(eventTimestamp as long) as tstamp"
      , "1.2 as version"
      , "ucase(wheelLocation) as location"
      , "batteryStatus as battery"
    )
      .select($"service",$"resource",$"device_id",$"location",$"version",$"time",$"tstamp",struct($"location",$"battery") as "data")
      .select($"device_id",$"time",$"tstamp",struct($"service",$"resource",$"version",$"time",$"data") as "event")
      .withColumnRenamed("event","evt")
      .select($"device_id" as "deviceId",lit("partner_device") as "device_name",lit("FedEx") as "customer",$"time",$"tstamp",$"evt")
      .select(concat_ws("-",$"deviceId",$"time") as "key",to_json( struct($"deviceId",$"tstamp",$"customer",$"evt")) as "value")

    // create GnssPos mesage
    val gpspos = decoded_data.selectExpr(
      "'gnss' as service"
      ,"'position' as resource"
      , "deviceEsn as device_id"
      ,"cast(eventTimestamp as long) * 1000 as time"
      , "cast(eventTimestamp as long) as tstamp"
      , "1.2 as version"
      , "latitude"
      , "longitude"
      , "altitude"
    )
      .select($"service",$"resource",$"device_id",$"version",$"time",$"tstamp",struct($"latitude",$"longitude",$"altitude") as "data")
      .select($"device_id",$"time",$"tstamp",struct($"service",$"resource",$"version",$"time",$"data") as "event")
      .withColumnRenamed("event","evt")
      .select($"device_id" as "deviceId",lit("partner_device") as "device_name",lit("FedEx") as "customer",$"time",$"tstamp",$"evt")
      .select(concat_ws("-",$"deviceId",$"time") as "key",to_json( struct($"deviceId",$"tstamp",$"customer",$"evt")) as "value")

    // create GnssTime mesage
    val gpstime = decoded_data.selectExpr(
      "'gnss' as service"
      ,"'time' as resource"
      , "deviceEsn as device_id"
      ,"cast(eventTimestamp as long) * 1000 as time"
      , "cast(eventTimestamp as long) as tstamp"
      , "1.2 as version"
    )
      .select($"service",$"resource",$"device_id",$"version",$"time",$"tstamp",struct($"time") as "data")
      .select($"device_id",$"time",$"tstamp",struct($"service",$"resource",$"version",$"time",$"data") as "event")
      .withColumnRenamed("event","evt")
      .select($"device_id" as "deviceId",lit("partner_device") as "device_name",lit("FedEx") as "customer",$"time",$"tstamp",$"evt")
      .select(concat_ws("-",$"deviceId",$"time") as "key",to_json( struct($"deviceId",$"tstamp",$"customer",$"evt")) as "value")

    // create velocity mesage
    val gps_velcty = decoded_data.selectExpr(
      "'gnss' as service"
      ,"'velocity' as resource"
      , "deviceEsn as device_id"
      ,"cast(eventTimestamp as long) * 1000 as time"
      , "cast(eventTimestamp as long) as tstamp"
      , "1.2 as version"
      , "gpsSpeed as speed"
      , "'0' as heading"
    )
      .select($"service",$"resource",$"device_id",$"version",$"time",$"tstamp",struct($"speed",$"heading") as "data")
      .select($"device_id",$"time",$"tstamp",struct($"service",$"resource",$"version",$"time",$"data") as "event")
      .withColumnRenamed("event","evt")
      .select($"device_id" as "deviceId",lit("partner_device") as "device_name",lit("FedEx") as "customer",$"time",$"tstamp",$"evt")
      .select(concat_ws("-",$"deviceId",$"time") as "key",to_json( struct($"deviceId",$"tstamp",$"customer",$"evt")) as "value")

    // create Hub1.1 alert message
    val alertPressureTmp = XirgoAlert2TPMSStandard(
      generatePressureAlertHub1_1(
      SetAlertFlags(
        decoded_data
        .where($"deviceType" === XirgoMapping.DEVICE_TYPE_HUB1_1.toString)
      ,88
      ,200
      ,0.88
      ,0.78
      ,1.3
      ,20)
      )
    )
      .select(
        concat_ws("-",$"deviceId",$"time") as "key"
        , to_json( struct($"deviceId",$"tstamp",$"customer",$"evt")) as "value"
        , $"deviceId"
        , $"evt.resource" as "resource"
        , $"time" as "alert_time"
        , $"location"
        , $"evt"
      )

    if (fedex_alerts_cache.isEmpty || fedex_alerts_cache.count() <= 0 ) {
      fedex_alerts_cache = alertPressureTmp.select(
         $"deviceId"
        , $"resource"
        , $"location"
        , $"alert_time"
      )
        .where($"active" === 1)
        .persist(StorageLevel.MEMORY_AND_DISK)
      fedex_alerts_cache.count()
    } else {
      // remove any closed alerts from cache
      fedex_alerts_cache = fedex_alerts_cache.join(
        alertPressureTmp.select(
          $"deviceId"
          , $"resource"
          , $"location"
          , $"alert_time" as "is_in_cache"
        )
          .where($"active" === 0)
        , Seq("deviceId","resource","location")
        ,"left"
      )
        .where($"is_in_cache" isNull)
        .drop("is_in_cache")
        .persist(StorageLevel.MEMORY_AND_DISK)
      fedex_alerts_cache.count()
    }

    val alert2send = alertPressureTmp.join(
      alertPressureTmp
        .select($"deviceId",$"location" ,$"resource" ,$"alert_time" as "is_in_cache")
        .where($"active" === 1)
      .union(
        fedex_alerts_cache.select($"deviceId",$"location",$"resource",$"alert_time" as "is_in_cache")
      )
        .groupBy("deviceId","resource","location")
        .agg(
          count($"is_in_cache") as "no_of_msgs"
        )
        .where($"no_of_msgs" >= 2)
        .drop("no_of_msgs")
      , Seq("deviceId","resource","location")
    )

    val alertPressureHub_1_1 = alertPressureTmp
      .where($"active" === 0)
      .union(
        alert2send
      )
      .select(
        $"key"
        , $"value"
      )


    val hub_1_1_with_alerts = decoded_data
      .where(
        ($"deviceType" === XirgoMapping.DEVICE_TYPE_HUB1_1.toString)
      )
      .withColumn("location", upper($"wheelLocation"))
      .join(
      alertPressureTmp.select($"deviceId",$"resource",$"location",$"evt")
      , Seq("deviceId","location")
    )

    val hub_1_1_anaytic_msg = generateAnalyticsMsg(hub_1_1_with_alerts)


    // add alerts not in the cache to the cache
    fedex_alerts_cache.unpersist()

    fedex_alerts_cache = fedex_alerts_cache.union(
      fedex_alerts_cache.join(
        alertPressureTmp.select(
          $"deviceId"
          ,$"resource"
          , $"location"
          , $"alert_time" as "alert_time_new"
        ).where($"active" === 1)
        , Seq("deviceId","resource", "location")
        , "right"
      ).where($"alert_time" isNull) // send alerts present in the cache
        .withColumn("alert_time"
          , when($"alert_time" isNull, $"alert_time_new").otherwise($"alert_time")
        )
        .drop("alert_time_new")
    ).persist(StorageLevel.MEMORY_AND_DISK)

    fedex_alerts_cache.count()

    // create HubA alert message
    val alertPressureTmp_HubA = XirgoAlert2TPMSStandard(
      generatePressureAlertHubA(
        decoded_data
          .where(
            ($"deviceType" === XirgoMapping.DEVICE_TYPE_HUBA.toString)
              //&& ($"eventType" === "6131" )
          )
      )
    )

    val alertPressure_HubA = alertPressureTmp_HubA
      .select(
        concat_ws("-",$"deviceId",$"time") as "key"
        , to_json( struct($"deviceId",$"tstamp",$"customer",$"evt")) as "value"
      )

    // generate an Analytical message for each alert
    val hubA_analytics_msg = generateAnalyticsMsg(decoded_data
      .where(
        ($"deviceType" === XirgoMapping.DEVICE_TYPE_HUBA.toString)
          //&& ($"eventType" === "6131" )
      )
      .withColumn("location", upper($"wheelLocation"))
      .join(
      alertPressureTmp_HubA.select($"deviceId",$"evt",$"location")
      , Seq("deviceId","location")
    ))


    // union all records and send to raw processor
    val fedex2tmps = Seq(
        temp
        , pressr
        , batt
        , gpspos
        , gpstime
        , gps_velcty
        , alertPressureHub_1_1
      , alertPressure_HubA
      ,hub_1_1_anaytic_msg
      ,hubA_analytics_msg
      ).reduce(
      (d1,d2) => if (!d2.isEmpty) d1.union(d2) else d1
    )
      .write
      .format("kafka")
      .mode("append")
      .options(PipelineUtil.kafkaConfig)
      .option("topic", pipelineConfig.getString("partner_inject_topic"))
      .save()

    batchDF.unpersist()
  }

  def doRawEventProcessing() {

    val rawMessage =
      PipelineUtil.spark.readStream
        .format("kafka")
        .option("subscribe", pipelineConfig.getString("fedex_source_stream_topic"))
        .options(PipelineUtil.kafkaConfig)
        //.option("groupIdPrefix", pipelineConfig.getString("consumer_group"))
        .option("failOnDataLoss", "false")
        .load()
        //.withColumn("timestamp", (lit(System.currentTimeMillis())) cast "long")
        .withColumn("consumed_timestamp"
          , getPartitonTimeStamp(pipelineConfig.getString("received_timestamp_format"))

        )

    rawMessage.writeStream
      .trigger(Trigger.ProcessingTime(PipelineUtil.processing_trigger_time))
      //.option("checkpointLocation", pipelineConfig.getString("raw_splitter_checkpoint_location"))
      .foreachBatch(processBatch _)
      .queryName("Xirgo MessageSplitter")
      .start()
  }
}
