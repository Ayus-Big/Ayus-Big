package com.sensata.data_office.batch.jobs

import com.sensata.data_office.batch.DashBoardDataPipeline._
import com.sensata.data_office.data._
import com.sensata.data_office.pipeline.queries.CustomerDataPublisher.{asKafkaConnectJsonMessage, setNullableStateForAllColumns}
import com.sensata.data_office.utilities.Analytics._
import com.sensata.data_office.utilities.PipelineUtil
import com.sensata.data_office.utilities.PipelineUtil.{wheelalerteventfact,vehicleeventfact,wheeleventfact,leakeventfact}
import org.apache.spark.sql.catalyst.ScalaReflection
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{DateType, StructType}
import org.apache.spark.sql.{Column, DataFrame, Dataset, Row}
import org.apache.spark.storage.StorageLevel

import java.time.LocalDateTime
import java.time.format.DateTimeFormatter



object FactsDataLoader {

  val current_snapshot_folder = LocalDateTime.now().format(
    DateTimeFormatter.ofPattern("yyyyMMddHH0000")
  )

  import PipelineUtil.spark.implicits._


  def loadWheelAlertEventsData(abatchDF: DataFrame, run_level: String): Unit = {

    val wheel_alert_data = abatchDF
      .repartition(10)
      .persist(StorageLevel.MEMORY_AND_DISK)

    val wheel_alert_schema = ScalaReflection.schemaFor[DashBoardWheelAlertFactRecordHistory].dataType.asInstanceOf[StructType]
    //val wheel_alert_schema = ScalaReflection.schemaFor[DashBoardWheelAlertFactRecordHistoryNew].dataType.asInstanceOf[StructType]

    /*val cols_list = wheel_alert_schema.fields.toList.map(_.name)


     val sensprod_alert_fact_df = wheelalerteventfact(wheel_alert_data)
      .filter($"asset_code".contains("SENSPROD"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[DashBoardWheelAlertFactRecordHistoryNew]
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_sensprod.getProperty("jdbcuri")
        ,s"data.wheel_event_fact_direct"
        , PipelineUtil.postgresdb_prop_sensprod
      )

    val dske_alert_fact_df = wheelalerteventfact(wheel_alert_data)
      .filter($"asset_code".contains("DSKE"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[DashBoardWheelAlertFactRecordHistoryNew]
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_dske.getProperty("jdbcuri")
        ,s"data.wheel_event_fact_direct"
        , PipelineUtil.postgresdb_prop_dske
      )

    val fedx_alert_fact_df = wheelalerteventfact(wheel_alert_data)
      .filter($"asset_code".contains("FEDX"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[DashBoardWheelAlertFactRecordHistoryNew]
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_fedx.getProperty("jdbcuri")
        ,s"data.wheel_event_fact_direct"
        , PipelineUtil.postgresdb_prop_fedx
      )

    val pnke_alert_fact_df = wheelalerteventfact(wheel_alert_data)
      .filter($"asset_code".contains("PNKE"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[DashBoardWheelAlertFactRecordHistoryNew]
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_pnke.getProperty("jdbcuri")
        ,s"data.wheel_event_fact_direct"
        , PipelineUtil.postgresdb_prop_pnke
      )

    val ppsi_alert_fact_df = wheelalerteventfact(wheel_alert_data)
      .filter($"asset_code".contains("PPSI"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[DashBoardWheelAlertFactRecordHistoryNew]
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_ppsi.getProperty("jdbcuri")
        ,s"data.wheel_event_fact_direct"
        , PipelineUtil.postgresdb_prop_ppsi
      )

    val ryes_alert_fact_df = wheelalerteventfact(wheel_alert_data)
      .filter($"asset_code".contains("RYES"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[DashBoardWheelAlertFactRecordHistoryNew]
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_ryes.getProperty("jdbcuri")
        ,s"data.wheel_event_fact_direct"
        , PipelineUtil.postgresdb_prop_ryes
      )

    val wrnr_alert_fact_df = wheelalerteventfact(wheel_alert_data)
      .filter($"asset_code".contains("WRNR"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[DashBoardWheelAlertFactRecordHistoryNew]
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_wrnr.getProperty("jdbcuri")
        ,s"data.wheel_event_fact_direct"
        , PipelineUtil.postgresdb_prop_wrnr
      )*/

    // store to datalake
    if (pipelineConfig.getBoolean("persist_local_copy")) {
      wheel_alert_data
        /*.withColumn("run_date"
          , date_format(current_timestamp(), "yyyyMMddHH0000")
        )*/
        .write
        .partitionBy("asset_code")
        .format("parquet")
        .mode("overwrite")
        .option("mergeSchema", "true")
        .save(pipelineConfig.getString("dest_data_path") + s"wheel_alert_events/run_date=$current_snapshot_folder")
    }

       asKafkaConnectJsonMessage(selectNCastDataFrameAsSchema(wheel_alert_data,wheel_alert_schema)
        //,wheel_alert_schema
        , setNullableStateForAllColumns(wheel_alert_schema, true)
        , Seq( "wheel_location","resource","asset_code", "schema", "payload", "topic", "topic_id").toList
        , true
    )

    .select(concat_ws("-", $"resource",$"wheel_location",$"asset_code") as "key"
        , to_json(struct($"schema", $"payload")) as "value"
        , $"topic"
      )
      .coalesce(3)
      .write
      .format("kafka")
      .mode("append")
      .options(PipelineUtil.kafkaConfig)
      //.option("groupIdPrefix", pipelineConfig.getString("consumer_group"))
      .save()

    abatchDF.unpersist()
  }

  def loadVehicleEventsData(abatchDF: DataFrame, run_level: String): Unit = {

    val vehicle_fact_data = abatchDF
      .repartition(10)
      .persist(StorageLevel.MEMORY_AND_DISK)

    val vhcle_schema = ScalaReflection.schemaFor[DashBoardVehicleFactRecordHistory].dataType.asInstanceOf[StructType]
   // val vhcle_schema = ScalaReflection.schemaFor[DashBoardVehicleFactRecordHistoryNew].dataType.asInstanceOf[StructType]

  /*  val cols_list = vhcle_schema.fields.toList.map(_.name)

     val sensprod_vehicle_fact_df = vehicleeventfact(vehicle_fact_data)
      .filter($"asset_code".contains("SENSPROD"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[DashBoardVehicleFactRecordHistoryNew]
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_sensprod.getProperty("jdbcuri")
        ,s"data.vehicle_data_fact_direct"
        , PipelineUtil.postgresdb_prop_sensprod
      )

    val dske_vehicle_fact_df = vehicleeventfact(vehicle_fact_data)
      .filter($"asset_code".contains("DSKE"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[DashBoardVehicleFactRecordHistoryNew]
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_dske.getProperty("jdbcuri")
        ,s"data.vehicle_data_fact_direct"
        , PipelineUtil.postgresdb_prop_dske
      )

    val fedx_vehicle_fact_df = vehicleeventfact(vehicle_fact_data)
      .filter($"asset_code".contains("FEDX"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[DashBoardVehicleFactRecordHistoryNew]
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_fedx.getProperty("jdbcuri")
        ,s"data.vehicle_data_fact_direct"
        , PipelineUtil.postgresdb_prop_fedx
      )

    val pnke_vehicle_fact_df = vehicleeventfact(vehicle_fact_data)
      .filter($"asset_code".contains("PNKE"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[DashBoardVehicleFactRecordHistoryNew]
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_pnke.getProperty("jdbcuri")
        ,s"data.vehicle_data_fact_direct"
        , PipelineUtil.postgresdb_prop_pnke
      )

    val ppsi_vehicle_fact_df = vehicleeventfact(vehicle_fact_data)
      .filter($"asset_code".contains("PPSI"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[DashBoardVehicleFactRecordHistoryNew]
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_ppsi.getProperty("jdbcuri")
        ,s"data.vehicle_data_fact_direct"
        , PipelineUtil.postgresdb_prop_ppsi
      )

    val ryes_vehicle_fact_df = vehicleeventfact(vehicle_fact_data)
      .filter($"asset_code".contains("RYES"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[DashBoardVehicleFactRecordHistoryNew]
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_ryes.getProperty("jdbcuri")
        ,s"data.vehicle_data_fact_direct"
        , PipelineUtil.postgresdb_prop_ryes
      )

    val wrnr_vehicle_fact_df = vehicleeventfact(vehicle_fact_data)
      .filter($"asset_code".contains("WRNR"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[DashBoardVehicleFactRecordHistoryNew]
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_wrnr.getProperty("jdbcuri")
        ,s"data.vehicle_data_fact_direct"
        , PipelineUtil.postgresdb_prop_wrnr
      )*/

    // store to datalake
    if (pipelineConfig.getBoolean("persist_local_copy")) {
      vehicle_fact_data
        /*.withColumn("run_date"
          , date_format(current_timestamp(), "yyyyMMddHH0000")
        )*/
        .write
        .partitionBy("asset_code")
        .format("parquet")
        .mode("overwrite")
        .option("mergeSchema", "true")
        .save(pipelineConfig.getString("dest_data_path") + s"vehicle_fact_events/run_date=$current_snapshot_folder")
    }

     asKafkaConnectJsonMessage(selectNCastDataFrameAsSchema(vehicle_fact_data,vhcle_schema)
      , vhcle_schema
      , Seq( "service","device_id","asset_code", "schema", "payload", "topic", "topic_id").toList
    )
      .select(concat_ws("-",$"service" ,$"device_id",$"asset_code") as "key"
        , to_json(struct($"schema", $"payload")) as "value"
        , $"topic"
      )
      .coalesce(3)
      .write
      .format("kafka")
      .mode("append")
      .options(PipelineUtil.kafkaConfig)
      //.option("groupIdPrefix", pipelineConfig.getString("consumer_group"))
      .save()

    abatchDF.unpersist()

  }

  def loadWheelEventsData(abatchDF: DataFrame, run_level: String): Unit = {

    val wheel_fact_data = abatchDF
      .repartition(10)
      .persist(StorageLevel.MEMORY_AND_DISK)

    val wheel_schema = ScalaReflection.schemaFor[DashBoardWheelFactRecordHistory].dataType.asInstanceOf[StructType]

  /*  val cols_list = wheel_schema.fields.toList.map(_.name)

     val sensprod_wheel_fact_df = wheeleventfact(wheel_fact_data)
      .filter($"asset_code".contains("SENSPROD"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[DashBoardWheelFactRecordHistory]
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_sensprod.getProperty("jdbcuri")
        ,s"data.wheel_data_fact_direct"
        , PipelineUtil.postgresdb_prop_sensprod
      )

    val dske_wheel_fact_df = wheeleventfact(wheel_fact_data)
      .filter($"asset_code".contains("DSKE"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[DashBoardWheelFactRecordHistory]
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_dske.getProperty("jdbcuri")
        ,s"data.wheel_data_fact_direct"
        , PipelineUtil.postgresdb_prop_dske
      )

    val fedx_wheel_fact_df = wheeleventfact(wheel_fact_data)
      .filter($"asset_code".contains("FEDX"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[DashBoardWheelFactRecordHistory]
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_fedx.getProperty("jdbcuri")
        ,s"data.wheel_data_fact_direct"
        , PipelineUtil.postgresdb_prop_fedx
      )

    val pnke_wheel_fact_df = wheeleventfact(wheel_fact_data)
      .filter($"asset_code".contains("PNKE"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[DashBoardWheelFactRecordHistory]
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_pnke.getProperty("jdbcuri")
        ,s"data.wheel_data_fact_direct"
        , PipelineUtil.postgresdb_prop_pnke
      )

    val ppsi_wheel_fact_df = wheeleventfact(wheel_fact_data)
      .filter($"asset_code".contains("PPSI"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[DashBoardWheelFactRecordHistory]
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_ppsi.getProperty("jdbcuri")
        ,s"data.wheel_data_fact_direct"
        , PipelineUtil.postgresdb_prop_ppsi
      )

    val ryes_wheel_fact_df = wheeleventfact(wheel_fact_data)
      .filter($"asset_code".contains("RYES"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[DashBoardWheelFactRecordHistory]
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_ryes.getProperty("jdbcuri")
        ,s"data.wheel_data_fact_direct"
        , PipelineUtil.postgresdb_prop_ryes
      )

    val wrnr_wheel_fact_df = wheeleventfact(wheel_fact_data)
      .filter($"asset_code".contains("WRNR"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[DashBoardWheelFactRecordHistory]
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_wrnr.getProperty("jdbcuri")
        ,s"data.wheel_data_fact_direct"
        , PipelineUtil.postgresdb_prop_wrnr
      )*/

    // store to datalake
    if (pipelineConfig.getBoolean("persist_local_copy")) {
      wheel_fact_data
        /*.withColumn("run_date"
          , date_format(current_timestamp(), "yyyyMMddHH0000")
        )*/
        .write
        .partitionBy("asset_code")
        .format("parquet")
        .mode("overwrite")
        .option("mergeSchema", "true")
        .save(pipelineConfig.getString("dest_data_path") + s"wheel_fact_events/run_date=$current_snapshot_folder")
    }

      asKafkaConnectJsonMessage(selectNCastDataFrameAsSchema(wheel_fact_data,wheel_schema)
      , wheel_schema
      , Seq( "location","device_id","asset_code", "schema", "payload", "topic", "topic_id").toList
    )
      .select(concat_ws("-",$"location",$"device_id",$"asset_code") as "key"
        , to_json(struct($"schema", $"payload")) as "value"
        , $"topic"
      )
      .coalesce(3)
      .write
      .format("kafka")
      .mode("append")
      .options(PipelineUtil.kafkaConfig)
     //.option("groupIdPrefix", pipelineConfig.getString("consumer_group"))
      .save()

    abatchDF.unpersist()
  }

  def loadLeakDetectionData(abatchDF: DataFrame, run_level: String): Unit = {

    val leak_data = abatchDF
      .repartition(10)
      .persist(StorageLevel.MEMORY_AND_DISK)

    val leak_schema = ScalaReflection.schemaFor[LeakDetectionFactRecordHistory].dataType.asInstanceOf[StructType]

    val cols_list = leak_schema.fields.toList.map(_.name)

      val sensprod_leak_fact_df = leakeventfact(leak_data)
      .filter($"asset_code".contains("SENSPROD"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[LeakDetectionFactRecordHistory]
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_sensprod.getProperty("jdbcuri")
        ,s"data.leak_detection_fact_direct"
        , PipelineUtil.postgresdb_prop_sensprod
      )

    val dske_leak_fact_df = leakeventfact(leak_data)
      .filter($"asset_code".contains("DSKE"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[LeakDetectionFactRecordHistory]
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_dske.getProperty("jdbcuri")
        ,s"data.leak_detection_fact_direct"
        , PipelineUtil.postgresdb_prop_dske
      )

    val fedx_leak_fact_df = leakeventfact(leak_data)
      .filter($"asset_code".contains("FEDX"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[LeakDetectionFactRecordHistory]
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_fedx.getProperty("jdbcuri")
        ,s"data.leak_detection_fact_direct"
        , PipelineUtil.postgresdb_prop_fedx
      )

    val pnke_leak_fact_df = leakeventfact(leak_data)
      .filter($"asset_code".contains("PNKE"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[LeakDetectionFactRecordHistory]
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_pnke.getProperty("jdbcuri")
        ,s"data.leak_detection_fact_direct"
        , PipelineUtil.postgresdb_prop_pnke
      )

    val ppsi_leak_fact_df = leakeventfact(leak_data)
      .filter($"asset_code".contains("PPSI"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[LeakDetectionFactRecordHistory]
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_ppsi.getProperty("jdbcuri")
        ,s"data.leak_detection_fact_direct"
        , PipelineUtil.postgresdb_prop_ppsi
      )

    val ryes_leak_fact_df = leakeventfact(leak_data)
      .filter($"asset_code".contains("RYES"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[LeakDetectionFactRecordHistory]
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_ryes.getProperty("jdbcuri")
        ,s"data.leak_detection_fact_direct"
        , PipelineUtil.postgresdb_prop_ryes
      )

    val wrnr_leak_fact_df = leakeventfact(leak_data)
      .filter($"asset_code".contains("WRNR"))
      .select(cols_list.map(m=>col(m)):_*)
      .as[LeakDetectionFactRecordHistory]
      .write.mode("append").format("jdbc")
      .jdbc(PipelineUtil.postgresdb_prop_wrnr.getProperty("jdbcuri")
        ,s"data.leak_detection_fact_direct"
        , PipelineUtil.postgresdb_prop_wrnr
      )


  /*  asKafkaConnectJsonMessage(selectNCastDataFrameAsSchema(leak_data,leak_schema)
      , leak_schema
      , Seq( "wheel_location","device_id","asset_code", "schema", "payload", "topic", "topic_id").toList
    )
      .select(concat_ws("-",$"wheel_location",$"device_id",$"asset_code") as "key"
        , to_json(struct($"schema", $"payload")) as "value"
        , $"topic"
      )
      .coalesce(3)
     .write
     .format("kafka")
     .mode("append")
     .options(PipelineUtil.kafkaConfig)
    //.option("groupIdPrefix", pipelineConfig.getString("consumer_group"))
     .save()*/

    abatchDF.unpersist()

  }

  def runFactDataLoader(start_time_range: Column, end_time_range: Column, wheel_records: Dataset[Row], gps_records: Dataset[Row]
                             , alerts_records: Dataset[Row], alerts_snapshot_records: Dataset[Row], leak_records: Dataset[Row],unit_of_run: String): Unit = {

    val lastupdated_timestamp = System.currentTimeMillis() / 1000

    val WheelsMessage = wheel_records
      .where(
        ($"reported_time" between(start_time_range, end_time_range))
      )
      .join(
        customer_data
        , Seq("device_id")
        , "left"
      )
      .drop("reported_device_id")
      .withColumn("asset_id", when($"v_asset_id" isNull, "N/A").otherwise($"v_asset_id"))
      .withColumn("asset_code", when($"v_asset_code" isNull, "N/A").otherwise($"v_asset_code"))
      .withColumn("company", when($"company_name" isNull, "N/A").otherwise($"company_name"))
      .withColumn("fleet", when($"fleet_name" isNull, "N/A").otherwise($"fleet_name"))
      .withColumn("asset_name", when($"company_asset_name" isNull, "N/A").otherwise($"company_asset_name"))
      .withColumn("wheel_config", when($"v_wheel_config" isNull, "N/A").otherwise($"v_wheel_config"))
      .withColumn("image_url", when($"v_image_url" isNull, "N/A").otherwise($"v_image_url"))
      .withColumn("topic_id", when($"v_topic_id" isNull, "all").otherwise($"v_topic_id"))
      .withColumn("topic", concat_ws("-", $"topic_id", lit("wheel-tpms-fact-table")))
      .withColumn("no_axles", when($"v_no_axles" isNull, "0").otherwise($"v_no_axles"))
      .withColumn("location",upper($"location"))
      .withColumn("location_name", $"location")
      .withColumn("wheel_key", concat($"device_id", $"asset_name", $"location"))
      .withColumn("asset_wheel_config_key", concat($"asset_name", $"wheel_config"))
      .withColumn("image_url", when($"v_image_url" isNull, "N/A").otherwise($"v_image_url"))
      /*.withColumn("agg_date"
        , to_timestamp(
          from_unixtime($"reported_time" cast "long", run_config.getOrElse(unit_of_run, default_run_config)._6)
        )

              )*/
      .withColumn("agg_date", col("reported_time").cast(DateType))
      .where( ($"asset_code" isNotNull) && ($"asset_code" =!= "N/A") ) // exclude null matches
      .withColumn("reported_time", $"reported_time" cast "timestamp")
      .persist(StorageLevel.MEMORY_AND_DISK)

    val alert_recrds_cleaned = alerts_records
      .where(
        ($"reported_time" between(start_time_range, end_time_range))
      )
      .join(
        customer_data
        , Seq("device_id")
        , "left"
      )
      .drop("reported_device_id")
      .withColumn("asset_id", when($"v_asset_id" isNull, "N/A").otherwise($"v_asset_id"))
      .withColumn("asset_code", when($"v_asset_code" isNull, "N/A").otherwise($"v_asset_code"))
      .withColumn("company", when($"company_name" isNull, "N/A").otherwise($"company_name"))
      .withColumn("fleet", when($"fleet_name" isNull, "N/A").otherwise($"fleet_name"))
      .withColumn("asset_name", when($"company_asset_name" isNull, "N/A").otherwise($"company_asset_name"))
      .withColumn("wheel_config", when($"v_wheel_config" isNull, "N/A").otherwise($"v_wheel_config"))
      .withColumn("image_url", when($"v_image_url" isNull, "N/A").otherwise($"v_image_url"))
      .withColumn("topic_id", when($"v_topic_id" isNull, "all").otherwise($"v_topic_id"))
      .withColumn("topic", concat_ws("-", $"topic_id", lit("alert-fact-table")))
      .withColumn("no_axles", when($"v_no_axles" isNull, "0").otherwise($"v_no_axles"))
      .withColumn("location",upper($"location"))
      .withColumn("location_name", $"location")
      .withColumn("wheel_key", concat($"device_id", $"asset_name", $"location"))
      .withColumn("asset_wheel_config_key", concat($"asset_name", $"wheel_config"))
       /* .withColumn("agg_date"
        , to_timestamp(
          from_unixtime($"reported_time" cast "long", run_config.getOrElse(unit_of_run, default_run_config)._6)
        )
      )*/
      .withColumn("agg_date", col("reported_time").cast(DateType))
      .withColumn("alert_start_time"
      , when( $"alert_start_time" like ("2000-01%")
        , lit(null) cast "string"
        ).otherwise($"alert_start_time")
      )
      .withColumn("alert_end_time"
        , when( $"alert_end_time" like ("2000-01%")
          , lit(null) cast "string"
        ).otherwise($"alert_end_time")
      )
      .withColumn("event_start_time"
        , when( $"event_start_time" like ("2000-01%")
          , lit(null) cast "string"
        ).otherwise($"event_start_time")
      )
      .withColumn("alert_name", setAlertNameValue())
      .where(
        ($"event_start_time" isNotNull) && ($"alert_start_time" isNotNull)
      )


    val alerts_analytics_v2 = alert_recrds_cleaned.where($"schema_version" >= "2.0")
      .withColumn("service", lit("tpms"))

      .withColumn("temperature", when($"temperature_f" isNotNull, $"temperature_f")
        .otherwise(lit(null)))
      .withColumn("pressure", when($"pressure_psi" isNotNull, $"pressure_psi")
        .otherwise(lit(null)))
      .withColumn("temp_comp_pressure", lit(null))
      .select($"reported_time" cast "timestamp",
        $"service",
        $"resource",
        $"location",
        $"category",
        $"asset_id",
        $"asset_code",
        $"temperature",
        $"temperature_f",
        $"pressure",
        $"pressure_psi",
        $"temp_comp_pressure")

    val alertsMessage = correctAlertDateTimes(alert_recrds_cleaned)
      .where(
        ($"reported_time" between(start_time_range, end_time_range))
      )

     // get alert records with tpms for analytics msg
    val alerts_metrics_data = flattenAnalyticalMessage(
      alerts_snapshot_records
     .where(
        ($"reported_time" between(start_time_range, end_time_range))
      )
      .join(
        customer_data
        , Seq("device_id")
        , "left"
      )
      .drop("reported_device_id")
      .withColumn("asset_id", when($"v_asset_id" isNull, "N/A").otherwise($"v_asset_id"))
      .withColumn("asset_code", when($"v_asset_code" isNull, "N/A").otherwise($"v_asset_code"))
      .withColumn("reported_time", $"reported_time" cast "timestamp")
    )
      .persist(StorageLevel.MEMORY_AND_DISK)

    alerts_metrics_data.count()

    val alerts_metrics_final = alerts_metrics_data.union(alerts_analytics_v2)

    val GpsMessage = gps_records
      .where(
        ($"reported_time" between(start_time_range, end_time_range))
      )
      .join(
        customer_data
        , Seq("device_id")
        , "left"
      )
      .drop("reported_device_id")
      .withColumn("asset_id", when($"v_asset_id" isNull, "N/A").otherwise($"v_asset_id"))
      .withColumn("asset_code", when($"v_asset_code" isNull, "N/A").otherwise($"v_asset_code"))
      .withColumn("company", when($"company_name" isNull, "N/A").otherwise($"company_name"))
      .withColumn("fleet", when($"fleet_name" isNull, "N/A").otherwise($"fleet_name"))
      .withColumn("asset_name", when($"company_asset_name" isNull, "N/A").otherwise($"company_asset_name"))
      .withColumn("wheel_config", when($"v_wheel_config" isNull, "N/A").otherwise($"v_wheel_config"))
      .withColumn("image_url", when($"v_image_url" isNull, "N/A").otherwise($"v_image_url"))
      .withColumn("topic_id", when($"v_topic_id" isNull, "all").otherwise($"v_topic_id"))
      .withColumn("topic", concat_ws("-", $"topic_id", lit("vehicle-fact-table")))
      .withColumn("no_axles", when($"v_no_axles" isNull, "0").otherwise($"v_no_axles"))
     /* .withColumn("agg_date"
        , to_timestamp(
          from_unixtime($"reported_time" cast "long", run_config.getOrElse(unit_of_run, default_run_config)._6)
        )
      )*/
      .withColumn("agg_date", col("reported_time").cast(DateType))
      .withColumn("reported_time", $"reported_time" cast "timestamp")
      .persist(StorageLevel.MEMORY_AND_DISK)

    // get list of customers to be processed
    val cust_list = WheelsMessage.select($"topic_id").dropDuplicates("topic_id")
      .union(
        GpsMessage.select($"topic_id").dropDuplicates("topic_id")
      ).union(
      alertsMessage.select($"topic_id").dropDuplicates("topic_id")
    )
      .withColumnRenamed("topic_id","customer")
      .dropDuplicates("customer")
      .persist(StorageLevel.MEMORY_AND_DISK)

   /* // get list of customers to be processed - for future release
    val cust_list = WheelsMessage.select($"asset_code").dropDuplicates("asset_code")
      .union(
        GpsMessage.select($"asset_code").dropDuplicates("asset_code")
      ).union(
      alertsMessage.select($"asset_code").dropDuplicates("asset_code")
    )
      .filter(($"asset_code".isNotNull) && ($"asset_code" =!= "N/A"))
      .withColumn("customer", regexp_replace($"asset_code","[^A-Z]",""))
      .dropDuplicates("customer")
      .persist(StorageLevel.MEMORY_AND_DISK)

    println("*******************cust_list*********************")
    cust_list.show(false)*/

    // send starting message
    cust_list
    .withColumn("notification",lit("fact-started"))
      .withColumn("datetime"
        ,to_timestamp(
          from_unixtime(lit(lastupdated_timestamp), "yyyy-MM-dd HH:mm:ss")
        )
      )
      .groupBy("notification").agg(
      collect_list("customer").as("customers")
      , first($"datetime", ignoreNulls = true) as "datetime"
    ).select($"notification" as "key"
      , to_json(
        struct(
          $"notification"
          , $"customers"
          , $"datetime"
        )
      ) as "value"
    )
      .write
      .format("kafka")
      .mode("append")
      .options(PipelineUtil.kafkaConfig)
      .option("topic", pipelineConfig.getString("batch-run-notifications"))
      .save()

    // get asset active datetime by day
    val asset_active_days = getAssetActivityDays(GpsMessage,WheelsMessage,alertsMessage)
      .persist(StorageLevel.MEMORY_AND_DISK)

     // get all trip information
    val vehicleTrips = getTripInformation(GpsMessage).persist(StorageLevel.MEMORY_AND_DISK)
    val distance_with_alerts = getDistanceWithAlerts(GpsMessage)

    val alertEvents = getAlertEventTimes(alertsMessage)
      .withColumn("created_at"
        , to_timestamp(
          from_unixtime(lit(lastupdated_timestamp), "yyyy-MM-dd HH:mm:ss")
        )
      )
      .withColumn("time_id"
        ,date_format($"reported_time", "HHmmss") cast "string"
      )
      .withColumn("date_id"
        ,date_format($"reported_time", "yyyyMMdd") cast "long"
      )

    val alertEvents_distinct_with_alert_distance = getDistinctDistanceWithAlerts(alertEvents,distance_with_alerts) // only select 1 record from any duplicates
    val alertEvents_step2 = allocateAlertDistancetoAlerts(alertEvents,alertEvents_distinct_with_alert_distance)
    val alertEvents_step3 = allocateAlertTripInformation(alertEvents_step2,vehicleTrips)
    val alertEvents_final = allocateAlertDurationNMetric(alertEvents_step3,asset_active_days,alerts_metrics_final)
      .withColumn("service", lit("tpms-alert"))
      .withColumn("asset_id", $"asset_id" cast "long" )
      .withColumn("wheel_id", $"location")
      .withColumn("wheel_location", $"location")
      .withColumn("alert_items", split($"resource","/"))
      .withColumn("event", $"alert_items"(1))
      .withColumn("alert", $"alert_items"(2))
      .withColumn("alert_id", setAlertIdFact())
      .withColumn("event_stop_time", $"event_end_time")
      .withColumn("category_id", $"category")
      .withColumn("topic", concat_ws("-", $"topic_id", lit("alert-fact-table")))
      .drop("alert_items")
      .na.fill(
      Map(
        ("alert_duration" -> 0.0),
        ("event_duration" -> 0.0),
        ("trip_duration" -> 0.0),
        ("active_duration" -> 0.0),
        ("alert_distance" -> 0.0),
        ("trip_distance" -> 0.0),
        ("event_status" -> -1),
        ("alert_status" -> -1)
       // ("measured_temperature" -> -1.0),
      //  ("measured_pressure" -> -1.0),
      //  ("battery_status" -> 0.0)
      )
    )
      .where(
        ($"alert_status" === 1) && ($"alert_start_time" isNotNull)
      )

    val alertEvents_final_new = alertEvents_final
      .withColumn("alert"
      ,when($"event" === "dynamic-pressure-warning", "dynamic-pressure")
          .otherwise(when($"event" === "pressure-warning" , "pressure")
            .otherwise(when($"event" === "temperature-warning" , "temperature")
              .otherwise(when($"event" === "tyre-lock-warning" , "tyre-lock")
               .otherwise(when($"event" === "battery-warning" , "battery")
                .otherwise(when($"event" === "missing-sensor" , "missing-sensor")
      .otherwise($"alert")
            ) ) ) ) ) )

    loadWheelAlertEventsData(
      alertEvents_final_new
      , unit_of_run
    )

    loadVehicleEventsData(
      GpsMessage
        .withColumn("service", lit("vehicle"))
        .withColumn("asset_id", $"asset_id" cast "long" )
        .withColumn("created_at"
          , to_timestamp(
            from_unixtime(lit(lastupdated_timestamp), "yyyy-MM-dd HH:mm:ss")
          )
        )
        .withColumn("time_id"
          ,date_format($"reported_time", "HHmmss") cast "string"
        )
        .withColumn("date_id"
          ,date_format($"reported_time", "yyyyMMdd") cast "long"
        )
      , unit_of_run
    )

    loadWheelEventsData(
      WheelsMessage
        .withColumn("service", lit("tpms"))
        .withColumn("asset_id", $"asset_id" cast "long" )
        .withColumn("wheel_id", $"location")
        .withColumn("wheel_location", $"location")
        .withColumn("created_at"
          , to_timestamp(
            from_unixtime(lit(lastupdated_timestamp), "yyyy-MM-dd HH:mm:ss")
          )
        )
        .withColumn("time_id"
          ,date_format($"reported_time", "HHmmss") cast "string"
        )
        .withColumn("date_id"
          ,date_format($"reported_time", "yyyyMMdd") cast "long"
        )
      , unit_of_run
    )

    loadLeakDetectionData(
      leak_records
        .withColumn("wheel_location", $"location_name")
        .withColumn("wheel_id", $"wheel_location")
        .withColumn("service", lit("leak-detection"))
        .withColumn("topic_id", lit("all"))
        .withColumn("topic", concat_ws("-", $"topic_id", lit("leak-detection-fact")))
        .withColumn("time_id"
          ,date_format($"reported_time", "HHmmss") cast "string"
        )
        .withColumn("date_id"
          ,date_format($"reported_time", "yyyyMMdd") cast "long"
        )
        .withColumn("created_at"
          , to_timestamp(
            from_unixtime(lit(lastupdated_timestamp), "yyyy-MM-dd HH:mm:ss")
          )
        )
        .select(
          $"service",
          $"asset_code",
          $"date_id",
          $"time_id",
          $"wheel_location",
          $"wheel_id",
          $"reported_time",
          $"asset_id",
          $"device_id",
          $"time_to_failure_summed30",
          $"alerttrigger",
          $"topic_id",
          $"topic"
        , $"created_at")
        .where(($"asset_code" isNotNull) && ($"wheel_location" isNotNull))
      , unit_of_run
    )

    Thread.sleep(5000) // wait 5 sec and send 'completed' notification

    // send end message
    cust_list
      .withColumn("notification",lit("fact-completed"))
      .withColumn("datetime"
        ,to_timestamp(
          from_unixtime(lit(System.currentTimeMillis() / 1000), "yyyy-MM-dd HH:mm:ss")
        )
      )
      .groupBy("notification").agg(
      collect_list("customer").as("customers")
      , first($"datetime", ignoreNulls = true) as "datetime"
    ).select($"notification" as "key"
      , to_json(
        struct(
          $"notification"
          , $"customers"
          , $"datetime"
        )
      ) as "value"
    )
      .write
      .format("kafka")
      .mode("append")
      .options(PipelineUtil.kafkaConfig)
      .option("topic", pipelineConfig.getString("batch-run-notifications"))
      .save()


  }
}
