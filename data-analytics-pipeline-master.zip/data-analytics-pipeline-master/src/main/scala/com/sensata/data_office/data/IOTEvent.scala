package com.sensata.data_office.data

import com.sensata.data_office.data.MessageTypes.{DATA_PLANE_1_0, DATA_PLANE_2_0}
import org.apache.spark.sql.catalyst.ScalaReflection
import org.apache.spark.sql.types.StructType

object MessageTypes {

  val WheelUnitRf: String  = "wheel/rf"
  val WheelUnitData: String = "wheel/com.sensata.data_office.data"
  val WheelInfoPressure: String = "wheel/pressure"
  val WheelInfoPressureV2: String = "wheel/pressure"
  val WheelInfoTemperature: String = "wheel/temperature"
  val WheelInfoTemperatureV2: String = "wheel/temperature"
  val WheelInfoBattery: String = "wheel/battery"
  val WheelInfoBatteryV2: String = "wheel/battery"
  val WarningEventGeneric: String = "events/warnings"
  val WarningEventPressure: String = "events/warnings/pressure"
  val WarningEventFastPressureLoss: String = "events/warnings/fast-pressure-loss"
  val WarningEventTyreBurst: String = "events/warnings/tyre-burst"
  val WarningEventTyreLock: String = "events/warnings/tyre-lock"
  val WheelWarningTemperature: String = "events/warnings/temperature"
  val WheelWarningTemperatureV2: String = "wheel/temperature-warning"
  val WheelWarningPressureV2: String = "wheel/pressure-warning"
  val WheelWarningBattery: String = "wheel/battery-warning"
  val WheelWarningDynamic: String = "wheel/dynamic-pressure-warning"
  val WheelWarningTyreLock: String = "wheel/tyre-lock-warning"
  val WheelMissingSensor: String = "wheel/missing-sensor"
  val GnssPos: String =  "position"
  val GnssTime: String = "time"
  val GnssVelocity: String = "velocity"
  val GnssDistance: String = "_dev_distance"
  val GnssHasAlerts: String = "_has_alerts"
  val AtisAlerts: String = "atis-state"
  val TtlAlerts: String = "connected-devices"
  val Kl15Alerts: String = "notify"
  val GnssMotion: String =  "motion"
  val OdometerDist: String = "distance"
  val OdometerTripDist: String = "trip-distance"


  val DATA_PLANE_2_0 = "2.0"
  val DATA_PLANE_1_0 = "1.2"

  //This is for Data Plane 0.2/1.2
  val eventTopics1 = Map(
    MessageTypes.WheelInfoPressure -> "tpms-stream-data"//"tpms-pressure-stream-data"
    ,  MessageTypes.WheelInfoTemperature -> "tpms-stream-data"//"tpms-temperature-stream-data"
    ,  MessageTypes.WheelInfoBattery -> "tpms-stream-data"//"tpms-battery-stream-data"
    ,  MessageTypes.GnssPos -> "gnss-stream-data"
    ,  MessageTypes.GnssTime -> "gnss-stream-data"
    ,  MessageTypes.GnssVelocity -> "gnss-stream-data"
    ,  MessageTypes.GnssDistance -> "gnss-stream-data"
    ,  MessageTypes.GnssHasAlerts -> "gnss-stream-data"
    ,  MessageTypes.GnssMotion -> "gnss-stream-data"
    ,  MessageTypes.AtisAlerts -> "gnss-stream-data"
    ,  MessageTypes.TtlAlerts -> "gnss-stream-data"
    ,  MessageTypes.Kl15Alerts -> "gnss-stream-data"
    ,  MessageTypes.WarningEventGeneric -> "tpms-alerts-event-data"
    ,  MessageTypes.WheelWarningTemperature -> "tpms-alerts-event-data"
    ,  MessageTypes.WarningEventPressure -> "tpms-alerts-event-data"
    ,  MessageTypes.WarningEventFastPressureLoss -> "tpms-alerts-event-data"
    ,  MessageTypes.WarningEventTyreBurst -> "tpms-alerts-event-data"
    ,  MessageTypes.OdometerDist -> "gnss-stream-data"
    ,  MessageTypes.OdometerTripDist -> "gnss-stream-data"
  )

  //This is for Data Plane 2.0
  val eventTopics = Map(
    MessageTypes.WheelInfoPressureV2 -> "tpms-stream-data"//"tpms-pressure-stream-data"
    ,  MessageTypes.WheelInfoTemperatureV2 -> "tpms-stream-data"//"tpms-temperature-stream-data"
    ,  MessageTypes.WheelInfoBatteryV2 -> "tpms-stream-data"//"tpms-battery-stream-data"
    ,  MessageTypes.GnssPos -> "gnss-stream-data"
    ,  MessageTypes.GnssTime -> "gnss-stream-data"
    ,  MessageTypes.GnssVelocity -> "gnss-stream-data"
    ,  MessageTypes.GnssDistance -> "gnss-stream-data"
    ,  MessageTypes.GnssHasAlerts -> "gnss-stream-data"
    ,  MessageTypes.GnssMotion -> "gnss-stream-data"
    ,  MessageTypes.AtisAlerts -> "gnss-stream-data"
    ,  MessageTypes.TtlAlerts -> "gnss-stream-data"
    ,  MessageTypes.Kl15Alerts -> "gnss-stream-data"
    ,  MessageTypes.WheelWarningTemperature -> "tpms-alerts-event-data"
    ,  MessageTypes.WheelWarningTemperatureV2 -> "tpms-alerts-event-data"
    ,  MessageTypes.WheelWarningPressureV2 -> "tpms-alerts-event-data"
    ,  MessageTypes.WheelWarningBattery -> "tpms-alerts-event-data"
    ,  MessageTypes.WheelWarningDynamic -> "tpms-alerts-event-data"
    ,  MessageTypes.WheelWarningTyreLock -> "tpms-alerts-event-data"
    ,  MessageTypes.WheelMissingSensor -> "tpms-alerts-event-data"
    ,  MessageTypes.WarningEventPressure -> "tpms-alerts-event-data"
    ,  MessageTypes.WarningEventFastPressureLoss -> "tpms-alerts-event-data"
    ,  MessageTypes.WarningEventTyreBurst -> "tpms-alerts-event-data"
    ,  MessageTypes.WarningEventTyreLock -> "tpms-alerts-event-data"
    ,  MessageTypes.WarningEventGeneric -> "tpms-alerts-event-data"
    ,  MessageTypes.OdometerDist -> "gnss-stream-data"
    ,  MessageTypes.OdometerTripDist -> "gnss-stream-data"
  )

  //This is for Data Plane 0.2/1.2
  val eventDataSchema1 = Map(
    MessageTypes.WheelUnitRf -> ScalaReflection.schemaFor[WheelRfData].dataType.asInstanceOf[StructType]
    ,  MessageTypes.WheelUnitData -> ScalaReflection.schemaFor[WheelTPMSData].dataType.asInstanceOf[StructType]
    ,  MessageTypes.WheelInfoPressure -> ScalaReflection.schemaFor[WheelPressureData].dataType.asInstanceOf[StructType]
    ,  MessageTypes.WheelInfoTemperature -> ScalaReflection.schemaFor[WheelTemperatureData].dataType.asInstanceOf[StructType]
    ,  MessageTypes.WheelInfoBattery -> ScalaReflection.schemaFor[SensorBatteryData].dataType.asInstanceOf[StructType]
    ,  MessageTypes.WarningEventGeneric -> ScalaReflection.schemaFor[AnalyticWarningEventData].dataType.asInstanceOf[StructType]
    ,  MessageTypes.GnssPos -> ScalaReflection.schemaFor[PosData].dataType.asInstanceOf[StructType]
    ,  MessageTypes.GnssTime -> ScalaReflection.schemaFor[TimeData].dataType.asInstanceOf[StructType]
    ,  MessageTypes.GnssDistance -> ScalaReflection.schemaFor[DistanceData].dataType.asInstanceOf[StructType]
    ,  MessageTypes.GnssVelocity -> ScalaReflection.schemaFor[VelocityData].dataType.asInstanceOf[StructType]
    ,  MessageTypes.GnssMotion -> ScalaReflection.schemaFor[MotionData].dataType.asInstanceOf[StructType]
    ,  MessageTypes.AtisAlerts -> ScalaReflection.schemaFor[AtisData].dataType.asInstanceOf[StructType]
    ,  MessageTypes.TtlAlerts -> ScalaReflection.schemaFor[TtlData].dataType.asInstanceOf[StructType]
    ,  MessageTypes.Kl15Alerts -> ScalaReflection.schemaFor[Kl15Data].dataType.asInstanceOf[StructType]
    ,  MessageTypes.WheelWarningTemperature -> ScalaReflection.schemaFor[WarningEvent].dataType.asInstanceOf[StructType]
    ,  MessageTypes.WarningEventPressure -> ScalaReflection.schemaFor[WarningEvent].dataType.asInstanceOf[StructType]
    ,  MessageTypes.WarningEventFastPressureLoss -> ScalaReflection.schemaFor[WarningEvent].dataType.asInstanceOf[StructType]
    ,  MessageTypes.WarningEventTyreBurst -> ScalaReflection.schemaFor[WarningEvent].dataType.asInstanceOf[StructType]
    ,  MessageTypes.WarningEventTyreLock -> ScalaReflection.schemaFor[WarningEvent].dataType.asInstanceOf[StructType]
    ,  MessageTypes.OdometerDist -> ScalaReflection.schemaFor[OdoDistData].dataType.asInstanceOf[StructType]
    ,  MessageTypes.OdometerTripDist -> ScalaReflection.schemaFor[OdoTripDistData].dataType.asInstanceOf[StructType]
  )

  //This is for Data Plane 2.0
  val eventDataSchema = Map(
    MessageTypes.WheelInfoPressureV2 -> ScalaReflection.schemaFor[WheelPressureDataV2].dataType.asInstanceOf[StructType]
    ,  MessageTypes.WheelInfoTemperatureV2 -> ScalaReflection.schemaFor[WheelTemperatureDataV2].dataType.asInstanceOf[StructType]
    ,  MessageTypes.WheelInfoBatteryV2 -> ScalaReflection.schemaFor[SensorBatteryDataV2].dataType.asInstanceOf[StructType]
    ,  MessageTypes.WheelWarningTemperatureV2 -> ScalaReflection.schemaFor[WarningEventV2].dataType.asInstanceOf[StructType]
    ,  MessageTypes.WheelWarningPressureV2 -> ScalaReflection.schemaFor[WarningEventV2].dataType.asInstanceOf[StructType]
    ,  MessageTypes.WheelWarningDynamic -> ScalaReflection.schemaFor[WarningEventV2].dataType.asInstanceOf[StructType]
    ,  MessageTypes.WheelWarningBattery -> ScalaReflection.schemaFor[WarningEventV2].dataType.asInstanceOf[StructType]
    ,  MessageTypes.WheelWarningTyreLock -> ScalaReflection.schemaFor[WarningEventV2].dataType.asInstanceOf[StructType]
    ,  MessageTypes.WheelMissingSensor -> ScalaReflection.schemaFor[WarningEventV2].dataType.asInstanceOf[StructType]
  )

  //This is for Data Plane 0.2/1.2
  val eventSchema1 = Map(
    MessageTypes.WheelUnitRf -> ScalaReflection.schemaFor[WheelUnitRf].dataType.asInstanceOf[StructType]
    ,  MessageTypes.WheelUnitData -> ScalaReflection.schemaFor[WheelUnitData].dataType.asInstanceOf[StructType]
    ,  MessageTypes.WheelInfoPressure -> ScalaReflection.schemaFor[WheelInfoPressure].dataType.asInstanceOf[StructType]
    ,  MessageTypes.WheelInfoTemperature -> ScalaReflection.schemaFor[WheelInfoTemperature].dataType.asInstanceOf[StructType]
    ,  MessageTypes.WheelInfoBattery -> ScalaReflection.schemaFor[WheelInfoBattery].dataType.asInstanceOf[StructType]
    ,  MessageTypes.GnssPos -> ScalaReflection.schemaFor[VehicleGnssPos].dataType.asInstanceOf[StructType]
    ,  MessageTypes.GnssTime -> ScalaReflection.schemaFor[VehicleGnssTime].dataType.asInstanceOf[StructType]
    ,  MessageTypes.GnssDistance -> ScalaReflection.schemaFor[VehicleGnssDistance].dataType.asInstanceOf[StructType]
    ,  MessageTypes.GnssVelocity -> ScalaReflection.schemaFor[VehicleGnssVelocity].dataType.asInstanceOf[StructType]
    ,  MessageTypes.GnssMotion -> ScalaReflection.schemaFor[VehicleGnssMotion].dataType.asInstanceOf[StructType]
    ,  MessageTypes.AtisAlerts -> ScalaReflection.schemaFor[VehicleAtis].dataType.asInstanceOf[StructType]
    ,  MessageTypes.TtlAlerts -> ScalaReflection.schemaFor[VehicleTtl].dataType.asInstanceOf[StructType]
    ,  MessageTypes.Kl15Alerts -> ScalaReflection.schemaFor[VehicleKl15].dataType.asInstanceOf[StructType]
    ,  MessageTypes.WarningEventGeneric -> ScalaReflection.schemaFor[AnalyticWarningEvent].dataType.asInstanceOf[StructType]
    ,  MessageTypes.WheelWarningTemperature -> ScalaReflection.schemaFor[WheelWarningTemperature].dataType.asInstanceOf[StructType]
    ,  MessageTypes.WarningEventPressure -> ScalaReflection.schemaFor[WarningEventPressure].dataType.asInstanceOf[StructType]
    ,  MessageTypes.WarningEventFastPressureLoss -> ScalaReflection.schemaFor[WarningEventFastPressureLoss].dataType.asInstanceOf[StructType]
    ,  MessageTypes.WarningEventTyreBurst -> ScalaReflection.schemaFor[WarningEventTyreBurst].dataType.asInstanceOf[StructType]
    ,  MessageTypes.WarningEventTyreLock -> ScalaReflection.schemaFor[WarningEventTyreLock].dataType.asInstanceOf[StructType]
    ,  MessageTypes.OdometerDist -> ScalaReflection.schemaFor[VehicleOdoDist].dataType.asInstanceOf[StructType]
    ,  MessageTypes.OdometerTripDist -> ScalaReflection.schemaFor[VehicleOdoTripDist].dataType.asInstanceOf[StructType]
  )

  //This is for Data Plane 2.0
  val eventSchema = Map(
    MessageTypes.WheelInfoPressureV2 -> ScalaReflection.schemaFor[WheelInfoPressureV2].dataType.asInstanceOf[StructType]
    ,  MessageTypes.WheelInfoTemperatureV2 -> ScalaReflection.schemaFor[WheelInfoTemperatureV2].dataType.asInstanceOf[StructType]
    ,  MessageTypes.WheelInfoBatteryV2 -> ScalaReflection.schemaFor[WheelInfoBatteryV2].dataType.asInstanceOf[StructType]
    ,  MessageTypes.WheelWarningTemperatureV2 -> ScalaReflection.schemaFor[WheelWarningTemperatureV2].dataType.asInstanceOf[StructType]
    ,  MessageTypes.WheelWarningPressureV2 -> ScalaReflection.schemaFor[WheelWarningPressureV2].dataType.asInstanceOf[StructType]
    ,  MessageTypes.WheelWarningDynamic -> ScalaReflection.schemaFor[WheelWarningDynamic].dataType.asInstanceOf[StructType]
    ,  MessageTypes.WheelWarningBattery -> ScalaReflection.schemaFor[WheelWarningBattery].dataType.asInstanceOf[StructType]
    ,  MessageTypes.WheelWarningTyreLock -> ScalaReflection.schemaFor[WheelWarningTyreLock].dataType.asInstanceOf[StructType]
    ,  MessageTypes.WheelMissingSensor -> ScalaReflection.schemaFor[WheelMissingSensor].dataType.asInstanceOf[StructType]
  )
}

object XirgoMapping extends Enumeration {

  type XirgoMapping = Value;

  val DEVICE_TYPE_HUB1_1 = Value(100,"Hub1.1")
  val DEVICE_TYPE_HUBA = Value(101,"HubA")
  val PRESSURE_STATE_EC0_OVER_PRESSURE = Value(1)
  val PRESSURE_STATE_OVER_PRESSURE = Value(2)
  val PRESSURE_STATE_EXTREME_OVER_PRESSURE = Value(3)
  val PRESSURE_STATE_EC0_UNDER_PRESSURE = Value(4)
  val PRESSURE_STATE_UNDER_PRESSURE = Value(5)
  val PRESSURE_STATE_EXTREME_UNDER_PRESSURE = Value(6)

  val xirgo_tyre_pressure_state = Map(
    PRESSURE_STATE_EC0_OVER_PRESSURE.id -> 1, // ECO over pressure
    PRESSURE_STATE_OVER_PRESSURE.id-> 1, // Over Pressure
    PRESSURE_STATE_EXTREME_OVER_PRESSURE.id -> 0, // Extreme over pressure
    PRESSURE_STATE_EC0_UNDER_PRESSURE.id -> 2, // ECO under pressure
    PRESSURE_STATE_UNDER_PRESSURE.id -> 2, // Under pressure
    PRESSURE_STATE_EXTREME_UNDER_PRESSURE.id -> 3, // Extreme under pressure
  )
}

case class GenericEventHubMessage(
                           body: String
                          ,partition: String
                          ,offset: String
                          ,sequenceNumber: Long
                          ,enqueuedTime: java.sql.Timestamp
                          ,publisher: String
                          ,partitionKey :String
                          ,properties:Map[String,String]
                           ,timestamp: java.sql.Timestamp
                           ,consumed_timestamp: Long
                         )

trait IoTEvent {
  val service: String
  val resource: String
  val time: java.sql.Timestamp
  val version: String
}

case class GenericEvent (
                          deviceId: String
                          , customer: String
                          , evt:GenericEventData
                          , tstamp: java.sql.Timestamp
                          , eventTime: java.sql.Timestamp

                        )


case class GenericEventData (
  service: String
  , resource: String
  , time: Long
  , deviceId: String
  , customer: String
  , version: String = DATA_PLANE_1_0
  , data: String
  , timestamp: Long
  , category: String
  ,consumed_timestamp: Long
)

case class SnapShotGenericEventTiggerData (
                                     service: String
                                     , resource: String
                                     , time: Long
                                     , version: String = DATA_PLANE_1_0
                                     , data: WarningEvent
                                   )
case class  SnapShotGenericEventData (
                              service: String
                              , resource: String
                              , time: Long
                              , version: String = DATA_PLANE_1_0
                              , data: String
                            )

case class GenericGnssEvent(service: String = "gnss"
                           ,resource: String
                            , version: String = DATA_PLANE_1_0
                           , deviceId: String
                            , customer: String
                           , time: java.sql.Timestamp
                           , timestamp: java.sql.Timestamp
                           , consumed_timestamp: Long
                           , data: Map[String,String]
                           , raw_data: String
                          ) extends IoTEvent

case class WarningEvent(

                          location: String
                         , event: Map[String,String]
                         , category: Int
                       )
case class WarningEventV2 (
                          `update-time`: Long
                          , location: String
                          , value: String
                          , updated: String
                          , changed: String

                       )
case class WheelRfData(
                        receiver_source: Map[String,String]
                        , received_timestamp: Long
                        , retention_time: Long
                        , rf_data_mode: String
                        , background_rssi: String
                        , frame_rssi_peak: String
                        , frame_rssi_avg: String
                        , frame_rssi_snr: String
                        , frame_length_bits: String
                        , rf_frame: List[String]
                      )
case class WheelTPMSData (
                          wheel_unit_id: Long
                          , frame_count: String
                          , frame_rssi_peak: String
                          , frame_rssi_snr: String
                          , pressure: String
                          , temperature: String
                          , battery: String
                          , rf_data_mode: String
                          , rf_trigger_mode: String
                          , tyre_fill_mode: String
                         )

case class WheelPressureFields (
                                 measured: String
                                 , temp_comp: String
                               )
case class WheelPressureData (
                               location: String
                              , pressure: WheelPressureFields
                            )

case class WheelPressureDataV2 (
                                 `update-time`: Long
                                 , location: String
                                 , value: String
                                 , updated: String
                                 , changed: String
                              )

case class WheelTemperatureData (
                               location: String
                               , temperature: String
                             )

case class WheelTemperatureDataV2 (
                                    `update-time`: Long
                                    , location: String
                                    , value: String
                                    , updated: String
                                    , changed: String
                                )

case class SensorBatteryData (
                                  location: String
                                  , battery: String
                                )

case class SensorBatteryDataV2 (
                                 `update-time`: Long
                                 , location: String
                                 , value: String
                                 , updated: String
                                 , changed: String
                             )

case class PosData (
                     latitude: String
                     ,longitude: String
                     ,altitude: String
                   )

case class TimeData (
                    time: String
                    )

case class VelocityData (
                          speed: String
                          ,heading: String
                        )

case class MotionData (
                          time: TimeData
                          ,velocity: VelocityData
                          ,position: PosData
                        )

case class DistanceData (
                          odometer: String
                          ,odometer_total: String
                        )

case class AtisData (
                      state: String
                    )                        
                        
case class TtlData (
                      ip_addresses: String
                    )                        
                      
case class Kl15Data (
                      kl15_pin_state: String
                    )

case class OdoDistData (
                         distance: String
                       )

case class OdoTripDistData (
                             `trip-distance`: String
                           )

case class AnalyticWarningEventData (
                                    trigger:SnapShotGenericEventData
                                    , additional_data: List[SnapShotGenericEventData]
                                    )


case class XirgoEventData (
                            eventType: String
                            , deviceType: String
                            , wheelLocation: String
                            , tyreOverTempStatus: Int
                            , altitude: Int
                            , accountName: String
                            , tyreLockDetectStatus: Int
                            , sessionDate: java.sql.Timestamp
                            , latitude: Double
                            , tyrePressure: Double
                            , deviceEsn: String
                            , gpsSpeed: Int
                            , deviceId: String
                            , accountId: String
                            , targetNomPressure: Double
                            , tyreFillAssistStatus: Long
                            , batteryStatus: Long
                            , sensorIdLearnStatus: Long
                            , tyreTemperature: Double
                            , tyrepressureStatus: Long
                            , tyreFastPressureLossStatus: Int
                            , eventTimestamp: java.sql.Timestamp
                            , longitude: Double
                            , consumed_timestamp: java.sql.Timestamp
                          )

case class WheelUnitRf(service: String = "tpms"
                       ,resource: String = MessageTypes.WheelUnitRf
                       , deviceId: String
                       , version: String = DATA_PLANE_1_0
                       ,time: java.sql.Timestamp
                       , timestamp: java.sql.Timestamp
                       , consumed_timestamp: Long
                       , data: WheelRfData
                       , raw_data: String
                      ) extends IoTEvent

case class WheelUnitData(service: String = "tpms"
                         , version: String = DATA_PLANE_1_0
                         , deviceId: String
                          ,resource: String = MessageTypes.WheelUnitData
                          , time: java.sql.Timestamp
                         , timestamp: java.sql.Timestamp
                         , consumed_timestamp: Long
                          , data: WheelTPMSData
                         , raw_data: String
                        ) extends IoTEvent

case class WheelInfoPressure(service: String = "tpms"
                             , version: String = DATA_PLANE_1_0
                             , deviceId: String
                             , customer: String
                             ,resource: String = MessageTypes.WheelInfoPressure
                              , time: java.sql.Timestamp
                             , timestamp: java.sql.Timestamp
                              , consumed_timestamp: Long
                              , data: WheelPressureData
                             , raw_data: String
                              ) extends IoTEvent

case class WheelInfoPressureV2 (service: String = "tpms"
                             , version: String = DATA_PLANE_2_0
                             , deviceId: String
                             , customer: String
                             , resource: String = MessageTypes.WheelInfoPressureV2
                             , time: java.sql.Timestamp
                             , timestamp: java.sql.Timestamp
                             , consumed_timestamp: Long
                             , data: WheelPressureDataV2
                             , raw_data: String
                            )

case class WheelInfoTemperature(service: String = "tpms"
                                , version: String = DATA_PLANE_1_0
                                , deviceId: String
                                , customer: String
                                ,resource: String = MessageTypes.WheelInfoTemperature
                                 , time: java.sql.Timestamp
                                , timestamp: java.sql.Timestamp
                                 , consumed_timestamp: Long
                                 , data: WheelTemperatureData
                                , raw_data: String
                                 ) extends IoTEvent

case class WheelInfoTemperatureV2 (service: String = "tpms"
                                , version: String = DATA_PLANE_2_0
                                , deviceId: String
                                , customer: String
                                , resource: String = MessageTypes.WheelInfoTemperatureV2
                                , time: java.sql.Timestamp
                                , timestamp: java.sql.Timestamp
                                , consumed_timestamp: Long
                                , data: WheelTemperatureDataV2
                                , raw_data: String
                               )

case class AllV2Message (service: String = "tpms"
                                   , version: String = DATA_PLANE_2_0
                                   , deviceId: String
                                   , customer: String
                                   , resource: String
                                   , time: java.sql.Timestamp
                                   , timestamp: java.sql.Timestamp
                                   , consumed_timestamp: Long
                                   , data: WarningEventV2
                                  )

case class WheelInfoBattery(service: String = "tpms"
                            , version: String = DATA_PLANE_1_0
                            , deviceId: String
                            , customer: String
                            ,resource: String = MessageTypes.WheelInfoBattery
                             , time: java.sql.Timestamp
                            , timestamp: java.sql.Timestamp
                             , consumed_timestamp: Long
                             , data: SensorBatteryData
                            , raw_data: String
                             ) extends IoTEvent

case class WheelInfoBatteryV2 (service: String = "tpms"
                            , version: String = DATA_PLANE_2_0
                            , deviceId: String
                            , customer: String
                            , resource: String = MessageTypes.WheelInfoBatteryV2
                            , time: java.sql.Timestamp
                            , timestamp: java.sql.Timestamp
                            , consumed_timestamp: Long
                            , data: SensorBatteryDataV2
                            , raw_data: String
                           )

case class VehicleGnssPos(service: String = "gnss"
                          , version: String = DATA_PLANE_1_0
                          ,resource: String = MessageTypes.GnssPos
                          , deviceId: String
                          , customer: String
                          , time: java.sql.Timestamp
                          , timestamp: java.sql.Timestamp
                          , consumed_timestamp: Long
                          , data: PosData
                          , raw_data: String
                          ) extends IoTEvent

case class VehicleGnssTime(service: String = "gnss"
                          , version: String = DATA_PLANE_1_0
                          ,resource: String = MessageTypes.GnssTime
                          , deviceId: String
                          , customer: String
                          , time: java.sql.Timestamp
                          , timestamp: java.sql.Timestamp
                          , consumed_timestamp: Long
                          , data: TimeData
                          , raw_data: String
                         ) extends IoTEvent

case class VehicleGnssVelocity(service: String = "gnss"
                          , version: String = DATA_PLANE_1_0
                          , resource: String = MessageTypes.GnssVelocity
                          , deviceId: String
                          , customer: String
                          , time: java.sql.Timestamp
                          , timestamp: java.sql.Timestamp
                          , consumed_timestamp: Long
                          , data: VelocityData
                          , raw_data: String
                         ) extends IoTEvent

case class VehicleGnssMotion(service: String = "gnss"
                               , version: String = DATA_PLANE_1_0
                               , resource: String = MessageTypes.GnssMotion
                               , deviceId: String
                               , customer: String
                               , time: java.sql.Timestamp
                               , timestamp: java.sql.Timestamp
                               , consumed_timestamp: Long
                               , data: MotionData
                               , raw_data: String
                              ) extends IoTEvent

case class VehicleGnssDistance(service: String = "gnss"
                               , version: String = DATA_PLANE_1_0
                               , resource: String = MessageTypes.GnssDistance
                               , deviceId: String
                               , customer: String
                               , time: java.sql.Timestamp
                               , timestamp: java.sql.Timestamp
                               , consumed_timestamp: Long
                               , data: DistanceData
                               , raw_data: String
                              ) extends IoTEvent
case class VehicleHasAlerts(
                            service: String = "gnss"
                            , version: String = DATA_PLANE_1_0
                            , resource: String = MessageTypes.GnssHasAlerts
                            , deviceId: String
                            , customer: String
                            , time: java.sql.Timestamp
                            , timestamp: java.sql.Timestamp
                            , consumed_timestamp: Long
                            , data: Int
                            , raw_data: String
                          ) extends IoTEvent

case class VehicleAtis(
                            service: String = "atis"
                            , version: String = "1.0"
                            , resource: String = MessageTypes.AtisAlerts
                            , deviceId: String
                            , customer: String
                            , time: java.sql.Timestamp
                            , timestamp: java.sql.Timestamp
                            , consumed_timestamp: Long
                            , data: AtisData
                            , raw_data: String
                          ) extends IoTEvent                         
                          
case class VehicleTtl(
                            service: String = "truck-trailer"
                            , version: String = DATA_PLANE_1_0
                            , resource: String = MessageTypes.TtlAlerts
                            , deviceId: String
                            , customer: String
                            , time: java.sql.Timestamp
                            , timestamp: java.sql.Timestamp
                            , consumed_timestamp: Long
                            , data: TtlData
                            , raw_data: String
                          ) extends IoTEvent  
                          
case class VehicleKl15(
                            service: String = "kl15-monitor"
                            , version: String = DATA_PLANE_1_0
                            , resource: String = MessageTypes.Kl15Alerts
                            , deviceId: String
                            , customer: String
                            , time: java.sql.Timestamp
                            , timestamp: java.sql.Timestamp
                            , consumed_timestamp: Long
                            , data: Kl15Data
                            , raw_data: String
                          ) extends IoTEvent

case class VehicleOdoDist(service: String = "odometer"
                          , version: String = "0.1"
                          , resource: String = MessageTypes.OdometerDist
                          , deviceId: String
                          , customer: String
                          , time: java.sql.Timestamp
                          , timestamp: java.sql.Timestamp
                          , consumed_timestamp: Long
                          , data: OdoDistData
                          , raw_data: String
                         ) extends IoTEvent

case class VehicleOdoTripDist(service: String = "odometer"
                          , version: String = "0.1"
                          , resource: String = MessageTypes.OdometerTripDist
                          , deviceId: String
                          , customer: String
                          , time: java.sql.Timestamp
                          , timestamp: java.sql.Timestamp
                          , consumed_timestamp: Long
                          , data: OdoTripDistData
                          , raw_data: String
                         )
                          
// Warnings
case class WheelWarningTemperature (
                                     service: String = "tpms"
                                     , version: String = DATA_PLANE_1_0
                                     , deviceId: String
                                     , customer: String
                                     , resource: String = MessageTypes.WheelWarningTemperature
                                     , time: java.sql.Timestamp
                                     , timestamp: java.sql.Timestamp
                                     , consumed_timestamp: Long
                                     , data: WarningEvent
                                     , raw_data: String
                                   ) extends IoTEvent

case class WheelWarningTemperatureV2 (
                                     service: String = "tpms"
                                     , version: String = DATA_PLANE_2_0
                                     , deviceId: String
                                     , customer: String
                                     , resource: String = MessageTypes.WheelWarningTemperatureV2
                                     , time: java.sql.Timestamp
                                     , timestamp: java.sql.Timestamp
                                     , consumed_timestamp: Long
                                     , data: WarningEventV2
                                     , raw_data: String
                                   )

case class WarningEventPressure(service: String = "tpms"
                                , version: String = DATA_PLANE_1_0
                                , deviceId: String
                                , customer: String
                                , resource: String = MessageTypes.WarningEventPressure
                                , time: java.sql.Timestamp
                                , timestamp: java.sql.Timestamp
                                , consumed_timestamp: Long
                                , data: WarningEvent
                                , raw_data: String
                                ) extends IoTEvent

case class WheelWarningPressureV2(service: String = "tpms"
                                , version: String = DATA_PLANE_2_0
                                , deviceId: String
                                , customer: String
                                , resource: String = MessageTypes.WheelWarningPressureV2
                                , time: Long
                                , timestamp: Long
                                , consumed_timestamp: Long
                                , data: WarningEventV2
                                , raw_data: String
                               )

case class WarningEventFastPressureLoss(service: String = "tpms"
                                        , version: String = DATA_PLANE_1_0
                                        , deviceId: String
                                        , customer: String
                                        , resource: String = MessageTypes.WarningEventFastPressureLoss
                                        , time: java.sql.Timestamp
                                        , timestamp: java.sql.Timestamp
                                        , consumed_timestamp: Long
                                        , data: WarningEvent
                                        , raw_data: String
                                        ) extends IoTEvent

case class WheelWarningDynamic(service: String = "tpms"
                                        , version: String = DATA_PLANE_2_0
                                        , deviceId: String
                                        , customer: String
                                        , resource: String = MessageTypes.WheelWarningDynamic
                                        , time: java.sql.Timestamp
                                        , timestamp: java.sql.Timestamp
                                        , consumed_timestamp: Long
                                        , data: WarningEventV2
                                        , raw_data: String
                                       )

case class WarningEventTyreBurst(service: String = "tpms"
                                 , version: String = DATA_PLANE_1_0
                                 , deviceId: String
                                 , customer: String
                                 , resource: String = MessageTypes.WarningEventTyreBurst
                                 , time: java.sql.Timestamp
                                 , timestamp: java.sql.Timestamp
                                 , consumed_timestamp: Long
                                 , data: WarningEvent
                                 , raw_data: String
                                 ) extends IoTEvent

case class WheelWarningBattery(service: String = "tpms"
                                 , version: String = DATA_PLANE_2_0
                                 , deviceId: String
                                 , customer: String
                                 , resource: String = MessageTypes.WheelWarningBattery
                                 , time: java.sql.Timestamp
                                 , timestamp: java.sql.Timestamp
                                 , consumed_timestamp: Long
                                 , data: WarningEventV2
                                 , raw_data: String
                                )

case class WarningEventTyreLock(service: String = "tpms"
                                 , version: String = DATA_PLANE_1_0
                                 , deviceId: String
                                 , customer: String
                                 , resource: String = MessageTypes.WarningEventTyreLock
                                 , time: java.sql.Timestamp
                                 , timestamp: java.sql.Timestamp
                                 , consumed_timestamp: Long
                                 , data: WarningEvent
                                 , raw_data: String
                                ) extends IoTEvent

case class WheelWarningTyreLock(service: String = "tpms"
                                , version: String = DATA_PLANE_2_0
                                , deviceId: String
                                , customer: String
                                , resource: String = MessageTypes.WheelWarningTyreLock
                                , time: java.sql.Timestamp
                                , timestamp: java.sql.Timestamp
                                , consumed_timestamp: Long
                                , data: WarningEventV2
                                , raw_data: String
                               )

case class WheelMissingSensor (service: String = "tpms"
                                , version: String = DATA_PLANE_2_0
                                , deviceId: String
                                , customer: String
                                , resource: String = MessageTypes.WheelMissingSensor
                                , time: java.sql.Timestamp
                                , timestamp: java.sql.Timestamp
                                , consumed_timestamp: Long
                                , data: WarningEventV2
                                , raw_data: String
                               )


// Analytics Event (Snapshot)
case class AnalyticWarningEvent(
                                 service: String = "analytics"
                                 , resource: String = MessageTypes.WarningEventGeneric
                                 , version: String = DATA_PLANE_1_0
                                 , deviceId: String
                                 , customer: String
                                 , time: java.sql.Timestamp
                                 , timestamp: java.sql.Timestamp
                                 , consumed_timestamp: Long
                                 , data: AnalyticWarningEventData
                                 , raw_data: String
                               ) extends IoTEvent

