package com.sensata.data_office.pipeline.queries

import com.sensata.data_office.data.MessageTypes._
import com.sensata.data_office.data.{GenericEventData, MessageTypes}
import com.sensata.data_office.utilities.PipelineUtil
import com.typesafe.config.ConfigFactory
import org.apache.spark.sql.catalyst.ScalaReflection
import org.apache.spark.sql.functions._
import org.apache.spark.sql.streaming.Trigger
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.{Dataset, Row}
import org.apache.spark.storage.StorageLevel


object RawEventsProcessor {

  val pipelineConfig = ConfigFactory
    .load(s"application.${PipelineUtil.getEnvVariable("ENVIRONMENT")}.conf")
    .getConfig("RawEventsProcessor").getConfig("pipeline")

  val VERSION = pipelineConfig.getString("version")

  import PipelineUtil.spark.implicits._

  def processBatch(batchDF: Dataset[Row], batchId: Long): Unit = {
    batchDF.persist()

    if (pipelineConfig.getBoolean("persist_local_copy") || pipelineConfig.getBoolean("in_debug")) {
      // persist raw data as received from the message bus
      batchDF.write
        .partitionBy("consumed_timestamp")
        .format("delta")
        .mode("append")
        .option("mergeSchema", "true")
        .save(pipelineConfig.getString("data_path") + "raw")
    }

    val device_new = try {
      PipelineUtil.updateCustomerDimCacheFromDatabase()
        .persist(StorageLevel.MEMORY_AND_DISK)
    } catch {
      case _ => PipelineUtil.FetchCustomerDeviceFromDatabase()
        .persist(StorageLevel.MEMORY_AND_DISK)
    }

    val list_wrnr = device_new
      .select($"device_id")
      .where($"company_name" === "Werner")
      .as[String]
      .collect
      .toList 

    //*************************This is only for Werner******************************
     
   /* val Wrnr_All_Message = batchDF
      .where((
        $"value" cast "string" rlike (".*\"resource\":\"wheel/pressure\".*")
      ) || ($"value" cast "string" rlike (".*\"resource\":\"wheel/temperature\".*")
      ) || ($"value" cast "string" rlike (".*\"resource\":\"wheel/battery\".*")
      ) || ($"value" cast "string" rlike (".*\"resource\":\"atis-state\".*")
      ) || ($"value" cast "string" rlike (".*\"resource\":\"events/warnings/\".*")
      ) || ($"value" cast "string" rlike (".*\"resource\":\"events/warnings/pressure\".*")
      ) || ($"value" cast "string" rlike (".*\"resource\":\"events/warnings/temperature\".*")
      ) || ($"value" cast "string" rlike (".*\"resource\":\"events/warnings/fast-pressure-loss\".*")
      ) || ($"value" cast "string" rlike (".*\"resource\":\"events/warnings/tyre-burst\".*")
      ) || ($"value" cast "string" rlike (".*\"resource\":\"events/warnings/tyre-lock\".*")
      ) || ($"value" cast "string" rlike (".*\"resource\":\"wheel/.*\".*"))
     )
      .filter(get_json_object($"value" cast "string", "$.deviceId").isin(list_wrnr:_*))
      .select($"value")

     PipelineUtil.writeDataFrameToKafkaTopic1(Wrnr_All_Message, "append", PipelineUtil.kafkaConfig
       , pipelineConfig.getString("wrnr_alerts_new_topic")
     )*/

    //*************************Above is only for WRNR***********************************************

    //*************************************This is for VOLVO POC *************************************
     
    val device_list_volvo = List("1JXjwW8C8712","1JXjwW8C7y12","1JXjfKxC1912","1JXjpFXC8R12","1JXjpFXCCt12","1KqjxXLC4w12")

    val Volvo_All_Message = batchDF
          .filter(get_json_object($"value" cast "string", "$.deviceId").isin(device_list_volvo:_*))
          .select($"value")

    PipelineUtil.writeDataFrameToKafkaTopic1(Volvo_All_Message, "append", PipelineUtil.kafkaConfig
      , pipelineConfig.getString("volvo_poc_new_topic")
    )

    //*************************************This is for VOLVO POC *************************************

    //*************************************This is for PEPSI DP2 Msg *************************************
  /*  val list_ppsi = device_new
      .select($"device_id")
      .where($"company_name" === "Pepsi")
      .as[String]
      .collect
      .toList

    val Pepsi_All_Message = batchDF
      .filter(get_json_object($"value" cast "string", "$.deviceId").isin(list_ppsi:_*))
      .select($"value")

    PipelineUtil.writeDataFrameToKafkaTopic1(Pepsi_All_Message, "append", PipelineUtil.kafkaConfig
      , pipelineConfig.getString("pepsi_dp2_new_topic")
    )*/
    //*************************************This is for PEPSI DP2 Msg *************************************
    
    //*************************************This is for REYES Msg *************************************
  /*  val list_ryes = device_new
      .select($"device_id")
      .where($"company_name" === "Reyes")
      .as[String]
      .collect
      .toList

    val Reyes_All_Message = batchDF
      .filter(get_json_object($"value" cast "string", "$.deviceId").isin(list_ryes:_*))
      .select($"value")

    PipelineUtil.writeDataFrameToKafkaTopic1(Reyes_All_Message, "append", PipelineUtil.kafkaConfig
      , pipelineConfig.getString("reyes_m2m_new_topic")
    )*/
    //*************************************This is for REYES Msg *************************************
    
    //*************************************This is for DASEKE Msg *************************************
  /*  val list_dske = device_new
      .select($"device_id")
      .where($"company_name" === "Daseke-RM")
      .as[String]
      .collect
      .toList

    val Daseke_All_Message = batchDF
      .filter(get_json_object($"value" cast "string", "$.deviceId").isin(list_dske:_*))
      .select($"value")

    PipelineUtil.writeDataFrameToKafkaTopic1(Daseke_All_Message, "append", PipelineUtil.kafkaConfig
      , pipelineConfig.getString("daseke_m2m_new_topic")
    )*/
    //*************************************This is for DASEKE Msg *************************************

    //*************************************This is for PENSKE Msg *************************************
  /*  val list_pnke = device_new
      .select($"device_id")
      .where($"company_name" === "Penske")
      .as[String]
      .collect
      .toList
 
    val Penske_All_Message = batchDF
      .filter(get_json_object($"value" cast "string", "$.deviceId").isin(list_pnke:_*))
      .select($"value")

    PipelineUtil.writeDataFrameToKafkaTopic1(Penske_All_Message, "append", PipelineUtil.kafkaConfig
      , pipelineConfig.getString("penske_m2m_new_topic")
    )*/
    //*************************************This is for PENSKE Msg *************************************

    //*************************************This is for WERNER Msg *************************************
   
  /*  val Werner_All_Message = batchDF
      .filter(get_json_object($"value" cast "string", "$.deviceId").isin(list_wrnr:_*))
      .select($"value")

    PipelineUtil.writeDataFrameToKafkaTopic1(Werner_All_Message, "append", PipelineUtil.kafkaConfig
      , pipelineConfig.getString("werner_m2m_new_topic")
    )*/

    //*************************************This is for WERNER Msg *************************************

    //*************************************This is for 4Track POC *************************************
   /* val device_list_4track = List("1MP4X3bPRd12","1KqjxXLC4312","1KqjxXLC5Y12","1JXk54kC3j12")

    val Fourtrack_All_Message = batchDF
      .filter(get_json_object($"value" cast "string", "$.deviceId").isin(device_list_4track:_*))
      .select($"value")

    PipelineUtil.writeDataFrameToKafkaTopic1(Fourtrack_All_Message, "append", PipelineUtil.kafkaConfig
      , pipelineConfig.getString("4track_poc_new_topic")
    )*/
    //*************************************This is for 4Track POC *************************************

    //*************************************This is for FEDEX Msg *************************************
  /*  val list_fedx = device_new
      .select($"device_id")
      .where($"company_name" === "FedEx")
      .as[String]
      .collect
      .toList

    val Fedex_All_Message = batchDF
      .filter(get_json_object($"value" cast "string", "$.deviceId").isin(list_fedx:_*))
      .select($"value")

    PipelineUtil.writeDataFrameToKafkaTopic1(Fedex_All_Message, "append", PipelineUtil.kafkaConfig
      , pipelineConfig.getString("fedex_m2m_new_topic")
    )*/
    //*************************************This is for FEDEX Msg *************************************



    //*************************************This is for Philips POC *************************************
    val device_list_philips = List("1KqjxXLC2g12","1MP4X3bPS712")

    val Philips_All_Message = batchDF
      .filter(get_json_object($"value" cast "string", "$.deviceId").isin(device_list_philips:_*))
      .select($"value")

    PipelineUtil.writeDataFrameToKafkaTopic1(Philips_All_Message, "append", PipelineUtil.kafkaConfig
      , pipelineConfig.getString("philips_poc_new_topic")
    )
    //*************************************This is for Philips POC *************************************


    val IoTEvents_tmp_unfiltered = PipelineUtil.constructGenericIOTEventMessage(batchDF);

    // filter out any messages with a time field older than 2 days
    val IoTEvents_tmp = IoTEvents_tmp_unfiltered
      .where(
        ($"time" / 1000 cast "timestamp")
          >=
          date_sub(
            current_timestamp() cast "date", PipelineUtil.getEnvVariable("INVALID_TIME_FILTER_THRESHOLD", "2").toInt
          )
      )

    // get Data-Plane 2.0 messages
    val v2_messages = IoTEvents_tmp
      .where(
        coalesce(substring(trim($"version"), 0, 3) cast "double", lit(0)) >= DATA_PLANE_2_0.toDouble
      )
      .withColumnRenamed("resource", "resource_new")
      .withColumn("resource", regexp_replace($"resource_new","\\/.*\\/","/"))
      .withColumn("location", regexp_extract($"resource_new",".*\\/([0-9a-zA-z]{2,2})\\/.*",1))
      .drop("resource_new")

    // pull alert messages from analytics messages and add to stream
    val analytics_trig = PipelineUtil.extractAnalyticMessageAlerts(IoTEvents_tmp.toDF())

    // pull tpms messages from analytics messages and add to stream
    val analytics_addtn = PipelineUtil.extractAnalyticMessageTPMS(IoTEvents_tmp.toDF())

    // group all messages together for processing
    val IoTEvents = IoTEvents_tmp
      .where(
        coalesce(substring(trim($"version"), 0, 3) cast "double", lit(0)) < DATA_PLANE_2_0.toDouble
      )
      .union(
        analytics_trig
      ).union(
      analytics_addtn
    ).toDF()


    val list_warnings = Seq(
      WarningEventPressure
      , WarningEventFastPressureLoss
      , WarningEventTyreBurst
      , WheelWarningTemperature
      , WarningEventGeneric
      , WheelWarningBattery
      , WheelWarningDynamic
      , WheelWarningTyreLock
      , WheelWarningTemperatureV2
      , WheelWarningPressureV2
      , WheelMissingSensor
    )


       val list_msg_with_location = Seq(
        WheelInfoPressureV2
      , WheelInfoTemperatureV2
      , WheelInfoBatteryV2
      , WheelWarningBattery
      , WheelWarningDynamic
      , WheelWarningTyreLock
      , WheelWarningTemperatureV2
      , WheelWarningPressureV2
      , WheelMissingSensor
    )

    var batchDFs = Map("None" -> PipelineUtil.spark.emptyDataFrame)
    var v2batchDFs = Map("None" -> PipelineUtil.spark.emptyDataFrame)
    val event_schema = ScalaReflection.schemaFor[GenericEventData].dataType.asInstanceOf[StructType]

    // process V1 messages
    if (IoTEvents.count() > 0) {
      for ((bevent, event_topic) <- MessageTypes.eventTopics1) {

        batchDFs +=
          bevent -> PipelineUtil.buildJsonMessage(
            IoTEvents.where($"resource" === bevent)
            , MessageTypes.eventDataSchema1.getOrElse(bevent, event_schema)
         )
            .withColumn("topic", lit(event_topic))
      }
    }

    // process V2 messages
    if (v2_messages.count() > 0) {
      for ((aevent, event_topic) <- MessageTypes.eventTopics) {

        v2batchDFs +=
          aevent -> PipelineUtil.buildJsonMessageV2(
           // v2_messages
              v2_messages.where($"resource" === aevent)
            , MessageTypes.eventDataSchema.getOrElse(aevent, event_schema)
            , list_msg_with_location.contains(aevent)
          )
            .withColumn("topic", lit(event_topic))
      }
    }

    // send odometer with alerts
    PipelineUtil.writeDataFrameToKafkaTopic(
      batchDFs
      .filter(v => (List(GnssDistance,OdometerDist,OdometerTripDist) ::: list_warnings.toList).contains(v._1) )
        .filter(v => !v._2.isEmpty)
      .map(_._2)
      .reduceOption((df1,df2) => df1.union(df2))
        .getOrElse(PipelineUtil.spark.emptyDataFrame.select(
          lit("") as "key"
          ,lit("") as "value"
          ,lit("") as "topic"
        ))
        .union(
          v2batchDFs
            .filter(v => (List(GnssDistance,OdometerDist,OdometerTripDist) ::: list_warnings.toList).contains(v._1) )
            .filter(v => !v._2.isEmpty)
            .map(_._2)
            .reduceOption((df1,df2) => df1.union(df2))
            .getOrElse(PipelineUtil.spark.emptyDataFrame.select(
              lit("") as "key"
              ,lit("") as "value"
              ,lit("") as "topic"
            ))
        )
        .drop("topic")
      , "append"
      , PipelineUtil.kafkaConfig
      , MessageTypes.eventTopics.getOrElse(WarningEventPressure,"tpms-alerts-event-data")
    )

    // send any data that is not an alert message
    PipelineUtil.writeDataFrameToKafka(
      batchDFs
      .filter(v => !list_warnings.toList.contains(v._1) && !List("None").contains(v._1) )
        .filter(v => !v._2.isEmpty)
    .map(_._2)
      .reduceOption((df1,df2) => df1.union(df2))
        .getOrElse(PipelineUtil.spark.emptyDataFrame.select(
          lit("") as "key"
          ,lit("") as "value"
          ,lit("") as "topic"
        ))
      .union(
        v2batchDFs
          .filter(v => !list_warnings.toList.contains(v._1) && !List("None").contains(v._1) )
          .filter(v => !v._2.isEmpty)
          .map(_._2)
          .reduceOption((df1,df2) => df1.union(df2))
          .getOrElse(PipelineUtil.spark.emptyDataFrame.select(
            lit("") as "key"
            ,lit("") as "value"
            ,lit("") as "topic"
          ))
      )
      , "append"
      , PipelineUtil.kafkaConfig
    )

    batchDF.unpersist()
  }

  def doRawEventProcessing() {

    val rawMessage = PipelineUtil.readDataFrameFromKafkaWithConsumedTimestamp(
      PipelineUtil.getEnvVariable("RAW_PROCESSOR_SRC_TOPIC"
        , pipelineConfig.getString("source_stream_topic")
      )
      , PipelineUtil.kafkaConfig + ("failOnDataLoss" -> "false")
    )

    rawMessage.writeStream
      .option("checkpointLocation"
        , s"${
          PipelineUtil.getEnvVariable("RAW_PROCESSOR_CHECKPOINT_PATH"
            , pipelineConfig.getString("raw_json_checkpoint_location")
          )
        }"
      )
      .trigger(Trigger.ProcessingTime("interval 20 seconds"))
      .foreachBatch(processBatch _)
      .queryName("Raw MessageSplitter")
      .start()

  }
}
