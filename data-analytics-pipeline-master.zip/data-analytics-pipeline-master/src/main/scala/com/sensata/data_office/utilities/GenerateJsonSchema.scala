package com.sensata.data_office.utilities

import com.sksamuel
import json._
import java.io._

import com.github.andyglow.json.JsonFormatter
import com.github.andyglow.jsonschema.AsValue
import com.sensata.data_office.data.{DashBoardVehicleRecordCurrent, DashBoardVehicleRecordHistory, DashBoardWheelAlertRecord, DashBoardWheelAlertRecordCurrent, DashBoardWheelRecord, DashBoardWheelRecordCurrent, DashBoardWheelRecordHistory, DashBoardWheelWarningRecordHistory, VehicleKeyMapping, WheelKeyMapping}
import com.sksamuel.avro4s.AvroSchema
import json.schema.Version.Draft07

object GenerateJsonSchema {

  def main(args: Array[String]): Unit = {

    val base_path = "C:\\Users\\Charles Bajomo\\Projects\\sensata\\data-analytics-pipeline\\kafka-connectors\\schemas"

    val filname_2_schema = Map(
      "wheel_alert_current" -> (Json.schema[DashBoardWheelAlertRecord], AvroSchema[DashBoardWheelAlertRecord]),
      "wheel_alert_agg" -> (Json.schema[DashBoardWheelAlertRecordCurrent], AvroSchema[DashBoardWheelAlertRecordCurrent]),
      "wheel_data_current" -> (Json.schema[DashBoardWheelRecord], AvroSchema[DashBoardWheelRecord]),
      "wheel_data_agg" -> (Json.schema[DashBoardWheelRecordCurrent], AvroSchema[DashBoardWheelRecordCurrent]),
      "vehicle_data_current" -> (Json.schema[DashBoardVehicleRecordCurrent], AvroSchema[DashBoardVehicleRecordCurrent]),
      "vehicle_history_dashboard" -> (Json.schema[DashBoardVehicleRecordHistory], AvroSchema[DashBoardVehicleRecordHistory]),
      "wheel_history_dashboard" -> (Json.schema[DashBoardWheelRecordHistory], AvroSchema[DashBoardWheelRecordHistory]),
      "alert_history_dashboard" -> (Json.schema[DashBoardWheelWarningRecordHistory], AvroSchema[DashBoardWheelWarningRecordHistory]),
      "wheel_key_mapping" -> (Json.schema[WheelKeyMapping], AvroSchema[WheelKeyMapping]),
      "vehicle_key_mapping" -> (Json.schema[VehicleKeyMapping], AvroSchema[VehicleKeyMapping]),
    )

    filname_2_schema.foreach(d => {

      val json_file = new PrintWriter(
        new File(base_path + "/" + d._1 + ".json")
      )
      json_file.write(JsonFormatter.format(AsValue.schema(d._2._1,json.schema.Version.Draft07(d._1))))
      json_file.close()

      val avro_file = new PrintWriter(
        new File(base_path + "/" + d._1 + ".avsc")
      )
      avro_file.write(d._2._2.toString(true))
      avro_file.close()

    })
}

}
