# Smart and Connected Spark Analytics Pipeline on Databricks
This Repo containe all the Spark scala jobs used by the streaming and batch jobs in Databricks. Full details on the project is available in confluence. [Data Processing Pipelines](http://confluence.corp.sensata.com/pages/viewpage.action?spaceKey=SCCP&title=Data+Processing+Pipelines) or
[Data Processing Pipelines](https://sensatacloud.atlassian.net/wiki/spaces/SCCP/pages/642744767/Data+Processing+Pipelines)

## Key points
 - Primary Streaming Job Entry point: com.sensata.data_office.pipeline.StreamingPipeline
 - Batch Fact data loads: com.sensata.data_office.batch.FactDataLoader
 - History data loads: com.sensata.data_office.batch.DashboardDataLoader
 - Common DataModel: com.sensata.data_office.data.*
